package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Práctica digital de lectura de mira tipo E.
 * Todo se dibuja por código para mantener nitidez, poco peso
 * y generar ejercicios aleatorios sin usar imágenes fijas.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int subTextColor;
    private final int panelColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.subTextColor = subTextColor;
        this.panelColor = panelColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        // Ventana visible de 30 cm, como una lectura cercana por el nivel.
        int firstDm = 3 + random.nextInt(45); // De 0.30 m a 4.70 m.
        visibleMin = firstDm / 10.0;
        visibleMax = visibleMin + 0.30;

        // El hilo medio queda cerca del centro y no exactamente en un centímetro.
        int middleMm = (int) Math.round((visibleMin + 0.15) * 1000.0);
        middleMm += random.nextInt(31) - 15;
        int remainder = floorMod(middleMm, 10);
        if (remainder == 0 || remainder == 1 || remainder == 9) middleMm += 4;

        // LS y LI siempre quedan simétricos respecto a LM.
        int halfSpanMm = 62 + random.nextInt(34); // 62 a 95 mm por lado.
        int minMm = (int) Math.round(visibleMin * 1000.0) + 12;
        int maxMm = (int) Math.round(visibleMax * 1000.0) - 12;
        if (middleMm - halfSpanMm < minMm) middleMm = minMm + halfSpanMm;
        if (middleMm + halfSpanMm > maxMm) middleMm = maxMm - halfSpanMm;

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;
        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = width + dp(42);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(16), dp(16), paint);

        float footer = dp(28);
        float cx = w / 2f;
        float cy = (h - footer) / 2f;
        float radius = Math.min(w * 0.475f, (h - footer) * 0.485f);

        // Borde oscuro del ocular.
        paint.setColor(Color.rgb(15, 18, 23));
        paint.setShadowLayer(dp(8), 0, dp(2), Color.argb(115, 0, 0, 0));
        canvas.drawCircle(cx, cy, radius + dp(6), paint);
        paint.clearShadowLayer();

        Path lens = new Path();
        lens.addCircle(cx, cy, radius, Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(lens);

        paint.setColor(Color.rgb(242, 242, 242));
        canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint);

        // Sombra muy suave del lente, sin tapar la escala.
        paint.setColor(Color.argb(12, 0, 0, 0));
        canvas.drawCircle(cx + radius * 0.22f, cy + radius * 0.10f, radius * 0.92f, paint);

        drawStaff(canvas, cx, cy, radius);
        drawThreads(canvas, cx, cy, radius);

        canvas.restoreToCount(save);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(3));
        paint.setColor(Color.rgb(20, 22, 27));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.rgb(110, 110, 110));
        canvas.drawCircle(cx, cy, radius - dp(3), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(10.5f));
        paint.setColor(subTextColor);
        canvas.drawText("Mira tipo E digital · cada franja equivale a 1 cm", cx, h - dp(7), paint);
    }

    private void drawStaff(Canvas canvas, float cx, float cy, float radius) {
        // Mira angosta, similar a la referencia real.
        float staffWidth = Math.min(dp(112), radius * 0.43f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = cy - radius - dp(6);
        float staffBottom = cy + radius + dp(6);

        float patternLeft = staffLeft;
        float divider = staffLeft + staffWidth * 0.50f;
        float numberRight = staffRight;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(28, 28, 28));
        paint.setStrokeWidth(dp(1.1f));
        canvas.drawLine(staffLeft, staffTop, staffLeft, staffBottom, paint);
        canvas.drawLine(divider, staffTop, divider, staffBottom, paint);
        canvas.drawLine(staffRight, staffTop, staffRight, staffBottom, paint);

        // Solo líneas principales por decímetro. Sin la cuadrícula fea anterior.
        int firstDm = (int) Math.floor(visibleMin * 10.0);
        int lastDm = (int) Math.ceil(visibleMax * 10.0);
        for (int dm = firstDm; dm <= lastDm; dm++) {
            float y = readingToY(dm / 10.0, staffTop, staffBottom);
            paint.setColor(Color.rgb(115, 115, 115));
            paint.setStrokeWidth(dp(0.8f));
            canvas.drawLine(staffLeft, y, staffRight, y, paint);
        }

        // Tres bloques de 10 cm completos.
        for (int dm = firstDm; dm < lastDm; dm++) {
            float yTop = readingToY((dm + 1) / 10.0, staffTop, staffBottom);
            float yBottom = readingToY(dm / 10.0, staffTop, staffBottom);
            float top = Math.min(yTop, yBottom);
            float bottom = Math.max(yTop, yBottom);
            if (bottom < staffTop || top > staffBottom) continue;

            drawEBlock(canvas, dm, patternLeft, divider, top, bottom);
            drawDecimeterNumber(canvas, dm, divider, numberRight, top, bottom);
        }
    }

    /**
     * Patrón realista por decímetro:
     * una E ocupa 5 cm y los otros 5 cm muestran dos rectángulos.
     * La posición se alterna en cada decímetro, como en una mira tipo E real.
     */
    private void drawEBlock(Canvas canvas, int dm, float left, float right, float top, float bottom) {
        float cmHeight = (bottom - top) / 10f;
        boolean eOnTop = floorMod(dm, 2) == 0;
        float upperHalf = top;
        float lowerHalf = top + cmHeight * 5f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(232, 30, 38));

        if (eOnTop) {
            drawEHalf(canvas, left, right, upperHalf, cmHeight);
            drawTwoBarsHalf(canvas, left, right, lowerHalf, cmHeight);
        } else {
            drawTwoBarsHalf(canvas, left, right, upperHalf, cmHeight);
            drawEHalf(canvas, left, right, lowerHalf, cmHeight);
        }
    }

    private void drawEHalf(Canvas canvas, float left, float right, float halfTop, float cmHeight) {
        float width = right - left;
        float margin = width * 0.05f;
        float spineWidth = width * 0.20f;
        float xLeft = left + margin;
        float xRight = right - margin;
        float bandHeight = cmHeight * 0.90f;

        // Espina vertical a la derecha: la E mira hacia la izquierda, como la referencia.
        canvas.drawRect(xRight - spineWidth, halfTop, xRight, halfTop + cmHeight * 5f, paint);

        // Tres brazos rojos de 1 cm separados por espacios blancos de 1 cm.
        for (int i = 0; i < 3; i++) {
            float y = halfTop + cmHeight * (i * 2) + cmHeight * 0.05f;
            canvas.drawRect(xLeft, y, xRight, y + bandHeight, paint);
        }
    }

    private void drawTwoBarsHalf(Canvas canvas, float left, float right, float halfTop, float cmHeight) {
        float width = right - left;
        float margin = width * 0.05f;
        float xRight = right - margin;
        float shortWidth = width * 0.38f;
        float bandHeight = cmHeight * 0.90f;

        // Dos rectángulos pequeños en los centímetros 2 y 4 del medio bloque.
        for (int i = 0; i < 2; i++) {
            float y = halfTop + cmHeight * (i * 2 + 1) + cmHeight * 0.05f;
            canvas.drawRect(xRight - shortWidth, y, xRight, y + bandHeight, paint);
        }
    }

    private void drawDecimeterNumber(Canvas canvas, int dm, float left, float right, float top, float bottom) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(12, 12, 12));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Math.min(dp(27), (bottom - top) * 0.44f));
        float x = left + (right - left) * 0.54f;
        float y = (top + bottom) / 2f;
        canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)), x, centeredBaseline(y), paint);
    }

    private void drawThreads(Canvas canvas, float cx, float cy, float radius) {
        float staffTop = cy - radius - dp(6);
        float staffBottom = cy + radius + dp(6);

        drawThread(canvas, "LS", upperReading, cx, radius, staffTop, staffBottom, false);
        drawThread(canvas, "LM", middleReading, cx, radius, staffTop, staffBottom, true);
        drawThread(canvas, "LI", lowerReading, cx, radius, staffTop, staffBottom, false);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(dp(0.9f));
        canvas.drawLine(cx, cy - radius * 0.96f, cx, cy + radius * 0.96f, paint);
    }

    private void drawThread(Canvas canvas, String label, double reading, float cx, float radius,
                            float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        float fullLeft = cx - radius + dp(4);
        float fullRight = cx + radius - dp(4);
        float shortLeft = cx - radius * 0.36f;
        float shortRight = cx + radius * 0.36f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(middle ? dp(2.0f) : dp(1.35f));
        if (middle) {
            canvas.drawLine(fullLeft, y, fullRight, y, paint);
        } else {
            canvas.drawLine(shortLeft, y, shortRight, y, paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(26, 26, 26));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(dp(12));
        paint.setTextAlign(Paint.Align.LEFT);
        float labelX = middle ? fullLeft + dp(4) : shortLeft - dp(27);
        canvas.drawText(label, labelX, y - dp(5), paint);
    }

    private float centeredBaseline(float centerY) {
        Paint.FontMetrics metrics = paint.getFontMetrics();
        return centerY - (metrics.ascent + metrics.descent) / 2f;
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double fraction = (visibleMax - reading) / range;
        return (float) (top + fraction * (bottom - top));
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
