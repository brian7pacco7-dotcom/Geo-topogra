# GeoTopo

Versión actual: **1.20.9**

## GPS/GNSS sin bloqueo por satélites

- Mantiene solo dos modos: **Automático: GPS + red** y **Solo satélites GNSS**.
- En la configuración GPS se indica en letras pequeñas:
  - Automático puede usar internet, Wi-Fi o red móvil para ubicar más rápido.
  - Solo satélites GNSS no requiere internet, aunque puede tardar más al iniciar.
- Las primeras coordenadas se muestran aunque la señal todavía sea débil.
- La cantidad de satélites queda como información y ya no bloquea el inicio ni las muestras del promedio.
- La fase previa espera hasta 90 segundos por una lectura GNSS reciente y estable, pero comienza antes si logra buena precisión.
- Una lectura de ±10 m o mejor puede iniciar de inmediato; entre ±10 m y ±25 m se confirma estabilidad con varias lecturas consecutivas.
- Después se ejecutan completos los 10, 20, 30 o 60 segundos seleccionados.
- Durante el promedio se aceptan lecturas GNSS recientes de hasta ±25 m, con ponderación por precisión y descarte de saltos.
- Se conserva la mejor precisión observada y el resultado final queda congelado para guardar.

## Puntos y mapa

- Los puntos GPS y el mapa usan el mismo almacenamiento.
- Se pueden mostrar juntos todos los puntos de un proyecto.
- El mapa ajusta el zoom y mantiene resaltado el punto seleccionado.

## Otras funciones

- Capas de calles, satélite, satélite con nombres y topográfico.
- Búsqueda de lugares y coordenadas.
- Medición de distancia y área con puntos movibles y apariencia configurable.
