# Validación GeoTopo 1.20.9

## Comportamiento esperado del GPS

1. En **Solo satélites GNSS**, cualquier lectura GPS reciente se muestra aunque todavía tenga precisión baja.
2. En **Automático**, la red puede dar una ubicación inicial rápida, pero la preparación del promedio espera lecturas GNSS.
3. El número de satélites visibles o usados se muestra solo como información; no impide iniciar ni aceptar muestras.
4. La búsqueda previa dura como máximo 90 s:
   - con ±10 m o mejor, el promedio puede comenzar de inmediato;
   - con precisión entre ±10 m y ±25 m, se requieren al menos tres lecturas consecutivas estables;
   - si la señal no mejora, aparecen las opciones Seguir esperando, Usar referencia o Cancelar.
5. El tiempo seleccionado de 10, 20, 30 o 60 s empieza después de la fase previa y se ejecuta completo.
6. Durante el promedio se aceptan lecturas GNSS recientes de hasta ±25 m; se descartan lecturas antiguas, saltos bruscos y velocidades incompatibles con un punto fijo.
7. Las lecturas más precisas tienen mayor peso. La precisión final usa el valor conservador entre la mejor precisión reportada y la dispersión del 68 % de las muestras.
8. El resultado queda congelado para que una lectura posterior peor no cambie la coordenada antes de guardarla.

## Textos de ayuda

- Automático: “Puede usar internet, Wi-Fi o red móvil para ubicarte más rápido.”
- Solo satélites GNSS: “No requiere internet; la primera ubicación puede tardar más.”
- Estas explicaciones aparecen únicamente dentro de la configuración GPS.

## Validaciones estructurales

- Se eliminaron las condiciones obligatorias de 6 satélites para iniciar y 5 para promediar.
- Se eliminó el descarte visual de lecturas GPS peores de ±75 m.
- Se mantiene la estructura Gradle, compileSdk 35, targetSdk 35 y MapLibre Android 11.8.0.
- Versión actualizada a 1.20.9.

## Prueba necesaria en teléfono

- Probar al aire libre primero con Solo satélites GNSS y luego con Automático.
- Confirmar que las coordenadas aparecen desde la primera lectura.
- Confirmar que 0 satélites reportados por el sistema no bloquean el proceso.
- Seleccionar 60 s y comprobar que la fase de promedio cuenta 60 s completos después de la búsqueda previa.
- Verificar que el resultado final permanece congelado al abrir Guardar punto.
