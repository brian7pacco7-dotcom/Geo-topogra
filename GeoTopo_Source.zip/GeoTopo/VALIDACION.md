# Validación GeoTopo 1.11

- Código Java compilado con `android.jar` de Android API 35.
- JavaScript de `map.html` validado con `node --check`.
- Cuadro de ajustes GPS reemplazado por diálogo oscuro de diseño propio.
- Opción de promedio de 60 segundos conservada.
- Exportación CSV/KML/KMZ/GPX e importación KML/KMZ implementadas.
- Adjuntar foto, editar y eliminar puntos implementado.
- Reutilización de mosaicos y aceleración WebView implementadas.
- Capa Relieve y acceso externo a Google Earth implementados.
- Última ubicación compartida entre GPS y mapa, con tiempo límite de búsqueda.
- Estructura del ZIP y XML comprobadas.
