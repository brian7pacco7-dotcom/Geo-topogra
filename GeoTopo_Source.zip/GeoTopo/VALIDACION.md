# Validación GeoTopo 1.14

- Añadida `ConverterActivity` y registrada en el manifiesto.
- Añadido acceso al conversor desde la pantalla principal.
- Añadida selección de puntos mediante pulsación prolongada en el mapa.
- Añadida conversión del punto seleccionado a UTM.
- Añadidas acciones de guardar, copiar, compartir, abrir en Maps y medir desde el punto.
- Añadida búsqueda opcional de dirección mediante conexión a internet.
- Añadida edición de vértices por arrastre durante mediciones activas.
- Optimizado el posicionamiento y margen de caché visual de las teselas.
- Todos los archivos Java compilaron conjuntamente contra Android API 35; solo se observaron advertencias de APIs obsoletas ya existentes.
- JavaScript del mapa comprobado con `node --check`.
- XML del manifiesto y recursos comprobado.
- Integridad final del ZIP comprobada.
