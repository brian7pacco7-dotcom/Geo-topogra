# Validación GeoTopo 1.17.0

- Estructura Android y manifest revisados.
- XML validado.
- Archivos Java revisados sintácticamente.
- Conversor ampliado a nueve categorías.
- Factores de conversión revisados usando unidades base SI.
- Temperatura validada con conversiones de referencia: 0 °C = 32 °F, 100 °C = 212 °F y 273.15 K = 0 °C.
- No se modificaron GPS, mapas, brújula, medición ni cálculos topográficos.

Pruebas recomendadas en el teléfono:

1. Abrir cada categoría del conversor.
2. Intercambiar las unidades de origen y destino.
3. Probar valores negativos en temperatura.
4. Copiar el resultado.
5. Confirmar que los menús largos de Área, Distancia y Volumen se desplazan correctamente.
