# Validación GeoTopo 1.20.4

## Cambios aplicados

- Se ocultó la capa `Relieve` del selector de capas.
- Si alguna ruta interna intenta abrir `relief`, la app abre `Topográfico` como respaldo seguro.
- En `Medir área y perímetro` se eliminó el relleno celeste/verdoso del polígono.
- La medición ahora limpia y vuelve a dibujar sus overlays al iniciar una medición nueva y al mover puntos.
- Los puntos de medición se hicieron más pequeños para tapar menos el mapa.
- Se conserva el marcador de ubicación como punto limpio.

## Comportamiento esperado

1. En `Capas` ya no aparece `Relieve`.
2. `Calles y lugares`, `Satélite`, `Satélite + nombres` y `Topográfico` siguen funcionando.
3. En `Medir distancia` solo se ven puntos, línea y etiquetas de tramo.
4. En `Medir área y perímetro` se ve el contorno y las etiquetas, pero sin relleno interior.
5. El botón `← Atrás` elimina únicamente el último punto.
6. Al arrastrar puntos no deberían quedar trazos viejos de la medición anterior.

## Comprobaciones estructurales realizadas

- Estructura Gradle presente.
- `compileSdk 35`, `targetSdk 35` y MapLibre Android 11.8.0 conservados.
- Versión actualizada a 1.20.4.
- ZIP generado nuevamente.

## Prueba final sugerida en teléfono

- Probar cambio de capas.
- Confirmar que `Relieve` ya no aparece.
- Medir distancia, luego área, luego volver a distancia.
- Mover P1/P2/P3 y confirmar que no queden líneas antiguas ni relleno interior.
