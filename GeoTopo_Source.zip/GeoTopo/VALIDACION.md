# Validación GeoTopo 1.18.0

- Se restauraron las entradas principales al visor MapLibre nativo.
- Se conservaron las funciones y categorías del conversor 1.17.0.
- XML del nuevo icono de brújula validado.
- Estructura de llaves y análisis sintáctico Java revisados.
- La brújula se actualiza con el bearing de la cámara y permite restablecer norte arriba.
- La medición recrea marcadores numerados y etiquetas por tramo al agregar, deshacer o limpiar puntos.
- Satélite e híbrido fijan `maxzoom` de fuente en 17 para permitir overzoom sin solicitar teselas inexistentes.

Pruebas recomendadas en el teléfono:

1. Abrir el mapa desde Inicio, GPS y un punto guardado; debe aparecer el visor MapLibre moderno.
2. Girar el mapa con dos dedos y confirmar que la aguja mantiene la dirección del norte.
3. Tocar la brújula y comprobar que el mapa vuelve a norte arriba.
4. Medir distancia y área; comprobar P1, P2, P3 y las distancias T1, T2, etc.
5. Ampliar Satélite y Satélite + nombres hasta el máximo y confirmar que no aparece “Map data not yet available”.
6. Revisar que el conversor mantenga Área, Distancia, Peso, Volumen, Energía, Temperatura, Velocidad, Potencia y Ángulo y pendiente.
