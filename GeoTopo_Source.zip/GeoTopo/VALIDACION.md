# Validación GeoTopo 1.20.2

## Corrección aplicada al fallo de GitHub Actions

- Eliminado `MarkerOptions.draggable(true)`, que no existe en MapLibre Android 11.8.0.
- Eliminado el listener `MapLibreMap.OnMarkerDragListener`, que tampoco forma parte de esa API.
- El arrastre se implementó con eventos táctiles de `MapView` y conversión entre pantalla y coordenadas mediante `Projection`.
- No quedan referencias a `draggable(true)`, `OnMarkerDragListener` ni métodos `onMarkerDrag*`.

## Comportamiento esperado

1. En Medir, tocar un punto P1, P2, P3… lo selecciona.
2. Arrastrar ese punto actualiza su coordenada.
3. Al moverlo se recalculan distancias, perímetro y área.
4. Mientras se arrastra, los gestos del mapa se bloquean; al soltar se restauran.
5. El botón `← Atrás` elimina únicamente el último punto.

## Comprobaciones estructurales realizadas

- Estructura Gradle presente.
- `compileSdk 35`, `targetSdk 35` y MapLibre Android 11.8.0 conservados.
- Versión actualizada a 1.20.2.
- ZIP probado con `zip -T`.

## Prueba final necesaria

Ejecutar el workflow `Build APK from ZIP`. Después, probar en el teléfono el arrastre de puntos en distancia y área, además de zoom, giro y cambio de capas.
