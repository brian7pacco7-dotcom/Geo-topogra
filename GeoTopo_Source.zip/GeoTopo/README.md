# GeoTopo 1.2

Aplicación Android de apoyo para cálculos topográficos, orientación, GPS y mapas.

## Funciones principales

- Azimut, rumbo, contraazimut y contrarrumbo.
- Coordenadas parciales, distancias, pendiente y desnivel.
- Distancia por dos hilos.
- Poligonal cerrada con corrección, coordenadas, área, perímetro y gráfico.
- Nivelación simple y nivelación con tres hilos.
- Brújula magnética cuando el teléfono tiene magnetómetro.
- Dirección de desplazamiento por GPS y orientación mediante dos puntos cuando no hay magnetómetro.
- Registro GPS con latitud, longitud, UTM, altitud GNSS, precisión, velocidad, rumbo y satélites.
- Promedio de lecturas GPS de 10, 20 o 30 segundos.
- Proyectos y puntos guardados.
- Exportación de puntos en CSV, KML y GPX.
- Mapa online estándar, satelital, híbrido y topográfico.
- Cartografía vectorial offline descargable por área visible o búsqueda de provincia/departamento.
- Medición de distancias y áreas en el mapa.

## Importante

- El GPS y las calculadoras funcionan sin internet.
- El mapa satelital requiere internet.
- Los mapas offline son vectoriales; no incluyen imágenes satelitales.
- Internet puede acelerar la obtención inicial de ubicación, pero no convierte el GPS interno del teléfono en un equipo topográfico centimétrico.
- Para precisión centimétrica se requiere un receptor GNSS RTK externo y correcciones apropiadas.

## Compilar con GitHub Actions

El repositorio debe contener este proyecto dentro del archivo `GeoTopo_Source.zip`, junto al workflow `.github/workflows/build-apk.yml` del repositorio.

1. Abre la pestaña **Actions**.
2. Ejecuta **Build APK from ZIP**.
3. Espera a que la compilación termine correctamente.
4. Descarga el artefacto **GeoTopo-debug-apk**.

El APK generado es una versión de depuración para instalación y pruebas.
