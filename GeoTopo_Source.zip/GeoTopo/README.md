# GeoTopo 1.11

Aplicación Android de apoyo para cálculos topográficos, GPS/GNSS y cartografía online/offline.

## Cambios principales

- Se reemplazó el cuadro blanco de **GPS y precisión** por un diálogo propio compatible con tema oscuro. Las opciones de modo y promedio de 10, 20, 30 y 60 segundos quedan siempre legibles.
- El mapa usa aceleración por hardware y reutiliza mosaicos visibles para reducir recargas al mover o ampliar.
- Se conserva el zoom con dos dedos, doble toque y desplazamiento con transformación fluida.
- Se comparte entre GPS y mapa la última ubicación válida, de modo que el mapa puede centrarla inmediatamente mientras busca una lectura nueva.
- Se añadió un límite de espera de 15 segundos para evitar el mensaje de búsqueda indefinido.
- Nueva capa **Relieve**, útil para interpretar montañas y pendientes. Es sombreado 2D, no un modelo 3D topográfico.
- Acceso para abrir la zona actual en Google Earth, donde pueden estar disponibles vistas 3D e imágenes históricas según el servicio y la zona.
- Exportación de puntos en CSV, KML, KMZ y GPX.
- Importación de puntos desde KML y KMZ.
- Los puntos guardados admiten descripción y foto adjunta mediante el selector de Android.
- Los puntos pueden editarse, abrirse en el mapa, mostrar su foto o eliminarse individualmente.
- Opción para compartir un resumen del proyecto mediante el menú de compartir de Android.
- Se mantienen mapas estándar, satélite, híbrido, topográfico y mapas vectoriales descargados sin internet.

## Aclaraciones

- La fotografía satelital necesita internet. La descarga offline guarda cartografía vectorial, no imágenes satelitales.
- La capa Relieve no es una vista 3D real. La opción Google Earth abre un servicio externo para funciones visuales avanzadas.
- La precisión GPS indicada es una estimación del teléfono y no sustituye un receptor GNSS RTK.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions y descarga el artefacto `GeoTopo-debug-apk`.
