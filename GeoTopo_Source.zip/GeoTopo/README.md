# GeoTopo

Versión actual: **1.20.4**

## Ajustes incluidos

- Mapa nativo con capas: Calles y lugares, Satélite, Satélite + nombres y Topográfico.
- Buscador de lugar o coordenadas.
- Medición por distancia y área con puntos movibles.
- Punto de ubicación limpio estilo GPS básico.

## Ajustes recientes

- Se retiró la capa `Relieve` porque en varias zonas devolvía mosaicos vacíos.
- Se quitó el relleno celeste/verdoso de las mediciones de área.
- Se redujo el tamaño visual de los puntos de medición.
- Se reforzó la limpieza/redibujo de líneas al iniciar una medición nueva o mover puntos.
