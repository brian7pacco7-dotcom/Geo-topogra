# GeoTopo 1.17.0

Aplicación Android de cálculos topográficos, GPS/GNSS, mapas, medición y conversión de unidades.

## Cambios principales

- Visor principal con MapLibre Native y aceleración por GPU.
- Capas de calles, satélite, satélite con nombres, topográfico y relieve.
- Medición referencial de distancia, área y perímetro sobre el mapa.
- Puntos numerados y visor de cartografía descargada.
- Conversor de unidades ampliado y funcional sin internet.

## Categorías del conversor

- Área
- Distancia
- Peso
- Volumen
- Energía
- Temperatura
- Velocidad
- Potencia
- Ángulo y pendiente

La temperatura convierte entre Celsius, Fahrenheit y Kelvin mediante fórmulas con desplazamiento, no mediante una regla de tres incorrecta.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions.
