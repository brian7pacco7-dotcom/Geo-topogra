# GeoTopo 1.20.0

Aplicación Android de cálculos topográficos, GPS/GNSS, mapas, medición y conversión de unidades.

## Cambios principales

- El proyecto conserva únicamente el visor moderno MapLibre Native, con aceleración por GPU, giro con dos dedos y zoom fluido.
- Se eliminó por completo el visor antiguo basado en WebView (`LegacyMapActivity` y `map.html`) para evitar que vuelva a abrirse por error.
- La lupa superior permite buscar ciudades, distritos, comunidades, calles y coordenadas. La consulta se ejecuta solo al pulsar **Buscar**, no como autocompletado continuo.
- La capa **Relieve** combina una base física del terreno, sombreado de elevación más marcado y nombres superpuestos.
- Las mediciones conservan P1, P2, P3 y las distancias, pero usan puntos y etiquetas compactos, líneas más finas y un relleno azul suave.
- Se mantienen los conversores ampliados de la versión anterior.

## Categorías del conversor

- Área
- Distancia
- Peso
- Volumen
- Energía
- Temperatura
- Velocidad
- Potencia
- Ángulo y pendiente

La temperatura convierte entre Celsius, Fahrenheit y Kelvin mediante fórmulas con desplazamiento.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions.

