# GeoTopo 1.15

Aplicación Android de cálculos topográficos, GPS/GNSS, mapas, medición y conversión de unidades.

## Cambios de esta versión

- Visor principal reconstruido con **MapLibre Native** y aceleración por GPU.
- Zoom con dos dedos, desplazamiento e inercia nativos.
- Capas: calles y lugares, satélite, satélite con nombres, topográfico y relieve.
- Los mapas offline existentes siguen disponibles mediante el visor de cartografía descargada.
- Pulsación prolongada sobre el mapa para obtener lugar, dirección, latitud, longitud y UTM.
- Guardar, copiar, compartir y medir desde un punto seleccionado.
- Medición referencial de distancia, área y perímetro sobre el mapa.
- Ubicación actual con nombre del lugar, precisión y círculo de incertidumbre.
- Conversor corregido con selectores visibles y frase clara de la conversión activa.
- GPS: separación visible entre la búsqueda de señal y el tiempo de promedio elegido.
- Búsqueda inicial GNSS limitada a 30 segundos; después permite seguir esperando, cancelar o usar posición aproximada.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions.

## Corrección 1.15.1

- AndroidX habilitado para compilar correctamente MapLibre.
- Jetifier activado para compatibilidad de dependencias.
- Código de versión incrementado para permitir instalar la actualización.
