# GeoTopo 1.18.0

Aplicación Android de cálculos topográficos, GPS/GNSS, mapas, medición y conversión de unidades.

## Cambios principales

- El visor principal vuelve a usar MapLibre Native con aceleración por GPU, giro con dos dedos y zoom fluido.
- La barra inferior conserva el diseño redondeado y recupera los iconos gráficos de Ubicación, Capas, Puntos, Medir y Descargar.
- La brújula es una aguja moderna que gira con la orientación del mapa; al tocarla vuelve al norte.
- La medición muestra P1, P2, P3... y la distancia de cada tramo.
- Satélite e híbrido usan el último nivel real disponible y continúan ampliando sin mostrar el mosaico en inglés de Esri.
- Se mantienen los conversores ampliados de la versión anterior.

## Categorías del conversor

- Área
- Distancia
- Peso
- Volumen
- Energía
- Temperatura
- Velocidad
- Potencia
- Ángulo y pendiente

La temperatura convierte entre Celsius, Fahrenheit y Kelvin mediante fórmulas con desplazamiento.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions.
