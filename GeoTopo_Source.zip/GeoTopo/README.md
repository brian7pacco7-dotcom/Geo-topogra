# GeoTopo 1.14

Aplicación Android de apoyo para cálculos topográficos, GPS/GNSS y cartografía online/offline.

## Conversor de unidades

Nueva herramienta independiente, disponible desde la pantalla principal:

- Longitud: mm, cm, m, km, pulgadas, pies, yardas y millas.
- Área: mm², cm², m², hectáreas, km², pies² y acres.
- Volumen: mL, L, cm³, m³, pies³ y galones US.
- Velocidad: m/s, km/h, pies/s y mph.
- Ángulo y pendiente: grados, radianes, grados centesimales y porcentaje.
- Conversión instantánea mientras se escribe, intercambio de unidades y copia del resultado.
- Funciona sin internet y no incluye potencia ni energía.

## Selección de puntos en el mapa

- Mantén pulsado cualquier lugar del mapa para crear un marcador.
- La ficha muestra latitud, longitud y coordenadas UTM.
- Con internet intenta obtener la dirección; sin internet las coordenadas siguen disponibles.
- Permite guardar el punto en los proyectos GPS, copiarlo, compartirlo, abrirlo en Maps o comenzar una medición desde allí.

## Medición mejorada

- Los vértices de una medición activa pueden arrastrarse para corregir su posición.
- Se mantiene la opción de deshacer, finalizar y limpiar.
- Las mediciones tocando el mapa continúan identificadas como referenciales.

## Rendimiento del mapa

- Las teselas se reposicionan mediante transformaciones aceleradas en vez de recalcular su diseño en cada movimiento.
- Se conserva un margen mayor de teselas alrededor de la pantalla para reducir recargas al desplazar o ampliar.
- El zoom con dos dedos mantiene la vista escalada durante el gesto y actualiza las teselas al finalizar.

## Promedio GPS

Se mantienen las opciones de 10, 20, 30 y 60 segundos, junto con la fase de preparación que espera una lectura GNSS válida antes de iniciar el conteo.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions y descarga el artefacto generado.
