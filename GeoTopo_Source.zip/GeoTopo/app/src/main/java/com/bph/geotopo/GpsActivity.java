package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.GnssStatus;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.Window;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class GpsActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private static final int REQ_LOCATION = 9201;
    private static final int REQ_EXPORT = 9202;
    private static final int REQ_IMPORT = 9203;
    private static final int REQ_PHOTO = 9204;
    private static final long DEFAULT_AVERAGE_DURATION_MS = 20000L;
    private static final float MAX_AVERAGE_ACCURACY_M = 50f;
    private static final float MAX_GPS_ONLY_DISPLAY_ACCURACY_M = 75f;
    private static final long MAX_LIVE_LOCATION_AGE_MS = 20000L;
    private static final long MAX_AVERAGE_FIX_WAIT_MS = 30000L;
    private static final float MAX_APPROXIMATE_AVERAGE_ACCURACY_M = 200f;

    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;
    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68), Color.rgb(158, 169, 181), Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentColor;
    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;

    private LocationManager locationManager;
    private Location currentLocation;
    private boolean gpsRunning = false;
    private boolean useNetworkProvider = true;
    private long averageDurationMs = DEFAULT_AVERAGE_DURATION_MS;
    private int satellitesVisible = 0;
    private int satellitesUsed = 0;
    private boolean gnssCallbackRegistered = false;
    private GnssStatus.Callback gnssStatusCallback;
    private boolean averaging = false;
    private long averagingEndsAt = 0L;
    private final List<Location> averagingSamples = new ArrayList<>();
    private int averagingRejectedSamples = 0;
    private boolean averagingWaitingForFix = false;
    private boolean averagingApproximateMode = false;
    private long averagingFixDeadline = 0L;
    private boolean pendingAverageStart = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<GpsPoint> points = new ArrayList<>();
    private String pendingExportType;
    private String pendingPhotoUri = "";
    private TextView photoStatusView;

    private TextView statusView;
    private TextView qualityView;
    private TextView latitudeView;
    private TextView longitudeView;
    private TextView altitudeView;
    private TextView accuracyView;
    private TextView speedView;
    private TextView bearingView;
    private TextView timeView;
    private TextView providerView;
    private TextView utmZoneView;
    private TextView utmEastView;
    private TextView utmNorthView;
    private TextView savedCountView;
    private TextView satellitesView;
    private TextView locationModeView;
    private TextView readingAgeView;
    private EditText pointNameInput;
    private EditText projectNameInput;
    private EditText pointDescriptionInput;
    private Button averageButton;

    private final Runnable averagingTicker = new Runnable() {
        @Override
        public void run() {
            if (!averaging) return;
            if (averagingWaitingForFix) {
                long waitRemaining = averagingFixDeadline - System.currentTimeMillis();
                if (waitRemaining <= 0L) {
                    showAverageFixTimeoutDialog();
                    return;
                }
                int seconds = (int) Math.ceil(waitRemaining / 1000.0);
                setStatus("Fase 1 de 2 · Búsqueda previa de señal GPS/GNSS (máx. 30 s): " + seconds + " s restantes · "
                        + satellitesUsed + " satélites usados. Luego sí se promediará durante "
                        + (averageDurationMs / 1000L) + " s.", Color.rgb(255, 171, 0));
                handler.postDelayed(this, 500L);
                return;
            }
            long remaining = averagingEndsAt - System.currentTimeMillis();
            if (remaining <= 0) {
                finishAveraging();
                return;
            }
            int seconds = (int) Math.ceil(remaining / 1000.0);
            String mode = averagingApproximateMode ? "aproximado" : "GPS/GNSS";
            setStatus("Fase 2 de 2 · Promediando " + mode + ": " + seconds + " s · "
                    + averagingSamples.size() + " válidas · " + averagingRejectedSamples + " descartadas", Color.rgb(255, 171, 0));
            handler.postDelayed(this, 500L);
        }
    };

    private final Runnable readingAgeTicker = new Runnable() {
        @Override
        public void run() {
            updateReadingAge();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        loadPoints();
        loadGpsSettings();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshGpsProviderStatus();
        handler.removeCallbacks(readingAgeTicker);
        handler.post(readingAgeTicker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(readingAgeTicker);
        cancelAveraging(false);
        stopLocationUpdates(false);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopLocationUpdates(false);
        super.onDestroy();
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        int accentIndex = sp.getInt("accent", 0);
        int safeAccentIndex = ((accentIndex % ACCENTS.length) + ACCENTS.length) % ACCENTS.length;
        accentColor = ACCENTS[safeAccentIndex];

        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(94, 101, 112);
            inputFillColor = Color.rgb(250, 251, 253);
            inputStrokeColor = Color.rgb(196, 202, 212);
            resultFillColor = Color.rgb(235, 249, 240);
            resultStrokeColor = Color.rgb(0, 150, 80);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputFillColor = Color.rgb(10, 29, 45);
            inputStrokeColor = Color.rgb(92, 112, 132);
            resultFillColor = Color.rgb(9, 50, 42);
            resultStrokeColor = Color.rgb(0, 210, 125);
        }
    }

    private void loadGpsSettings() {
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        useNetworkProvider = sp.getBoolean("use_network_provider", true);
        long saved = sp.getLong("average_duration_ms", DEFAULT_AVERAGE_DURATION_MS);
        averageDurationMs = saved == 10000L || saved == 20000L || saved == 30000L || saved == 60000L ? saved : DEFAULT_AVERAGE_DURATION_MS;
    }

    private void saveGpsSettings() {
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putBoolean("use_network_provider", useNetworkProvider)
                .putLong("average_duration_ms", averageDurationMs)
                .apply();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(28));
        content.setBackgroundColor(bgColor);

        content.addView(mapEntryCard());
        content.addView(liveGpsCard());
        content.addView(savePointCard());
        content.addView(exportCard());
        content.addView(warningCard());

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        updateSavedCount();
        updateDisplay(null);
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(12), dp(14), dp(12));
        bar.setBackgroundColor(appBarColor);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(40);
        back.setGravity(Gravity.CENTER);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("GPS y puntos", 23, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView subtitle = text("GPS/GNSS y puntos topográficos", 13, false);
        subtitle.setTextColor(Color.rgb(193, 218, 240));
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    private View mapEntryCard() {
        LinearLayout box = card();
        box.addView(sectionTitle("Mapa y trabajo de campo"));
        box.addView(small("Visualiza tu ubicación y los puntos guardados en el mapa moderno. Satélite, relieve y búsqueda de lugares usan internet."));
        Button openMap = button("Abrir mapa topográfico");
        openMap.setOnClickListener(v -> openGeoTopoMap());
        box.addView(openMap);
        return box;
    }

    private View liveGpsCard() {
        LinearLayout box = card();
        box.addView(sectionTitle("Tu ubicación actual"));
        box.addView(small("Sí: estos datos corresponden a la posición actual del teléfono. Pulsa Iniciar GPS y espera una lectura reciente antes de guardar."));

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        locationModeView = valueBox(useNetworkProvider ? "Automático: GPS + red" : "Solo GPS/GNSS");
        modeRow.addView(locationModeView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button gpsSettings = button("⚙ Precisión");
        gpsSettings.setOnClickListener(v -> showGpsSettingsDialog());
        modeRow.addView(gpsSettings, new LinearLayout.LayoutParams(dp(132), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(modeRow);

        statusView = resultBox("GPS detenido. Esperando lectura reciente");
        box.addView(statusView);
        qualityView = resultBox("Calidad: sin lectura");
        box.addView(qualityView);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button start = button("Iniciar GPS");
        start.setOnClickListener(v -> startGps());
        controls.addView(start, weightParams());
        Button stop = button("Detener");
        stop.setOnClickListener(v -> {
            cancelAveraging(false);
            stopLocationUpdates(true);
        });
        controls.addView(stop, weightParams());
        averageButton = button("Promediar " + (averageDurationMs / 1000L) + " s");
        averageButton.setOnClickListener(v -> startAveraging());
        controls.addView(averageButton, weightParams());
        box.addView(controls);

        latitudeView = valueBox("Sin lectura");
        longitudeView = valueBox("Sin lectura");
        box.addView(twoValues("Latitud", latitudeView, "Longitud", longitudeView));

        utmEastView = valueBox("Sin lectura");
        utmNorthView = valueBox("Sin lectura");
        box.addView(twoValues("Este UTM", utmEastView, "Norte UTM", utmNorthView));

        utmZoneView = valueBox("Sin lectura");
        altitudeView = valueBox("Sin lectura");
        box.addView(twoValues("Zona UTM", utmZoneView, "Altitud GNSS", altitudeView));

        accuracyView = valueBox("Sin lectura");
        speedView = valueBox("Sin lectura");
        box.addView(twoValues("Precisión estimada", accuracyView, "Velocidad", speedView));

        bearingView = valueBox("Sin lectura");
        providerView = valueBox("Sin lectura");
        box.addView(twoValues("Rumbo de movimiento", bearingView, "Proveedor", providerView));

        satellitesView = valueBox("0 / 0");
        box.addView(labeledValue("Satélites visibles / usados", satellitesView));

        timeView = valueBox("Sin lectura reciente");
        box.addView(labeledValue("Última lectura", timeView));
        readingAgeView = small("Altitud, velocidad y rumbo son útiles, pero el teléfono no siempre los reporta. Si aún no hay lectura válida, verás textos claros en vez de rayas.");
        box.addView(readingAgeView);
        return box;
    }

    private View savePointCard() {
        LinearLayout box = card();
        box.addView(sectionTitle("Guardar punto"));
        box.addView(small("El punto conserva latitud, longitud, UTM, altitud, precisión, velocidad, rumbo, proveedor y fecha. Si algún dato no lo reporta el teléfono, se guardará como no disponible."));

        projectNameInput = edit("Ejemplo: Levantamiento terreno A");
        projectNameInput.setText(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString("current_project", "Proyecto general"));
        box.addView(labeledInput("Proyecto", projectNameInput));

        pointNameInput = edit("P1");
        pointNameInput.setText(nextPointName());
        pointDescriptionInput = edit("Ejemplo: esquina norte del terreno");
        pointDescriptionInput.setSingleLine(false);
        pointDescriptionInput.setMinLines(2);
        pointDescriptionInput.setMaxLines(4);
        pointDescriptionInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(labeledInput("Nombre del punto", pointNameInput));
        box.addView(labeledInput("Descripción opcional", pointDescriptionInput));

        LinearLayout photoRow = new LinearLayout(this);
        photoRow.setOrientation(LinearLayout.HORIZONTAL);
        Button photo = button("Agregar foto");
        photo.setOnClickListener(v -> choosePointPhoto());
        photoRow.addView(photo, weightParams());
        Button removePhoto = button("Quitar foto");
        removePhoto.setOnClickListener(v -> {
            pendingPhotoUri = "";
            if (photoStatusView != null) photoStatusView.setText("Sin foto adjunta");
        });
        photoRow.addView(removePhoto, weightParams());
        box.addView(photoRow);
        photoStatusView = small("Sin foto adjunta");
        box.addView(photoStatusView);

        Button save = button("Tomar y guardar punto");
        save.setOnClickListener(v -> saveCurrentPoint());
        box.addView(save);

        savedCountView = resultBox("Puntos guardados: 0");
        box.addView(savedCountView);
        Button viewPoints = button("Ver puntos guardados");
        viewPoints.setOnClickListener(v -> showPointsDialog());
        box.addView(viewPoints);
        return box;
    }

    private View exportCard() {
        LinearLayout box = card();
        box.addView(sectionTitle("Archivos y proyectos"));
        box.addView(small("Exporta para Excel, Google Earth y aplicaciones GPS. También puedes importar KML/KMZ y compartir un resumen del proyecto."));

        LinearLayout exportRow1 = new LinearLayout(this);
        exportRow1.setOrientation(LinearLayout.HORIZONTAL);
        Button csv = button("CSV");
        csv.setOnClickListener(v -> beginExport("csv"));
        exportRow1.addView(csv, weightParams());
        Button kml = button("KML");
        kml.setOnClickListener(v -> beginExport("kml"));
        exportRow1.addView(kml, weightParams());
        Button kmz = button("KMZ");
        kmz.setOnClickListener(v -> beginExport("kmz"));
        exportRow1.addView(kmz, weightParams());
        Button gpx = button("GPX");
        gpx.setOnClickListener(v -> beginExport("gpx"));
        exportRow1.addView(gpx, weightParams());
        box.addView(exportRow1);

        LinearLayout projectRow = new LinearLayout(this);
        projectRow.setOrientation(LinearLayout.HORIZONTAL);
        Button importButton = button("Importar KML/KMZ");
        importButton.setOnClickListener(v -> beginImport());
        projectRow.addView(importButton, weightParams());
        Button share = button("Compartir proyecto");
        share.setOnClickListener(v -> shareProjectSummary());
        projectRow.addView(share, weightParams());
        box.addView(projectRow);

        LinearLayout utilityRow = new LinearLayout(this);
        utilityRow.setOrientation(LinearLayout.HORIZONTAL);
        Button map = button("Mapa de GeoTopo");
        map.setOnClickListener(v -> openGeoTopoMap());
        utilityRow.addView(map, weightParams());
        Button copy = button("Copiar coordenadas");
        copy.setOnClickListener(v -> copyCurrentCoordinates());
        utilityRow.addView(copy, weightParams());
        box.addView(utilityRow);
        return box;
    }

    private View warningCard() {
        LinearLayout box = card();
        box.addView(sectionTitle("Límite de precisión"));
        TextView warning = small("La precisión mostrada es una estimación del teléfono. Guardar varias lecturas o usar internet no convierte el celular en un equipo RTK. Para replanteos, linderos o trabajos centimétricos se necesita un receptor GNSS RTK externo y control topográfico.");
        warning.setTextColor(Color.rgb(255, 171, 0));
        box.addView(warning);
        return box;
    }

    private void showGpsSettingsDialog() {
        Dialog dialog = new Dialog(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(16), dp(20), dp(14));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(cardColor);
        panelBg.setCornerRadius(dp(22));
        panelBg.setStroke(dp(1), inputStrokeColor);
        panel.setBackground(panelBg);

        TextView title = new TextView(this);
        title.setText("GPS y precisión");
        title.setTextColor(textColor);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        panel.addView(title);

        TextView explanation = new TextView(this);
        explanation.setText("Automático combina GPS/GNSS con ubicación asistida. Solo GPS usa satélites y también funciona sin internet.");
        explanation.setTextColor(subTextColor);
        explanation.setTextSize(13);
        explanation.setPadding(0, dp(6), 0, dp(14));
        panel.addView(explanation);

        TextView modeTitle = new TextView(this);
        modeTitle.setText("Modo de ubicación");
        modeTitle.setTextColor(textColor);
        modeTitle.setTextSize(15);
        modeTitle.setTypeface(Typeface.DEFAULT_BOLD);
        panel.addView(modeTitle);

        RadioGroup modeGroup = new RadioGroup(this);
        RadioButton automatic = dialogRadio("Automático: GPS + ubicación asistida", textColor);
        RadioButton satelliteOnly = dialogRadio("Solo GPS/GNSS satelital", textColor);
        modeGroup.addView(automatic);
        modeGroup.addView(satelliteOnly);
        (useNetworkProvider ? automatic : satelliteOnly).setChecked(true);
        panel.addView(modeGroup);

        TextView avgTitle = new TextView(this);
        avgTitle.setText("Tiempo de promedio");
        avgTitle.setTextColor(textColor);
        avgTitle.setTextSize(15);
        avgTitle.setTypeface(Typeface.DEFAULT_BOLD);
        avgTitle.setPadding(0, dp(14), 0, 0);
        panel.addView(avgTitle);

        RadioGroup averageGroup = new RadioGroup(this);
        RadioButton ten = dialogRadio("10 segundos · rápido", textColor);
        RadioButton twenty = dialogRadio("20 segundos · normal", textColor);
        RadioButton thirty = dialogRadio("30 segundos · recomendado", textColor);
        RadioButton sixty = dialogRadio("60 segundos · mayor estabilidad", textColor);
        averageGroup.addView(ten);
        averageGroup.addView(twenty);
        averageGroup.addView(thirty);
        averageGroup.addView(sixty);
        if (averageDurationMs == 10000L) ten.setChecked(true);
        else if (averageDurationMs == 30000L) thirty.setChecked(true);
        else if (averageDurationMs == 60000L) sixty.setChecked(true);
        else twenty.setChecked(true);
        panel.addView(averageGroup);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END);
        actions.setPadding(0, dp(12), 0, 0);
        Button cancel = new Button(this);
        cancel.setText("Cancelar");
        cancel.setTextColor(accentColor);
        cancel.setTextSize(14);
        cancel.setBackgroundColor(Color.TRANSPARENT);
        Button save = new Button(this);
        save.setText("Guardar");
        save.setTextColor(accentColor);
        save.setTextSize(14);
        save.setTypeface(Typeface.DEFAULT_BOLD);
        save.setBackgroundColor(Color.TRANSPARENT);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(48), 1f));
        panel.addView(actions);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(panel);
        dialog.setContentView(scroll);
        dialog.setCancelable(true);
        cancel.setOnClickListener(v -> dialog.dismiss());
        save.setOnClickListener(v -> {
            boolean previousNetworkMode = useNetworkProvider;
            useNetworkProvider = automatic.isChecked();
            averageDurationMs = ten.isChecked() ? 10000L : (thirty.isChecked() ? 30000L : (sixty.isChecked() ? 60000L : 20000L));
            saveGpsSettings();
            if (locationModeView != null) locationModeView.setText(useNetworkProvider ? "Automático: GPS + red" : "Solo GPS/GNSS");
            refreshAverageButtonState();

            if (previousNetworkMode && !useNetworkProvider && currentLocation != null
                    && !LocationManager.GPS_PROVIDER.equals(currentLocation.getProvider())) {
                currentLocation = null;
                updateDisplay(null);
                setStatus("Modo Solo GPS/GNSS: se descartó la ubicación aproximada de red.", Color.rgb(255, 171, 0));
            }

            if (gpsRunning || previousNetworkMode != useNetworkProvider) {
                stopLocationUpdates(false);
                startGps();
            } else {
                refreshAverageButtonState();
            }
            dialog.dismiss();
        });
        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.92f), ViewGroup.LayoutParams.WRAP_CONTENT);
                window.setDimAmount(0.65f);
            }
        });
        dialog.show();
    }

    private RadioButton dialogRadio(String label, int color) {
        RadioButton button = new RadioButton(this);
        button.setText(label);
        button.setTextColor(color);
        button.setTextSize(14);
        button.setPadding(dp(2), dp(5), dp(2), dp(5));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            int[][] states = new int[][]{
                    new int[]{android.R.attr.state_checked},
                    new int[]{-android.R.attr.state_checked}
            };
            int[] colors = new int[]{accentColor, Color.rgb(105, 110, 118)};
            button.setButtonTintList(new ColorStateList(states, colors));
        }
        return button;
    }

    private void registerGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || gnssCallbackRegistered) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        if (gnssStatusCallback == null) {
            gnssStatusCallback = new GnssStatus.Callback() {
                @Override
                public void onSatelliteStatusChanged(GnssStatus status) {
                    int visible = status.getSatelliteCount();
                    int used = 0;
                    for (int i = 0; i < visible; i++) if (status.usedInFix(i)) used++;
                    satellitesVisible = visible;
                    satellitesUsed = used;
                    if (satellitesView != null) satellitesView.setText(visible + " / " + used);
                }

                @Override
                public void onStopped() {
                    satellitesVisible = 0;
                    satellitesUsed = 0;
                    if (satellitesView != null) satellitesView.setText("0 / 0");
                }
            };
        }
        try {
            locationManager.registerGnssStatusCallback(gnssStatusCallback, handler);
            gnssCallbackRegistered = true;
        } catch (Exception ignored) {
            gnssCallbackRegistered = false;
        }
    }

    private void unregisterGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || !gnssCallbackRegistered || gnssStatusCallback == null) return;
        try { locationManager.unregisterGnssStatusCallback(gnssStatusCallback); } catch (Exception ignored) {}
        gnssCallbackRegistered = false;
    }

    private void startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (locationManager == null) {
            setStatus("Servicio de ubicación no disponible", Color.rgb(244, 67, 54));
            return;
        }
        boolean gpsEnabled;
        try {
            gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) {
            gpsEnabled = false;
        }
        if (!gpsEnabled) {
            setStatus("GPS desactivado. Actívalo en el celular.", Color.rgb(244, 67, 54));
            new AlertDialog.Builder(this)
                    .setTitle("Activar ubicación")
                    .setMessage("La función necesita que el GPS o la ubicación del teléfono estén activados.")
                    .setPositiveButton("Abrir ajustes", (d, w) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }

        try {
            stopLocationUpdates(false);
            currentLocation = null;
            gpsRunning = true;
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0.5f, this);
            try {
                if (useNetworkProvider && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 1.0f, this);
                }
            } catch (Exception ignored) {
                // El GPS satelital sigue funcionando aunque el proveedor de red no exista.
            }
            registerGnssStatus();
            Location lastGps = safeLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location lastNetwork = useNetworkProvider ? safeLastKnownLocation(LocationManager.NETWORK_PROVIDER) : null;
            Location best = useNetworkProvider ? chooseBetter(lastGps, lastNetwork) : lastGps;
            if (best != null
                    && System.currentTimeMillis() - best.getTime() <= 120000L
                    && isAllowedByLocationMode(best)) {
                onLocationChanged(best);
            } else {
                currentLocation = null;
                updateDisplay(null);
            }
            setStatus(useNetworkProvider
                    ? "Buscando una ubicación rápida y luego una lectura GPS/GNSS más precisa…"
                    : "Buscando señal GPS/GNSS satelital…", accentColor);
        } catch (SecurityException e) {
            setStatus("Permiso de ubicación insuficiente. Elige ubicación precisa.", Color.rgb(244, 67, 54));
        } catch (Exception e) {
            setStatus("No se pudo iniciar el GPS: " + safeMessage(e), Color.rgb(244, 67, 54));
        }
    }

    private void stopLocationUpdates(boolean showMessage) {
        if (locationManager != null) {
            try {
                locationManager.removeUpdates(this);
            } catch (SecurityException ignored) {
            }
        }
        unregisterGnssStatus();
        gpsRunning = false;
        if (showMessage) setStatus("GPS detenido. La última lectura queda visible.", subTextColor);
    }

    private void refreshGpsProviderStatus() {
        if (gpsRunning || locationManager == null || statusView == null) return;
        try {
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                setStatus("GPS desactivado", Color.rgb(244, 67, 54));
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null || !isAllowedByLocationMode(location)) return;

        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        long ageMs = Math.max(0L, System.currentTimeMillis() - timestamp);
        if (ageMs > MAX_LIVE_LOCATION_AGE_MS) return;

        boolean gpsProvider = LocationManager.GPS_PROVIDER.equals(location.getProvider());
        if (!useNetworkProvider && gpsProvider
                && location.hasAccuracy()
                && location.getAccuracy() > MAX_GPS_ONLY_DISPLAY_ACCURACY_M) {
            setStatus("Señal GPS/GNSS todavía débil (± "
                    + String.format(Locale.US, "%.1f", location.getAccuracy())
                    + " m). Espera en un lugar despejado.", Color.rgb(244, 67, 54));
            refreshAverageButtonState();
            return;
        }

        if (currentLocation == null || isBetterLocation(location, currentLocation)) {
            currentLocation = new Location(location);
            saveLastLocation(currentLocation);
            updateDisplay(currentLocation);
        }

        if (averaging) {
            if (averagingWaitingForFix) {
                if (isPreciseGnssForAverage(location)) {
                    beginAverageCountdown(location, false);
                } else {
                    averagingRejectedSamples++;
                }
            } else if (isSampleAllowedForCurrentAverage(location)) {
                averagingSamples.add(new Location(location));
            } else {
                averagingRejectedSamples++;
            }
        }

        if (!averaging) {
            String source = gpsProvider ? "GPS/GNSS" : "red (aproximada)";
            String accuracy = location.hasAccuracy()
                    ? String.format(Locale.US, "± %.1f m", location.getAccuracy())
                    : "sin precisión";
            int color = isPreciseGnssForAverage(location) ? accentColor : Color.rgb(255, 171, 0);
            String suffix = isPreciseGnssForAverage(location)
                    ? ""
                    : " · todavía no válida para promedio GPS";
            setStatus("Ubicación por " + source + " · " + accuracy + suffix, color);
        }
        refreshAverageButtonState();
    }

    @Override
    public void onProviderEnabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) setStatus("GPS activado. Toca Iniciar GPS.", accentColor);
    }

    @Override
    public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) setStatus("GPS desactivado", Color.rgb(244, 67, 54));
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // Compatibilidad con versiones antiguas de Android.
    }

    private void updateDisplay(Location location) {
        if (latitudeView == null) return;
        if (location == null) {
            latitudeView.setText("Sin lectura");
            longitudeView.setText("Sin lectura");
            altitudeView.setText("No disponible aún");
            accuracyView.setText("Sin lectura");
            speedView.setText("Sin movimiento / sin dato");
            bearingView.setText("Sin rumbo válido aún");
            timeView.setText("Sin lectura reciente");
            providerView.setText("Sin lectura");
            utmZoneView.setText("Sin lectura");
            utmEastView.setText("Sin lectura");
            utmNorthView.setText("Sin lectura");
            if (satellitesView != null) satellitesView.setText(satellitesVisible + " / " + satellitesUsed);
            setQuality(null);
            refreshAverageButtonState();
            return;
        }

        latitudeView.setText(String.format(Locale.US, "%.8f", location.getLatitude()));
        longitudeView.setText(String.format(Locale.US, "%.8f", location.getLongitude()));
        altitudeView.setText(location.hasAltitude() ? String.format(Locale.US, "%.2f m", location.getAltitude()) : "No reportada por el equipo");
        accuracyView.setText(location.hasAccuracy() ? String.format(Locale.US, "± %.1f m", location.getAccuracy()) : "No reportada");
        speedView.setText(location.hasSpeed() ? String.format(Locale.US, "%.2f km/h", Math.max(0f, location.getSpeed()) * 3.6) : "Sin dato / equipo quieto");
        bearingView.setText(formatMovementBearing(location));
        providerView.setText(providerLabel(location.getProvider()));
        updateReadingAge();

        UtmCoordinate utm = toUtm(location.getLatitude(), location.getLongitude());
        if (utm.valid) {
            utmZoneView.setText(utm.zone + " " + utm.hemisphere);
            utmEastView.setText(String.format(Locale.US, "%.3f m", utm.easting));
            utmNorthView.setText(String.format(Locale.US, "%.3f m", utm.northing));
        } else {
            utmZoneView.setText("Fuera del rango UTM");
            utmEastView.setText("—");
            utmNorthView.setText("—");
        }
        if (satellitesView != null) satellitesView.setText(satellitesVisible + " / " + satellitesUsed);
        setQuality(location);
        refreshAverageButtonState();
    }

    private void saveLastLocation(Location location) {
        if (location == null) return;
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.hasAccuracy() ? location.getAccuracy() : 0f)
                .putFloat("last_bearing", hasUsableMovementBearing(location) ? location.getBearing() : -1f)
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .apply();
    }

    private void updateReadingAge() {
        if (timeView == null) return;
        if (currentLocation == null) {
            timeView.setText("Sin lectura reciente");
            return;
        }
        long timestamp = currentLocation.getTime() > 0 ? currentLocation.getTime() : System.currentTimeMillis();
        long ageMs = Math.max(0L, System.currentTimeMillis() - timestamp);
        String date = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
        timeView.setText(date + " · " + ageLabel(ageMs));
    }

    private String ageLabel(long ageMs) {
        long seconds = ageMs / 1000L;
        if (seconds < 2L) return "ahora";
        if (seconds < 60L) return "hace " + seconds + " s";
        long minutes = seconds / 60L;
        if (minutes < 60L) return "hace " + minutes + " min";
        return "lectura antigua";
    }

    private boolean hasUsableMovementBearing(Location location) {
        if (location == null || !location.hasBearing() || !location.hasSpeed()) return false;
        if (location.getSpeed() < 0.8f) return false;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        if (System.currentTimeMillis() - timestamp > 15000L) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && location.hasBearingAccuracy()
                && location.getBearingAccuracyDegrees() > 45f) return false;
        return true;
    }

    private String formatMovementBearing(Location location) {
        if (!hasUsableMovementBearing(location)) {
            return location != null && location.hasSpeed() && location.getSpeed() < 0.8f
                    ? "No disponible (detenido)"
                    : "No disponible";
        }
        double bearing = normalizeBearing(location.getBearing());
        String value = String.format(Locale.US, "%.1f° · %s", bearing, cardinalDirection(bearing));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && location.hasBearingAccuracy()) {
            value += String.format(Locale.US, " (±%.0f°)", location.getBearingAccuracyDegrees());
        }
        return value;
    }

    private String cardinalDirection(double bearing) {
        String[] directions = {"N", "NE", "E", "SE", "S", "SO", "O", "NO"};
        int index = (int) Math.round(normalizeBearing(bearing) / 45.0) % 8;
        return directions[index];
    }

    private void setQuality(Location location) {
        if (qualityView == null) return;
        if (location == null || !location.hasAccuracy()) {
            qualityView.setText("Calidad: sin lectura válida");
            setViewBackground(qualityView, inputFillColor, inputStrokeColor);
            return;
        }
        float accuracy = location.getAccuracy();
        int color;
        String label;
        if (accuracy <= 5f) {
            color = Color.rgb(0, 184, 148);
            label = "Buena para reconocimiento · " + String.format(Locale.US, "± %.1f m", accuracy);
        } else if (accuracy <= 15f) {
            color = Color.rgb(255, 171, 0);
            label = "Regular · " + String.format(Locale.US, "± %.1f m", accuracy);
        } else if (accuracy <= MAX_AVERAGE_ACCURACY_M) {
            color = Color.rgb(255, 112, 20);
            label = "Baja · " + String.format(Locale.US, "± %.1f m", accuracy) + ". Espera una mejor lectura.";
        } else {
            color = Color.rgb(244, 67, 54);
            label = "No válida para promedio · " + String.format(Locale.US, "± %.1f m", accuracy) + ". Busca cielo despejado.";
        }
        qualityView.setText("Calidad: " + label);
        setViewBackground(qualityView, withAlphaOnBackground(color), color);
    }

    private void setStatus(String message, int color) {
        if (statusView == null) return;
        statusView.setText(message);
        setViewBackground(statusView, withAlphaOnBackground(color), color);
    }

    private int withAlphaOnBackground(int color) {
        int r = (Color.red(color) + Color.red(cardColor) * 4) / 5;
        int g = (Color.green(color) + Color.green(cardColor) * 4) / 5;
        int b = (Color.blue(color) + Color.blue(cardColor) * 4) / 5;
        return Color.rgb(r, g, b);
    }

    private void startAveraging() {
        if (averaging) {
            cancelAveraging(true);
            return;
        }
        pendingAverageStart = false;
        if (!gpsRunning) {
            pendingAverageStart = true;
            startGps();
            if (!gpsRunning) {
                setStatus("El promedio empezará cuando el permiso y el GPS estén disponibles.", Color.rgb(255, 171, 0));
                refreshAverageButtonState();
                return;
            }
            pendingAverageStart = false;
        }
        beginAveragePreparation();
    }

    private void beginAveragePreparation() {
        averagingSamples.clear();
        averagingRejectedSamples = 0;
        averagingApproximateMode = false;
        averaging = true;
        if (isPreciseGnssForAverage(currentLocation)) {
            beginAverageCountdown(currentLocation, false);
        } else {
            averagingWaitingForFix = true;
            averagingFixDeadline = System.currentTimeMillis() + MAX_AVERAGE_FIX_WAIT_MS;
            averagingEndsAt = 0L;
            setStatus("Fase 1 de 2 · Búsqueda previa de señal GPS/GNSS durante un máximo de 30 s. "
                    + "Tu promedio real seguirá siendo de " + (averageDurationMs / 1000L) + " s.", Color.rgb(255, 171, 0));
        }
        refreshAverageButtonState();
        handler.removeCallbacks(averagingTicker);
        handler.post(averagingTicker);
    }

    private void beginAverageCountdown(Location firstSample, boolean approximate) {
        averagingWaitingForFix = false;
        averagingApproximateMode = approximate;
        averagingEndsAt = System.currentTimeMillis() + averageDurationMs;
        averagingSamples.clear();
        averagingRejectedSamples = 0;
        if (firstSample != null && isSampleAllowedForCurrentAverage(firstSample)) {
            averagingSamples.add(new Location(firstSample));
        }
        setStatus((approximate ? "Promedio aproximado" : "Señal GPS/GNSS lista")
                + ". Iniciando " + (averageDurationMs / 1000L) + " s…", Color.rgb(255, 171, 0));
        refreshAverageButtonState();
    }

    private void showAverageFixTimeoutDialog() {
        handler.removeCallbacks(averagingTicker);
        averaging = false;
        averagingWaitingForFix = false;
        refreshAverageButtonState();
        boolean canUseApproximate = isUsableApproximateLocation(currentLocation);
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Aún no hay señal GPS precisa")
                .setMessage("No se consiguió una lectura GPS/GNSS de ± 50 m o mejor en 30 segundos. "
                        + "Esos 30 s son solo la búsqueda previa; tu promedio elegido de " + (averageDurationMs / 1000L) + " s se mantiene igual. Puedes seguir esperando o cancelar."
                        + (canUseApproximate ? " También puedes promediar la ubicación de red, pero será solo referencial y no apta para topografía." : ""))
                .setPositiveButton("Seguir esperando", (d, w) -> beginAveragePreparation())
                .setNegativeButton("Cancelar", null);
        if (canUseApproximate) {
            builder.setNeutralButton("Usar aproximada", (d, w) -> {
                averaging = true;
                beginAverageCountdown(currentLocation, true);
                handler.removeCallbacks(averagingTicker);
                handler.post(averagingTicker);
            });
        }
        builder.show();
    }

    private void finishAveraging() {
        boolean approximateResult = averagingApproximateMode;
        averaging = false;
        averagingWaitingForFix = false;
        handler.removeCallbacks(averagingTicker);
        refreshAverageButtonState();
        if (averagingSamples.isEmpty()) {
            setStatus("No hubo lecturas válidas para promediar. No se cambió tu última posición. Intenta al aire libre.", Color.rgb(244, 67, 54));
            return;
        }

        List<Location> filtered = rejectOutlierLocations(averagingSamples);
        int rejectedByFilter = averagingSamples.size() - filtered.size();
        if (filtered.isEmpty()) {
            setStatus("Las lecturas fueron demasiado dispersas. No se aplicó el promedio.", Color.rgb(244, 67, 54));
            return;
        }

        Location averaged = averageLocations(filtered);
        currentLocation = averaged;
        saveLastLocation(averaged);
        updateDisplay(averaged);
        stopLocationUpdates(false);
        int rejectedTotal = averagingRejectedSamples + rejectedByFilter;
        String prefix = approximateResult
                ? "Promedio aproximado aplicado (solo referencial): "
                : "Promedio GPS aplicado: ";
        setStatus(prefix + filtered.size() + " lecturas aceptadas y "
                + rejectedTotal + " descartadas. GPS detenido para conservar el resultado.",
                approximateResult ? Color.rgb(255, 171, 0) : Color.rgb(0, 184, 148));
        averagingApproximateMode = false;
    }

    private void cancelAveraging(boolean showMessage) {
        if (!averaging && !pendingAverageStart) return;
        averaging = false;
        averagingWaitingForFix = false;
        averagingApproximateMode = false;
        pendingAverageStart = false;
        handler.removeCallbacks(averagingTicker);
        averagingSamples.clear();
        averagingRejectedSamples = 0;
        refreshAverageButtonState();
        if (showMessage) setStatus("Promedio cancelado", subTextColor);
    }

    private boolean isPreciseGnssForAverage(Location location) {
        if (location == null) return false;
        if (!LocationManager.GPS_PROVIDER.equals(location.getProvider()) && !"promedio_gnss".equals(location.getProvider())) return false;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        if (System.currentTimeMillis() - timestamp > MAX_LIVE_LOCATION_AGE_MS) return false;
        return location.hasAccuracy() && location.getAccuracy() <= MAX_AVERAGE_ACCURACY_M;
    }

    private boolean isUsableApproximateLocation(Location location) {
        if (location == null) return false;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        if (System.currentTimeMillis() - timestamp > MAX_LIVE_LOCATION_AGE_MS) return false;
        return location.hasAccuracy() && location.getAccuracy() <= MAX_APPROXIMATE_AVERAGE_ACCURACY_M;
    }

    private boolean isSampleAllowedForCurrentAverage(Location location) {
        return averagingApproximateMode ? isUsableApproximateLocation(location) : isPreciseGnssForAverage(location);
    }

    private boolean isUsableForAverage(Location location) {
        return isPreciseGnssForAverage(location);
    }

    private boolean isAllowedByLocationMode(Location location) {
        if (location == null) return false;
        return useNetworkProvider || LocationManager.GPS_PROVIDER.equals(location.getProvider())
                || "promedio_gnss".equals(location.getProvider()) || "promedio_aproximado".equals(location.getProvider());
    }

    private void refreshAverageButtonState() {
        if (averageButton == null) return;
        averageButton.setEnabled(true);
        averageButton.setText(averaging ? "Cancelar" : "Promediar " + (averageDurationMs / 1000L) + " s");
    }

    private List<Location> rejectOutlierLocations(List<Location> samples) {
        List<Location> clean = new ArrayList<>();
        for (Location sample : samples) if (isSampleAllowedForCurrentAverage(sample)) clean.add(new Location(sample));
        if (clean.size() < 4) return clean;

        Location provisional = averageLocations(clean);
        List<Float> distances = new ArrayList<>();
        for (Location sample : clean) distances.add(sample.distanceTo(provisional));
        java.util.Collections.sort(distances);
        float median = distances.get(distances.size() / 2);
        float threshold = Math.max(12f, Math.min(60f, median * 3f + 5f));

        List<Location> filtered = new ArrayList<>();
        for (Location sample : clean) {
            if (sample.distanceTo(provisional) <= threshold) filtered.add(sample);
        }
        return filtered.size() >= 2 ? filtered : clean;
    }

    private Location averageLocations(List<Location> samples) {
        double totalWeight = 0.0;
        double lat = 0.0;
        double lon = 0.0;
        double altitude = 0.0;
        double altitudeWeight = 0.0;
        double speed = 0.0;
        double speedWeight = 0.0;
        double bearingSin = 0.0;
        double bearingCos = 0.0;
        double bearingWeight = 0.0;
        double accuracySum = 0.0;
        int accuracyCount = 0;

        for (Location sample : samples) {
            double reported = sample.hasAccuracy() ? Math.max(1.0, sample.getAccuracy()) : 20.0;
            double weight = 1.0 / (reported * reported);
            totalWeight += weight;
            lat += sample.getLatitude() * weight;
            lon += sample.getLongitude() * weight;
            if (sample.hasAltitude()) {
                altitude += sample.getAltitude() * weight;
                altitudeWeight += weight;
            }
            if (sample.hasSpeed()) {
                speed += sample.getSpeed() * weight;
                speedWeight += weight;
            }
            if (sample.hasBearing() && sample.hasSpeed() && sample.getSpeed() >= 0.8f) {
                double rad = Math.toRadians(sample.getBearing());
                bearingSin += Math.sin(rad) * weight;
                bearingCos += Math.cos(rad) * weight;
                bearingWeight += weight;
            }
            if (sample.hasAccuracy()) {
                accuracySum += sample.getAccuracy();
                accuracyCount++;
            }
        }

        Location result = new Location(averagingApproximateMode ? "promedio_aproximado" : "promedio_gnss");
        result.setLatitude(lat / totalWeight);
        result.setLongitude(lon / totalWeight);
        if (altitudeWeight > 0) result.setAltitude(altitude / altitudeWeight);
        if (speedWeight > 0) result.setSpeed((float) (speed / speedWeight));
        if (bearingWeight > 0) {
            double bearing = Math.toDegrees(Math.atan2(bearingSin, bearingCos));
            result.setBearing((float) normalizeBearing(bearing));
        }
        if (accuracyCount > 0) result.setAccuracy((float) (accuracySum / accuracyCount));
        result.setTime(System.currentTimeMillis());
        return result;
    }

    private void choosePointPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PHOTO);
    }

    private void saveCurrentPoint() {
        if (currentLocation == null) {
            Toast.makeText(this, "No hay una coordenada disponible. Inicia el GPS.", Toast.LENGTH_LONG).show();
            return;
        }
        long timestamp = currentLocation.getTime() > 0 ? currentLocation.getTime() : System.currentTimeMillis();
        if (System.currentTimeMillis() - timestamp > 30000L) {
            Toast.makeText(this, "La lectura tiene más de 30 segundos. Inicia el GPS y espera una posición nueva.", Toast.LENGTH_LONG).show();
            return;
        }
        String name = pointNameInput.getText().toString().trim();
        if (name.isEmpty()) name = nextPointName();
        final String finalName = name;
        float accuracy = currentLocation.hasAccuracy() ? currentLocation.getAccuracy() : Float.NaN;
        if (!Float.isNaN(accuracy) && accuracy > MAX_AVERAGE_ACCURACY_M) {
            Toast.makeText(this, "La precisión es demasiado baja (± "
                    + String.format(Locale.US, "%.1f", accuracy)
                    + " m). Espera una lectura mejor antes de guardar.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Float.isNaN(accuracy) && accuracy > 10f) {
            new AlertDialog.Builder(this)
                    .setTitle("Precisión baja")
                    .setMessage("La lectura indica aproximadamente ± " + String.format(Locale.US, "%.1f", accuracy) + " m. ¿Deseas guardarla de todas formas?")
                    .setPositiveButton("Guardar", (d, w) -> persistCurrentPoint(finalName))
                    .setNegativeButton("Esperar", null)
                    .show();
        } else {
            persistCurrentPoint(finalName);
        }
    }

    private void persistCurrentPoint(String name) {
        String project = projectNameInput == null ? "Proyecto general" : projectNameInput.getText().toString().trim();
        if (project.isEmpty()) project = "Proyecto general";
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString("current_project", project).apply();
        GpsPoint point = GpsPoint.fromLocation(project, name, pointDescriptionInput.getText().toString().trim(), currentLocation);
        point.photoUri = pendingPhotoUri == null ? "" : pendingPhotoUri;
        points.add(point);
        savePoints();
        pointNameInput.setText(nextPointName());
        pointDescriptionInput.setText("");
        pendingPhotoUri = "";
        if (photoStatusView != null) photoStatusView.setText("Sin foto adjunta");
        updateSavedCount();
        Toast.makeText(this, "Punto " + point.name + " guardado", Toast.LENGTH_SHORT).show();
    }

    private void updateSavedCount() {
        if (savedCountView != null) savedCountView.setText("Puntos guardados: " + points.size());
    }

    private String nextPointName() {
        int number = 1;
        while (true) {
            String candidate = "P" + number;
            boolean exists = false;
            for (GpsPoint point : points) {
                if (candidate.equalsIgnoreCase(point.name)) {
                    exists = true;
                    break;
                }
            }
            if (!exists) return candidate;
            number++;
        }
    }

    private void showPointsDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(12), dp(16), dp(12));
        panel.setBackgroundColor(cardColor);

        if (points.isEmpty()) {
            TextView empty = text("Todavía no hay puntos guardados.", 16, false);
            panel.addView(empty);
        } else {
            for (int i = 0; i < points.size(); i++) {
                GpsPoint p = points.get(i);
                UtmCoordinate u = toUtm(p.latitude, p.longitude);
                StringBuilder value = new StringBuilder();
                value.append(i + 1).append(". [").append(p.project).append("] ").append(p.name);
                if (!p.description.isEmpty()) value.append(" — ").append(p.description);
                value.append("\nLat/Lon: ").append(String.format(Locale.US, "%.8f, %.8f", p.latitude, p.longitude));
                if (u.valid) value.append("\nUTM: ").append(u.zone).append(" ").append(u.hemisphere)
                        .append(" | E ").append(String.format(Locale.US, "%.3f", u.easting))
                        .append(" | N ").append(String.format(Locale.US, "%.3f", u.northing));
                value.append("\nPrecisión: ").append(Double.isNaN(p.accuracy) ? "—" : String.format(Locale.US, "± %.1f m", p.accuracy));
                value.append(" | ").append(formatDate(p.timestamp));
                if (p.photoUri != null && !p.photoUri.isEmpty()) value.append("\nFoto adjunta");
                TextView item = resultBox(value.toString());
                final int pointIndex = i;
                item.setContentDescription("Abrir opciones del punto " + p.name);
                item.setOnClickListener(v -> showPointActions(pointIndex));
                panel.addView(item);
            }
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(panel);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Puntos guardados")
                .setView(scroll)
                .setPositiveButton("Cerrar", null)
                .setNeutralButton(points.isEmpty() ? null : "Borrar todos", null)
                .create();
        dialog.setOnShowListener(d -> {
            if (!points.isEmpty()) {
                Button clear = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
                clear.setOnClickListener(v -> confirmClearPoints(dialog));
            }
        });
        dialog.show();
    }

    private void showPointActions(int index) {
        if (index < 0 || index >= points.size()) return;
        GpsPoint point = points.get(index);
        ArrayList<String> options = new ArrayList<>();
        options.add("Editar nombre y descripción");
        options.add("Abrir en el mapa");
        if (point.photoUri != null && !point.photoUri.isEmpty()) options.add("Ver foto adjunta");
        options.add("Eliminar punto");
        String[] items = options.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle(point.name + " · " + point.project)
                .setItems(items, (d, which) -> {
                    String selected = items[which];
                    if (selected.startsWith("Editar")) editPoint(index);
                    else if (selected.startsWith("Abrir")) openSavedPointInMap(point);
                    else if (selected.startsWith("Ver foto")) openPointPhoto(point);
                    else if (selected.startsWith("Eliminar")) deletePoint(index);
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void editPoint(int index) {
        if (index < 0 || index >= points.size()) return;
        GpsPoint point = points.get(index);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(8), dp(18), dp(4));
        panel.setBackgroundColor(Color.WHITE);
        EditText project = new EditText(this);
        project.setHint("Proyecto");
        project.setText(point.project);
        project.setTextColor(Color.rgb(32, 36, 43));
        EditText name = new EditText(this);
        name.setHint("Nombre");
        name.setText(point.name);
        name.setTextColor(Color.rgb(32, 36, 43));
        EditText description = new EditText(this);
        description.setHint("Descripción");
        description.setText(point.description);
        description.setTextColor(Color.rgb(32, 36, 43));
        description.setMinLines(2);
        description.setMaxLines(5);
        panel.addView(project);
        panel.addView(name);
        panel.addView(description);
        new AlertDialog.Builder(this)
                .setTitle("Editar punto")
                .setView(panel)
                .setPositiveButton("Guardar", (d, w) -> {
                    String newProject = project.getText().toString().trim();
                    String newName = name.getText().toString().trim();
                    point.project = newProject.isEmpty() ? "Proyecto general" : newProject;
                    point.name = newName.isEmpty() ? point.name : newName;
                    point.description = description.getText().toString().trim();
                    savePoints();
                    Toast.makeText(this, "Punto actualizado", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void openSavedPointInMap(GpsPoint point) {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("latitude", point.latitude);
        intent.putExtra("longitude", point.longitude);
        intent.putExtra("location_accuracy", Double.isNaN(point.accuracy) ? 0f : (float) point.accuracy);
        intent.putExtra("location_bearing", Double.isNaN(point.bearing) ? -1f : (float) point.bearing);
        intent.putExtra("location_time", point.timestamp);
        startActivity(intent);
    }

    private void openPointPhoto(GpsPoint point) {
        if (point.photoUri == null || point.photoUri.isEmpty()) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(point.photoUri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la foto adjunta.", Toast.LENGTH_LONG).show();
        }
    }

    private void deletePoint(int index) {
        if (index < 0 || index >= points.size()) return;
        GpsPoint point = points.get(index);
        new AlertDialog.Builder(this)
                .setTitle("Eliminar " + point.name)
                .setMessage("Se eliminará este punto de GeoTopo.")
                .setPositiveButton("Eliminar", (d, w) -> {
                    points.remove(index);
                    savePoints();
                    updateSavedCount();
                    Toast.makeText(this, "Punto eliminado", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void confirmClearPoints(AlertDialog parent) {
        new AlertDialog.Builder(this)
                .setTitle("Borrar todos los puntos")
                .setMessage("Esta acción no se puede deshacer. Exporta primero si necesitas conservarlos.")
                .setPositiveButton("Borrar", (d, w) -> {
                    points.clear();
                    savePoints();
                    updateSavedCount();
                    pointNameInput.setText(nextPointName());
                    parent.dismiss();
                    Toast.makeText(this, "Puntos borrados", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void beginExport(String type) {
        if (points.isEmpty()) {
            Toast.makeText(this, "No hay puntos guardados para exportar.", Toast.LENGTH_LONG).show();
            return;
        }
        pendingExportType = type;
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        if ("kml".equals(type)) {
            intent.setType("application/vnd.google-earth.kml+xml");
            intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".kml");
        } else if ("kmz".equals(type)) {
            intent.setType("application/vnd.google-earth.kmz");
            intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".kmz");
        } else if ("gpx".equals(type)) {
            intent.setType("application/gpx+xml");
            intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".gpx");
        } else {
            intent.setType("text/csv");
            intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".csv");
        }
        startActivityForResult(intent, REQ_EXPORT);
    }

    private void beginImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.google-earth.kml+xml",
                "application/vnd.google-earth.kmz",
                "application/zip",
                "text/xml",
                "application/xml"
        });
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void shareProjectSummary() {
        if (points.isEmpty()) {
            Toast.makeText(this, "No hay puntos guardados para compartir.", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("GeoTopo · Proyecto de campo\n");
        sb.append("Puntos: ").append(points.size()).append("\n\n");
        for (GpsPoint point : points) {
            sb.append('[').append(point.project).append("] ").append(point.name).append("\n")
                    .append(String.format(Locale.US, "%.8f, %.8f", point.latitude, point.longitude));
            if (!Double.isNaN(point.accuracy)) sb.append(String.format(Locale.US, " · ±%.1f m", point.accuracy));
            if (point.description != null && !point.description.isEmpty()) sb.append("\n").append(point.description);
            if (point.photoUri != null && !point.photoUri.isEmpty()) sb.append("\nFoto adjunta en GeoTopo");
            sb.append("\n\n");
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Proyecto GeoTopo");
        send.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(send, "Compartir proyecto"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_PHOTO) {
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            pendingPhotoUri = uri.toString();
            if (photoStatusView != null) photoStatusView.setText("Foto adjunta correctamente");
            return;
        }

        if (requestCode == REQ_IMPORT) {
            importKmlOrKmz(uri);
            return;
        }

        if (requestCode != REQ_EXPORT) return;
        try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
            if (output == null) throw new IOException("No se pudo abrir el archivo de destino");
            if ("kmz".equals(pendingExportType)) {
                try (ZipOutputStream zip = new ZipOutputStream(output)) {
                    zip.putNextEntry(new ZipEntry("doc.kml"));
                    zip.write(buildKml().getBytes(StandardCharsets.UTF_8));
                    zip.closeEntry();
                    zip.finish();
                }
            } else {
                try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8))) {
                    writer.write('\ufeff');
                    writer.write("kml".equals(pendingExportType) ? buildKml() : ("gpx".equals(pendingExportType) ? buildGpx() : buildCsv()));
                    writer.flush();
                }
            }
            Toast.makeText(this, "Archivo exportado correctamente", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo exportar: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private void importKmlOrKmz(Uri uri) {
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IOException("No se pudo abrir el archivo");
            BufferedInputStream input = new BufferedInputStream(raw);
            input.mark(4);
            int b1 = input.read();
            int b2 = input.read();
            input.reset();
            String kml;
            if (b1 == 'P' && b2 == 'K') {
                kml = readKmlFromKmz(input);
            } else {
                kml = new String(readAllBytes(input, 20 * 1024 * 1024), StandardCharsets.UTF_8);
            }
            List<GpsPoint> imported = parseKmlPoints(kml);
            if (imported.isEmpty()) {
                Toast.makeText(this, "El archivo no contiene puntos KML compatibles.", Toast.LENGTH_LONG).show();
                return;
            }
            points.addAll(imported);
            savePoints();
            updateSavedCount();
            if (pointNameInput != null) pointNameInput.setText(nextPointName());
            Toast.makeText(this, "Importados " + imported.size() + " puntos", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo importar: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private String readKmlFromKmz(InputStream input) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(input)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (!entry.isDirectory() && entry.getName().toLowerCase(Locale.US).endsWith(".kml")) {
                    return new String(readAllBytes(zip, 20 * 1024 * 1024), StandardCharsets.UTF_8);
                }
                zip.closeEntry();
            }
        }
        throw new IOException("El KMZ no contiene un archivo KML");
    }

    private byte[] readAllBytes(InputStream input, int maxBytes) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int total = 0;
        int read;
        while ((read = input.read(buffer)) != -1) {
            total += read;
            if (total > maxBytes) throw new IOException("El archivo es demasiado grande");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private List<GpsPoint> parseKmlPoints(String kml) {
        ArrayList<GpsPoint> imported = new ArrayList<>();
        if (kml == null) return imported;
        Pattern placemarkPattern = Pattern.compile("(?is)<Placemark\\b[^>]*>(.*?)</Placemark>");
        Matcher placemarks = placemarkPattern.matcher(kml);
        int count = 1;
        while (placemarks.find()) {
            String block = placemarks.group(1);
            String coordinates = firstTagValue(block, "coordinates");
            if (coordinates.isEmpty()) continue;
            String first = coordinates.trim().split("\\s+")[0];
            String[] parts = first.split(",");
            if (parts.length < 2) continue;
            try {
                double lon = Double.parseDouble(parts[0].trim());
                double lat = Double.parseDouble(parts[1].trim());
                if (lat < -90 || lat > 90 || lon < -180 || lon > 180) continue;
                GpsPoint point = new GpsPoint();
                point.project = "Importado KML/KMZ";
                point.name = decodeXml(firstTagValue(block, "name"));
                if (point.name.isEmpty()) point.name = "KML" + count;
                point.description = stripHtml(decodeXml(firstTagValue(block, "description")));
                point.latitude = lat;
                point.longitude = lon;
                point.altitude = parts.length >= 3 ? parseOptional(parts[2]) : Double.NaN;
                point.accuracy = Double.NaN;
                point.speedKmh = Double.NaN;
                point.bearing = Double.NaN;
                point.timestamp = System.currentTimeMillis();
                point.provider = "KML/KMZ importado";
                point.photoUri = "";
                imported.add(point);
                count++;
            } catch (NumberFormatException ignored) {
            }
        }
        return imported;
    }

    private String firstTagValue(String block, String tag) {
        Matcher matcher = Pattern.compile("(?is)<" + Pattern.quote(tag) + "\\b[^>]*>(.*?)</" + Pattern.quote(tag) + ">").matcher(block);
        return matcher.find() ? matcher.group(1).trim() : "";
    }

    private String decodeXml(String value) {
        return value == null ? "" : value
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&amp;", "&");
    }

    private String stripHtml(String value) {
        return value == null ? "" : value.replaceAll("(?is)<[^>]+>", " ").replaceAll("\\s+", " ").trim();
    }

    private double parseOptional(String value) {
        try {
            return Double.parseDouble(value.trim());
        } catch (Exception ignored) {
            return Double.NaN;
        }
    }

    private String buildCsv() {
        StringBuilder sb = new StringBuilder();
        sb.append("Proyecto,Punto,Descripcion,Latitud,Longitud,Este_UTM,Norte_UTM,Zona,Hemisferio,Altitud_m,Precision_m,Velocidad_kmh,Azimut_grados,Proveedor,Foto_URI,Fecha_hora\n");
        for (GpsPoint p : points) {
            UtmCoordinate u = toUtm(p.latitude, p.longitude);
            sb.append(csv(p.project)).append(',')
                    .append(csv(p.name)).append(',')
                    .append(csv(p.description)).append(',')
                    .append(formatNumber(p.latitude, 8)).append(',')
                    .append(formatNumber(p.longitude, 8)).append(',')
                    .append(u.valid ? formatNumber(u.easting, 3) : "").append(',')
                    .append(u.valid ? formatNumber(u.northing, 3) : "").append(',')
                    .append(u.valid ? u.zone : "").append(',')
                    .append(u.valid ? u.hemisphere : "").append(',')
                    .append(formatOptional(p.altitude, 2)).append(',')
                    .append(formatOptional(p.accuracy, 1)).append(',')
                    .append(formatOptional(p.speedKmh, 2)).append(',')
                    .append(formatOptional(p.bearing, 2)).append(',')
                    .append(csv(p.provider)).append(',')
                    .append(csv(p.photoUri == null ? "" : p.photoUri)).append(',')
                    .append(csv(formatDate(p.timestamp))).append('\n');
        }
        return sb.toString();
    }

    private String buildKml() {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>\n");
        sb.append("<name>GeoTopo - Puntos GPS</name>\n");
        for (GpsPoint p : points) {
            UtmCoordinate u = toUtm(p.latitude, p.longitude);
            sb.append("<Placemark>\n");
            sb.append("<name>").append(xml(p.name)).append("</name>\n");
            sb.append("<description>")
                    .append("Proyecto: ").append(xml(p.project)).append("\n")
                    .append(xml(p.description)).append("\n")
                    .append("Precisión: ").append(Double.isNaN(p.accuracy) ? "—" : formatNumber(p.accuracy, 1) + " m").append("\n")
                    .append(u.valid ? "UTM: " + u.zone + " " + u.hemisphere + ", E " + formatNumber(u.easting, 3) + ", N " + formatNumber(u.northing, 3) + "\n" : "")
                    .append("Fecha: ").append(xml(formatDate(p.timestamp)))
                    .append(p.photoUri != null && !p.photoUri.isEmpty() ? "\nFoto adjunta en GeoTopo" : "")
                    .append("</description>\n");
            sb.append("<Point><coordinates>")
                    .append(formatNumber(p.longitude, 8)).append(',')
                    .append(formatNumber(p.latitude, 8)).append(',')
                    .append(Double.isNaN(p.altitude) ? "0" : formatNumber(p.altitude, 2))
                    .append("</coordinates></Point>\n");
            sb.append("</Placemark>\n");
        }
        sb.append("</Document></kml>\n");
        return sb.toString();
    }

    private String buildGpx() {
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<gpx version=\"1.1\" creator=\"GeoTopo\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        sb.append("<metadata><name>GeoTopo - Puntos GPS</name></metadata>\n");
        for (GpsPoint p : points) {
            sb.append("<wpt lat=\"").append(formatNumber(p.latitude, 8)).append("\" lon=\"").append(formatNumber(p.longitude, 8)).append("\">\n");
            if (!Double.isNaN(p.altitude)) sb.append("<ele>").append(formatNumber(p.altitude, 2)).append("</ele>\n");
            sb.append("<time>").append(iso.format(new Date(p.timestamp))).append("</time>\n");
            sb.append("<name>").append(xml(p.name)).append("</name>\n");
            sb.append("<desc>").append(xml("Proyecto: " + p.project + (p.description.isEmpty() ? "" : " | " + p.description))).append("</desc>\n");
            sb.append("</wpt>\n");
        }
        sb.append("</gpx>\n");
        return sb.toString();
    }

    private void openGeoTopoMap() {
        Intent intent = new Intent(this, MapActivity.class);
        if (currentLocation != null) {
            intent.putExtra("latitude", currentLocation.getLatitude());
            intent.putExtra("longitude", currentLocation.getLongitude());
            intent.putExtra("location_accuracy", currentLocation.hasAccuracy() ? currentLocation.getAccuracy() : 0f);
            intent.putExtra("location_bearing", hasUsableMovementBearing(currentLocation) ? currentLocation.getBearing() : -1f);
            intent.putExtra("location_time", currentLocation.getTime());
        }
        startActivity(intent);
    }

    private void openCurrentPointInMap() {
        if (currentLocation == null) {
            Toast.makeText(this, "No hay una coordenada disponible.", Toast.LENGTH_LONG).show();
            return;
        }
        double lat = currentLocation.getLatitude();
        double lon = currentLocation.getLongitude();
        String label = pointNameInput == null ? "GeoTopo" : pointNameInput.getText().toString().trim();
        if (label.isEmpty()) label = "GeoTopo";
        Uri geo = Uri.parse("geo:" + lat + "," + lon + "?q=" + lat + "," + lon + "(" + Uri.encode(label) + ")");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, geo);
        try {
            startActivity(mapIntent);
        } catch (ActivityNotFoundException e) {
            Uri web = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + lat + "," + lon);
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, web));
            } catch (ActivityNotFoundException ex) {
                Toast.makeText(this, "No hay una aplicación de mapas o navegador disponible.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void copyCurrentCoordinates() {
        if (currentLocation == null) {
            Toast.makeText(this, "No hay una coordenada disponible.", Toast.LENGTH_LONG).show();
            return;
        }
        UtmCoordinate u = toUtm(currentLocation.getLatitude(), currentLocation.getLongitude());
        String text = String.format(Locale.US, "Latitud: %.8f\nLongitud: %.8f", currentLocation.getLatitude(), currentLocation.getLongitude());
        if (u.valid) {
            text += String.format(Locale.US, "\nUTM: %d %s\nEste: %.3f m\nNorte: %.3f m", u.zone, u.hemisphere, u.easting, u.northing);
        }
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Coordenadas GeoTopo", text));
            Toast.makeText(this, "Coordenadas copiadas", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        boolean fineGranted = false;
        for (int i = 0; i < permissions.length; i++) {
            if (Manifest.permission.ACCESS_FINE_LOCATION.equals(permissions[i])
                    && i < grantResults.length
                    && grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                fineGranted = true;
                break;
            }
        }
        if (fineGranted) {
            startGps();
            if (pendingAverageStart && gpsRunning) {
                pendingAverageStart = false;
                beginAveragePreparation();
            }
        } else {
            pendingAverageStart = false;
            refreshAverageButtonState();
            setStatus("Permiso denegado o ubicación aproximada. Para GPS necesitas permitir ubicación precisa.", Color.rgb(244, 67, 54));
        }
    }

    private void loadPoints() {
        points.clear();
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);
                if (object != null) points.add(GpsPoint.fromJson(object));
            }
        } catch (JSONException ignored) {
        }
    }

    private void savePoints() {
        JSONArray array = new JSONArray();
        for (GpsPoint point : points) array.put(point.toJson());
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, array.toString()).apply();
    }

    private Location safeLastKnownLocation(String provider) {
        if (locationManager == null) return null;
        try {
            return locationManager.getLastKnownLocation(provider);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Location chooseBetter(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        if (a.getTime() > b.getTime() + 30000L) return a;
        if (b.getTime() > a.getTime() + 30000L) return b;
        if (a.hasAccuracy() && b.hasAccuracy()) return a.getAccuracy() <= b.getAccuracy() ? a : b;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private boolean isBetterLocation(Location candidate, Location current) {
        long timeDelta = candidate.getTime() - current.getTime();
        boolean significantlyNewer = timeDelta > 30000L;
        boolean significantlyOlder = timeDelta < -30000L;
        boolean newer = timeDelta > 0L;
        if (significantlyNewer) return true;
        if (significantlyOlder) return false;

        if (!current.hasAccuracy()) return true;
        if (!candidate.hasAccuracy()) return newer && sameProvider(candidate, current);

        float accuracyDelta = candidate.getAccuracy() - current.getAccuracy();
        boolean moreAccurate = accuracyDelta < 0f;
        boolean lessAccurate = accuracyDelta > 0f;
        boolean significantlyLessAccurate = accuracyDelta > 50f;
        return moreAccurate
                || (newer && !lessAccurate)
                || (newer && !significantlyLessAccurate && sameProvider(candidate, current));
    }

    private boolean sameProvider(Location a, Location b) {
        String pa = a.getProvider();
        String pb = b.getProvider();
        return pa == null ? pb == null : pa.equals(pb);
    }

    private String providerLabel(String provider) {
        if (provider == null) return "Desconocido";
        if (LocationManager.GPS_PROVIDER.equals(provider)) return "Satélite GPS/GNSS";
        if (LocationManager.NETWORK_PROVIDER.equals(provider)) return "Red / ubicación aproximada";
        if ("promedio_gnss".equals(provider)) return "Promedio GPS/GNSS";
        if ("promedio_aproximado".equals(provider)) return "Promedio aproximado (red)";
        return provider;
    }

    private static double normalizeBearing(double bearing) {
        double result = bearing % 360.0;
        if (result < 0) result += 360.0;
        return result;
    }

    private static UtmCoordinate toUtm(double latitude, double longitude) {
        if (latitude < -80.0 || latitude > 84.0 || longitude < -180.0 || longitude > 180.0) {
            return UtmCoordinate.invalid();
        }

        final double a = 6378137.0;
        final double eccSquared = 0.00669438;
        final double k0 = 0.9996;

        int zoneNumber = (int) Math.floor((longitude + 180.0) / 6.0) + 1;
        if (longitude == 180.0) zoneNumber = 60;

        if (latitude >= 56.0 && latitude < 64.0 && longitude >= 3.0 && longitude < 12.0) {
            zoneNumber = 32;
        }
        if (latitude >= 72.0 && latitude < 84.0) {
            if (longitude >= 0.0 && longitude < 9.0) zoneNumber = 31;
            else if (longitude < 21.0) zoneNumber = 33;
            else if (longitude < 33.0) zoneNumber = 35;
            else if (longitude < 42.0) zoneNumber = 37;
        }

        double lonOrigin = (zoneNumber - 1) * 6.0 - 180.0 + 3.0;
        double latRad = Math.toRadians(latitude);
        double lonRad = Math.toRadians(longitude);
        double lonOriginRad = Math.toRadians(lonOrigin);

        double eccPrimeSquared = eccSquared / (1.0 - eccSquared);
        double sinLat = Math.sin(latRad);
        double cosLat = Math.cos(latRad);
        double tanLat = Math.tan(latRad);
        double n = a / Math.sqrt(1.0 - eccSquared * sinLat * sinLat);
        double t = tanLat * tanLat;
        double c = eccPrimeSquared * cosLat * cosLat;
        double aa = cosLat * (lonRad - lonOriginRad);

        double m = a * ((1.0 - eccSquared / 4.0 - 3.0 * eccSquared * eccSquared / 64.0 - 5.0 * Math.pow(eccSquared, 3) / 256.0) * latRad
                - (3.0 * eccSquared / 8.0 + 3.0 * eccSquared * eccSquared / 32.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(2.0 * latRad)
                + (15.0 * eccSquared * eccSquared / 256.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(4.0 * latRad)
                - (35.0 * Math.pow(eccSquared, 3) / 3072.0) * Math.sin(6.0 * latRad));

        double easting = k0 * n * (aa + (1.0 - t + c) * Math.pow(aa, 3) / 6.0
                + (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * eccPrimeSquared) * Math.pow(aa, 5) / 120.0) + 500000.0;

        double northing = k0 * (m + n * tanLat * (aa * aa / 2.0
                + (5.0 - t + 9.0 * c + 4.0 * c * c) * Math.pow(aa, 4) / 24.0
                + (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * eccPrimeSquared) * Math.pow(aa, 6) / 720.0));

        String hemisphere = latitude < 0.0 ? "S" : "N";
        if (latitude < 0.0) northing += 10000000.0;
        return new UtmCoordinate(true, zoneNumber, hemisphere, easting, northing);
    }

    private String formatDate(long timestamp) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
    }

    private static String formatNumber(double value, int decimals) {
        return String.format(Locale.US, "%." + decimals + "f", value);
    }

    private static String formatOptional(double value, int decimals) {
        return Double.isNaN(value) ? "" : formatNumber(value, decimals);
    }

    private static String csv(String value) {
        if (value == null) value = "";
        return "\"" + value.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ") + "\"";
    }

    private static String xml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    private static String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? e.getClass().getSimpleName() : message;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), inputStrokeColor);
        box.setBackground(bg);
        return box;
    }

    private TextView sectionTitle(String value) {
        TextView view = text(value, 20, true);
        view.setPadding(0, 0, 0, dp(8));
        return view;
    }

    private TextView small(String value) {
        TextView view = text(value, 13, false);
        view.setTextColor(subTextColor);
        view.setLineSpacing(0, 1.15f);
        return view;
    }

    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(textColor);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private TextView resultBox(String value) {
        TextView view = text(value, 15, false);
        view.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(4));
        view.setLayoutParams(lp);
        setViewBackground(view, resultFillColor, resultStrokeColor);
        return view;
    }

    private TextView valueBox(String value) {
        TextView view = text(value, 15, true);
        view.setPadding(dp(10), dp(10), dp(10), dp(10));
        view.setGravity(Gravity.CENTER_VERTICAL);
        setViewBackground(view, inputFillColor, inputStrokeColor);
        return view;
    }

    private View labeledValue(String label, TextView value) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), dp(4), 0, dp(2));
        wrap.addView(title);
        wrap.addView(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        wrap.setLayoutParams(lp);
        return wrap;
    }

    private View twoValues(String leftLabel, TextView left, String rightLabel, TextView right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(labeledValue(leftLabel, left), weightParams());
        row.addView(labeledValue(rightLabel, right), weightParams());
        return row;
    }

    private EditText edit(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(textColor);
        input.setHintTextColor(subTextColor);
        input.setTextSize(16);
        input.setSingleLine(true);
        input.setPadding(dp(10), dp(8), dp(10), dp(8));
        setViewBackground(input, inputFillColor, inputStrokeColor);
        return input;
    }

    private View labeledInput(String label, EditText input) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), dp(6), 0, dp(2));
        wrap.addView(title);
        wrap.addView(input);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(3), 0, dp(5));
        wrap.setLayoutParams(lp);
        return wrap;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(bestContrastColor(accentColor));
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accentColor);
        bg.setCornerRadius(dp(10));
        button.setBackground(bg);
        return button;
    }

    private void setViewBackground(View view, int fill, int stroke) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(dp(9));
        bg.setStroke(dp(1), stroke);
        view.setBackground(bg);
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private int bestContrastColor(int color) {
        double luminance = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
        return luminance > 170 ? Color.BLACK : Color.WHITE;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class UtmCoordinate {
        final boolean valid;
        final int zone;
        final String hemisphere;
        final double easting;
        final double northing;

        UtmCoordinate(boolean valid, int zone, String hemisphere, double easting, double northing) {
            this.valid = valid;
            this.zone = zone;
            this.hemisphere = hemisphere;
            this.easting = easting;
            this.northing = northing;
        }

        static UtmCoordinate invalid() {
            return new UtmCoordinate(false, 0, "", Double.NaN, Double.NaN);
        }
    }

    private static final class GpsPoint {
        String project;
        String name;
        String description;
        double latitude;
        double longitude;
        double altitude;
        double accuracy;
        double speedKmh;
        double bearing;
        long timestamp;
        String provider;
        String photoUri;

        static GpsPoint fromLocation(String project, String name, String description, Location location) {
            GpsPoint p = new GpsPoint();
            p.project = project == null || project.trim().isEmpty() ? "Proyecto general" : project;
            p.name = name;
            p.description = description == null ? "" : description;
            p.latitude = location.getLatitude();
            p.longitude = location.getLongitude();
            p.altitude = location.hasAltitude() ? location.getAltitude() : Double.NaN;
            p.accuracy = location.hasAccuracy() ? location.getAccuracy() : Double.NaN;
            p.speedKmh = location.hasSpeed() ? location.getSpeed() * 3.6 : Double.NaN;
            p.bearing = location.hasBearing() && location.hasSpeed() && location.getSpeed() >= 0.8f
                    ? normalizeBearing(location.getBearing()) : Double.NaN;
            p.timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
            p.provider = location.getProvider() == null ? "" : location.getProvider();
            p.photoUri = "";
            return p;
        }

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("project", project);
                o.put("name", name);
                o.put("description", description);
                o.put("latitude", latitude);
                o.put("longitude", longitude);
                putOptional(o, "altitude", altitude);
                putOptional(o, "accuracy", accuracy);
                putOptional(o, "speedKmh", speedKmh);
                putOptional(o, "bearing", bearing);
                o.put("timestamp", timestamp);
                o.put("provider", provider);
                o.put("photoUri", photoUri == null ? "" : photoUri);
            } catch (JSONException ignored) {
            }
            return o;
        }

        static GpsPoint fromJson(JSONObject o) {
            GpsPoint p = new GpsPoint();
            p.project = o.optString("project", "Proyecto general");
            p.name = o.optString("name", "Punto");
            p.description = o.optString("description", "");
            p.latitude = o.optDouble("latitude", 0.0);
            p.longitude = o.optDouble("longitude", 0.0);
            p.altitude = optionalDouble(o, "altitude");
            p.accuracy = optionalDouble(o, "accuracy");
            p.speedKmh = optionalDouble(o, "speedKmh");
            p.bearing = optionalDouble(o, "bearing");
            p.timestamp = o.optLong("timestamp", System.currentTimeMillis());
            p.provider = o.optString("provider", "");
            p.photoUri = o.optString("photoUri", "");
            return p;
        }

        private static void putOptional(JSONObject o, String key, double value) throws JSONException {
            if (Double.isNaN(value) || Double.isInfinite(value)) o.put(key, JSONObject.NULL);
            else o.put(key, value);
        }

        private static double optionalDouble(JSONObject o, String key) {
            if (!o.has(key) || o.isNull(key)) return Double.NaN;
            return o.optDouble(key, Double.NaN);
        }
    }
}
