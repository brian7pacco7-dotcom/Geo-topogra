package com.bph.geotopo;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class ConverterActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;
    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68), Color.rgb(158, 169, 181), Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int accentColor;
    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int strokeColor;

    private Spinner categorySpinner;
    private Spinner fromSpinner;
    private Spinner toSpinner;
    private EditText inputView;
    private TextView resultView;
    private TextView formulaView;

    private final LinkedHashMap<String, UnitCategory> categories = new LinkedHashMap<>();
    private UnitCategory currentCategory;
    private boolean updatingSpinners;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        buildCategories();
        buildUi();
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        int theme = sp.getInt("theme", THEME_DARK);
        int accent = sp.getInt("accent", 0);
        accentColor = ACCENTS[((accent % ACCENTS.length) + ACCENTS.length) % ACCENTS.length];
        if (theme == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(94, 101, 112);
            strokeColor = Color.rgb(196, 202, 212);
        } else if (theme == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            strokeColor = Color.rgb(79, 85, 96);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            strokeColor = Color.rgb(92, 112, 132);
        }
    }

    private void buildCategories() {
        UnitCategory length = new UnitCategory("Longitud", false);
        length.add("milímetros (mm)", 0.001);
        length.add("centímetros (cm)", 0.01);
        length.add("metros (m)", 1.0);
        length.add("kilómetros (km)", 1000.0);
        length.add("pulgadas (in)", 0.0254);
        length.add("pies (ft)", 0.3048);
        length.add("yardas (yd)", 0.9144);
        length.add("millas (mi)", 1609.344);
        categories.put(length.name, length);

        UnitCategory area = new UnitCategory("Área", false);
        area.add("milímetros² (mm²)", 0.000001);
        area.add("centímetros² (cm²)", 0.0001);
        area.add("metros² (m²)", 1.0);
        area.add("hectáreas (ha)", 10000.0);
        area.add("kilómetros² (km²)", 1000000.0);
        area.add("pies² (ft²)", 0.09290304);
        area.add("acres", 4046.8564224);
        categories.put(area.name, area);

        UnitCategory volume = new UnitCategory("Volumen", false);
        volume.add("mililitros (mL)", 0.000001);
        volume.add("litros (L)", 0.001);
        volume.add("centímetros³ (cm³)", 0.000001);
        volume.add("metros³ (m³)", 1.0);
        volume.add("pies³ (ft³)", 0.028316846592);
        volume.add("galones US", 0.003785411784);
        categories.put(volume.name, volume);

        UnitCategory speed = new UnitCategory("Velocidad", false);
        speed.add("metros/s (m/s)", 1.0);
        speed.add("kilómetros/h (km/h)", 1.0 / 3.6);
        speed.add("pies/s (ft/s)", 0.3048);
        speed.add("millas/h (mph)", 0.44704);
        categories.put(speed.name, speed);

        UnitCategory angle = new UnitCategory("Ángulo y pendiente", true);
        angle.add("grados (°)", 1.0);
        angle.add("radianes (rad)", 1.0);
        angle.add("grados centesimales (gon)", 1.0);
        angle.add("pendiente (%)", 1.0);
        categories.put(angle.name, angle);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(28));
        content.setBackgroundColor(bgColor);

        LinearLayout intro = card();
        TextView title = text("Conversor de unidades", 22, true);
        intro.addView(title);
        TextView subtitle = text("Conversiones útiles para campo y cálculos topográficos. Funciona sin internet.", 13, false);
        subtitle.setTextColor(subTextColor);
        subtitle.setPadding(0, dp(4), 0, 0);
        intro.addView(subtitle);
        content.addView(intro);

        LinearLayout converter = card();
        converter.addView(label("Categoría"));
        categorySpinner = spinner(categories.keySet().toArray(new String[0]));
        converter.addView(categorySpinner, matchWrap());

        LinearLayout unitsRow = new LinearLayout(this);
        unitsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout fromCol = new LinearLayout(this);
        fromCol.setOrientation(LinearLayout.VERTICAL);
        fromCol.addView(label("Convertir de"));
        fromSpinner = spinner(new String[0]);
        fromCol.addView(fromSpinner, matchWrap());
        unitsRow.addView(fromCol, weightParams());

        LinearLayout toCol = new LinearLayout(this);
        toCol.setOrientation(LinearLayout.VERTICAL);
        toCol.setPadding(dp(8), 0, 0, 0);
        toCol.addView(label("Convertir a"));
        toSpinner = spinner(new String[0]);
        toCol.addView(toSpinner, matchWrap());
        unitsRow.addView(toCol, weightParams());
        converter.addView(unitsRow);

        converter.addView(label("Valor"));
        inputView = new EditText(this);
        inputView.setSingleLine(true);
        inputView.setTextColor(textColor);
        inputView.setHintTextColor(subTextColor);
        inputView.setHint("Escribe un número");
        inputView.setTextSize(20);
        inputView.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        inputView.setPadding(dp(14), dp(12), dp(14), dp(12));
        inputView.setBackground(fieldBackground());
        converter.addView(inputView, matchWrap());

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, dp(10), 0, 0);
        Button swap = secondaryButton("⇄ Intercambiar");
        swap.setOnClickListener(v -> swapUnits());
        actionRow.addView(swap, weightParams());
        Button clear = secondaryButton("Limpiar");
        clear.setOnClickListener(v -> inputView.setText(""));
        actionRow.addView(clear, weightParams());
        converter.addView(actionRow);
        content.addView(converter);

        LinearLayout resultCard = card();
        TextView resultTitle = text("Resultado", 15, true);
        resultTitle.setTextColor(accentColor);
        resultCard.addView(resultTitle);
        resultView = text("—", 28, true);
        resultView.setTextColor(textColor);
        resultView.setPadding(0, dp(8), 0, dp(3));
        resultView.setTextIsSelectable(true);
        resultCard.addView(resultView);
        formulaView = text("Escribe un valor para convertir.", 12, false);
        formulaView.setTextColor(subTextColor);
        resultCard.addView(formulaView);
        Button copy = primaryButton("Copiar resultado");
        copy.setOnClickListener(v -> copyResult());
        LinearLayout.LayoutParams copyLp = matchWrap();
        copyLp.setMargins(0, dp(12), 0, 0);
        resultCard.addView(copy, copyLp);
        content.addView(resultCard);

        TextView note = text("Incluye longitud, área, volumen, velocidad y conversión entre ángulos y pendiente.", 12, false);
        note.setTextColor(subTextColor);
        note.setPadding(dp(4), dp(4), dp(4), 0);
        content.addView(note);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (updatingSpinners) return;
                String key = String.valueOf(parent.getItemAtPosition(position));
                currentCategory = categories.get(key);
                updateUnitSpinners();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        AdapterView.OnItemSelectedListener recalcListener = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { recalculate(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        };
        fromSpinner.setOnItemSelectedListener(recalcListener);
        toSpinner.setOnItemSelectedListener(recalcListener);
        inputView.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { recalculate(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        currentCategory = categories.values().iterator().next();
        updateUnitSpinners();
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(9), dp(14), dp(9));
        bar.setBackgroundColor(appBarColor);

        TextView back = text("‹", 40, true);
        back.setTextColor(Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Volver");
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Conversor", 23, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView sub = text("Unidades topográficas y de campo", 12, false);
        sub.setTextColor(Color.rgb(193, 218, 240));
        titles.addView(sub);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    private void updateUnitSpinners() {
        if (currentCategory == null) return;
        updatingSpinners = true;
        String[] labels = currentCategory.units.keySet().toArray(new String[0]);
        fromSpinner.setAdapter(new ThemedAdapter(this, labels));
        toSpinner.setAdapter(new ThemedAdapter(this, labels));
        if (labels.length > 1) toSpinner.setSelection(Math.min(1, labels.length - 1));
        updatingSpinners = false;
        recalculate();
    }

    private void swapUnits() {
        int from = fromSpinner.getSelectedItemPosition();
        int to = toSpinner.getSelectedItemPosition();
        updatingSpinners = true;
        fromSpinner.setSelection(to);
        toSpinner.setSelection(from);
        updatingSpinners = false;
        recalculate();
    }

    private void recalculate() {
        if (currentCategory == null || inputView == null || resultView == null) return;
        String raw = inputView.getText().toString().trim().replace(',', '.');
        if (raw.isEmpty() || raw.equals("-") || raw.equals(".")) {
            resultView.setText("—");
            formulaView.setText("Escribe un valor para convertir.");
            return;
        }
        try {
            double value = Double.parseDouble(raw);
            String from = String.valueOf(fromSpinner.getSelectedItem());
            String to = String.valueOf(toSpinner.getSelectedItem());
            double result;
            if (currentCategory.angleMode) {
                double radians = angleToRadians(value, from);
                result = radiansToAngle(radians, to);
                if (Double.isNaN(result) || Double.isInfinite(result) || Math.abs(result) > 1.0e15) {
                    throw new IllegalArgumentException("El resultado no es finito para ese ángulo.");
                }
            } else {
                Double fromFactor = currentCategory.units.get(from);
                Double toFactor = currentCategory.units.get(to);
                if (fromFactor == null || toFactor == null) return;
                result = value * fromFactor / toFactor;
            }
            resultView.setText(formatNumber(result) + " " + shortUnit(to));
            formulaView.setText(formatNumber(value) + " " + shortUnit(from) + " = "
                    + formatNumber(result) + " " + shortUnit(to));
        } catch (Exception ex) {
            resultView.setText("Valor no válido");
            formulaView.setText(ex.getMessage() == null ? "Revisa el número ingresado." : ex.getMessage());
        }
    }

    private double angleToRadians(double value, String unit) {
        if (unit.startsWith("grados (")) return Math.toRadians(value);
        if (unit.startsWith("radianes")) return value;
        if (unit.startsWith("grados centesimales")) return value * Math.PI / 200.0;
        if (unit.startsWith("pendiente")) return Math.atan(value / 100.0);
        return value;
    }

    private double radiansToAngle(double radians, String unit) {
        if (unit.startsWith("grados (")) return Math.toDegrees(radians);
        if (unit.startsWith("radianes")) return radians;
        if (unit.startsWith("grados centesimales")) return radians * 200.0 / Math.PI;
        if (unit.startsWith("pendiente")) return Math.tan(radians) * 100.0;
        return radians;
    }

    private String shortUnit(String label) {
        int a = label.indexOf('(');
        int b = label.indexOf(')');
        if (a >= 0 && b > a) return label.substring(a + 1, b);
        if (label.equals("acres")) return "acres";
        if (label.equals("galones US")) return "gal US";
        return label;
    }

    private String formatNumber(double value) {
        double abs = Math.abs(value);
        if ((abs > 0 && abs < 0.000001) || abs >= 1.0e10) {
            return String.format(Locale.US, "%.8e", value);
        }
        DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.US);
        DecimalFormat df = new DecimalFormat("0.##########", symbols);
        return df.format(value);
    }

    private void copyResult() {
        String value = resultView == null ? "" : resultView.getText().toString();
        if (value.isEmpty() || value.equals("—") || value.startsWith("Valor")) {
            Toast.makeText(this, "Todavía no hay un resultado para copiar.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Conversión GeoTopo", value));
        Toast.makeText(this, "Resultado copiado", Toast.LENGTH_SHORT).show();
    }

    private Spinner spinner(String[] items) {
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ThemedAdapter(this, items));
        spinner.setPadding(dp(10), dp(4), dp(8), dp(4));
        spinner.setBackground(fieldBackground());
        return spinner;
    }

    private final class ThemedAdapter extends ArrayAdapter<String> {
        ThemedAdapter(Context context, String[] values) {
            super(context, android.R.layout.simple_spinner_item, values);
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView view = (TextView) super.getView(position, convertView, parent);
            view.setTextColor(textColor);
            view.setTextSize(15);
            view.setPadding(dp(8), dp(10), dp(8), dp(10));
            return view;
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            TextView view = (TextView) super.getDropDownView(position, convertView, parent);
            view.setTextColor(textColor);
            view.setTextSize(15);
            view.setBackgroundColor(cardColor);
            view.setPadding(dp(14), dp(13), dp(14), dp(13));
            return view;
        }
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), strokeColor);
        card.setBackground(bg);
        card.setElevation(dp(3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(lp);
        return card;
    }

    private GradientDrawable fieldBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cardColor);
        gd.setCornerRadius(dp(13));
        gd.setStroke(dp(1), strokeColor);
        return gd;
    }

    private TextView text(String value, float size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(textColor);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private TextView label(String value) {
        TextView view = text(value, 12, true);
        view.setTextColor(subTextColor);
        view.setPadding(dp(2), dp(10), 0, dp(5));
        return view;
    }

    private Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accentColor);
        bg.setCornerRadius(dp(14));
        button.setBackground(bg);
        return button;
    }

    private Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setTextSize(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), accentColor);
        button.setBackground(bg);
        return button;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class UnitCategory {
        final String name;
        final boolean angleMode;
        final LinkedHashMap<String, Double> units = new LinkedHashMap<>();

        UnitCategory(String name, boolean angleMode) {
            this.name = name;
            this.angleMode = angleMode;
        }

        void add(String label, double factor) {
            units.put(label, factor);
        }
    }
}
