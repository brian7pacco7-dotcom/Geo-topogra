package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

public class ConverterActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;
    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68), Color.rgb(158, 169, 181), Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int accentColor;
    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int strokeColor;

    private final LinkedHashMap<String, UnitCategory> categories = new LinkedHashMap<>();
    private UnitCategory currentCategory;
    private String fromUnit;
    private String toUnit;

    private Button categoryButton;
    private Button fromButton;
    private Button toButton;
    private EditText inputView;
    private TextView conversionSummaryView;
    private TextView resultView;
    private TextView formulaView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        buildCategories();
        currentCategory = categories.values().iterator().next();
        chooseDefaults();
        buildUi();
        refreshSelectors();
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        int theme = sp.getInt("theme", THEME_DARK);
        int accent = sp.getInt("accent", 0);
        accentColor = ACCENTS[((accent % ACCENTS.length) + ACCENTS.length) % ACCENTS.length];
        if (theme == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(94, 101, 112);
            strokeColor = Color.rgb(196, 202, 212);
        } else if (theme == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            strokeColor = Color.rgb(79, 85, 96);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            strokeColor = Color.rgb(92, 112, 132);
        }
    }

    private void buildCategories() {
        // Se mantienen nombres simples y claros, como en un conversor convencional.
        UnitCategory area = new UnitCategory("Área", false);
        area.add("milímetros² (mm²)", 0.000001);
        area.add("centímetros² (cm²)", 0.0001);
        area.add("metros² (m²)", 1.0);
        area.add("hectáreas (ha)", 10000.0);
        area.add("kilómetros² (km²)", 1000000.0);
        area.add("pulgadas² (in²)", 0.00064516);
        area.add("pies² (ft²)", 0.09290304);
        area.add("yardas² (yd²)", 0.83612736);
        area.add("acres (ac)", 4046.8564224);
        area.add("millas² (mi²)", 2589988.110336);
        categories.put(area.name, area);

        UnitCategory distance = new UnitCategory("Distancia", false);
        distance.add("milímetros (mm)", 0.001);
        distance.add("centímetros (cm)", 0.01);
        distance.add("metros (m)", 1.0);
        distance.add("kilómetros (km)", 1000.0);
        distance.add("pulgadas (in)", 0.0254);
        distance.add("pies (ft)", 0.3048);
        distance.add("yardas (yd)", 0.9144);
        distance.add("millas (mi)", 1609.344);
        distance.add("millas náuticas (nmi)", 1852.0);
        categories.put(distance.name, distance);

        UnitCategory weight = new UnitCategory("Peso", false);
        weight.add("miligramos (mg)", 0.000001);
        weight.add("gramos (g)", 0.001);
        weight.add("kilogramos (kg)", 1.0);
        weight.add("toneladas (t)", 1000.0);
        weight.add("onzas (oz)", 0.028349523125);
        weight.add("libras (lb)", 0.45359237);
        categories.put(weight.name, weight);

        UnitCategory volume = new UnitCategory("Volumen", false);
        volume.add("milímetros³ (mm³)", 0.000000001);
        volume.add("centímetros³ (cm³)", 0.000001);
        volume.add("mililitros (mL)", 0.000001);
        volume.add("litros (L)", 0.001);
        volume.add("metros³ (m³)", 1.0);
        volume.add("pulgadas³ (in³)", 0.000016387064);
        volume.add("pies³ (ft³)", 0.028316846592);
        volume.add("galones US (gal US)", 0.003785411784);
        volume.add("galones imperiales (gal imp)", 0.00454609);
        categories.put(volume.name, volume);

        UnitCategory energy = new UnitCategory("Energía", false);
        energy.add("julios (J)", 1.0);
        energy.add("kilojulios (kJ)", 1000.0);
        energy.add("calorías (cal)", 4.184);
        energy.add("kilocalorías (kcal)", 4184.0);
        energy.add("vatios-hora (Wh)", 3600.0);
        energy.add("kilovatios-hora (kWh)", 3600000.0);
        categories.put(energy.name, energy);

        UnitCategory temperature = new UnitCategory("Temperatura", false);
        // Base interna: kelvin. base = valor * factor + offset.
        temperature.addAffine("Celsius (°C)", 1.0, 273.15);
        temperature.addAffine("Fahrenheit (°F)", 5.0 / 9.0, 255.3722222222222);
        temperature.addAffine("Kelvin (K)", 1.0, 0.0);
        categories.put(temperature.name, temperature);

        UnitCategory speed = new UnitCategory("Velocidad", false);
        speed.add("metros/s (m/s)", 1.0);
        speed.add("kilómetros/h (km/h)", 1.0 / 3.6);
        speed.add("pies/s (ft/s)", 0.3048);
        speed.add("millas/h (mph)", 0.44704);
        speed.add("nudos (kn)", 0.5144444444444445);
        categories.put(speed.name, speed);

        UnitCategory power = new UnitCategory("Potencia", false);
        power.add("vatios (W)", 1.0);
        power.add("kilovatios (kW)", 1000.0);
        power.add("megavatios (MW)", 1000000.0);
        power.add("caballos de fuerza (hp)", 745.6998715822702);
        power.add("caballos métricos (CV)", 735.49875);
        categories.put(power.name, power);

        // Esta categoría adicional sí es útil para topografía y se conserva.
        UnitCategory angle = new UnitCategory("Ángulo y pendiente", true);
        angle.add("grados (°)", 1.0);
        angle.add("radianes (rad)", 1.0);
        angle.add("grados centesimales (gon)", 1.0);
        angle.add("pendiente (%)", 1.0);
        categories.put(angle.name, angle);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(28));
        content.setBackgroundColor(bgColor);

        LinearLayout intro = card();
        intro.addView(text("Conversor de unidades", 22, true));
        TextView introText = text("Elige una categoría, selecciona las dos unidades y escribe el valor. Funciona sin internet.", 13, false);
        introText.setTextColor(subTextColor);
        introText.setPadding(0, dp(4), 0, 0);
        intro.addView(introText);
        content.addView(intro);

        LinearLayout converter = card();
        converter.addView(label("Categoría"));
        categoryButton = selectorButton();
        categoryButton.setOnClickListener(v -> showCategoryChooser());
        converter.addView(categoryButton, matchWrap());

        conversionSummaryView = text("", 15, true);
        conversionSummaryView.setTextColor(accentColor);
        conversionSummaryView.setPadding(dp(2), dp(14), dp(2), dp(6));
        converter.addView(conversionSummaryView);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout fromCol = new LinearLayout(this);
        fromCol.setOrientation(LinearLayout.VERTICAL);
        fromCol.addView(label("Convertir de"));
        fromButton = selectorButton();
        fromButton.setOnClickListener(v -> showUnitChooser(true));
        fromCol.addView(fromButton, matchWrap());
        row.addView(fromCol, weightParamsWrap());

        LinearLayout toCol = new LinearLayout(this);
        toCol.setOrientation(LinearLayout.VERTICAL);
        toCol.setPadding(dp(8), 0, 0, 0);
        toCol.addView(label("Convertir a"));
        toButton = selectorButton();
        toButton.setOnClickListener(v -> showUnitChooser(false));
        toCol.addView(toButton, matchWrap());
        row.addView(toCol, weightParamsWrap());
        converter.addView(row);

        converter.addView(label("Valor"));
        inputView = new EditText(this);
        inputView.setSingleLine(true);
        inputView.setTextColor(textColor);
        inputView.setHintTextColor(subTextColor);
        inputView.setHint("Escribe un número");
        inputView.setTextSize(20);
        inputView.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        inputView.setPadding(dp(14), dp(12), dp(14), dp(12));
        inputView.setBackground(fieldBackground());
        converter.addView(inputView, matchWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(10), 0, 0);
        Button swap = secondaryButton("⇄ Intercambiar");
        swap.setOnClickListener(v -> swapUnits());
        actions.addView(swap, weightParams());
        Button clear = secondaryButton("Limpiar");
        clear.setOnClickListener(v -> inputView.setText(""));
        actions.addView(clear, weightParams());
        converter.addView(actions);
        content.addView(converter);

        LinearLayout resultCard = card();
        TextView resultTitle = text("Resultado", 15, true);
        resultTitle.setTextColor(accentColor);
        resultCard.addView(resultTitle);
        resultView = text("—", 28, true);
        resultView.setPadding(0, dp(8), 0, dp(3));
        resultView.setTextIsSelectable(true);
        resultCard.addView(resultView);
        formulaView = text("Escribe un valor para convertir.", 12, false);
        formulaView.setTextColor(subTextColor);
        resultCard.addView(formulaView);
        Button copy = primaryButton("Copiar resultado");
        copy.setOnClickListener(v -> copyResult());
        LinearLayout.LayoutParams copyLp = matchWrap();
        copyLp.setMargins(0, dp(12), 0, 0);
        resultCard.addView(copy, copyLp);
        content.addView(resultCard);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        inputView.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { recalculate(); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void showCategoryChooser() {
        String[] names = categories.keySet().toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Elige una categoría")
                .setItems(names, (d, which) -> {
                    currentCategory = categories.get(names[which]);
                    chooseDefaults();
                    refreshSelectors();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showUnitChooser(boolean from) {
        if (currentCategory == null) return;
        String[] units = currentCategory.units.keySet().toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle(from ? "Convertir de" : "Convertir a")
                .setItems(units, (d, which) -> {
                    if (from) fromUnit = units[which];
                    else toUnit = units[which];
                    refreshSelectors();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void chooseDefaults() {
        List<String> units = new ArrayList<>(currentCategory.units.keySet());
        if (units.isEmpty()) {
            fromUnit = "";
            toUnit = "";
            return;
        }
        fromUnit = units.get(0);
        toUnit = units.get(Math.min(1, units.size() - 1));
        if ("Área".equals(currentCategory.name)) {
            fromUnit = "metros² (m²)";
            toUnit = "hectáreas (ha)";
        } else if ("Distancia".equals(currentCategory.name)) {
            fromUnit = "metros (m)";
            toUnit = "kilómetros (km)";
        } else if ("Peso".equals(currentCategory.name)) {
            fromUnit = "kilogramos (kg)";
            toUnit = "libras (lb)";
        } else if ("Volumen".equals(currentCategory.name)) {
            fromUnit = "litros (L)";
            toUnit = "metros³ (m³)";
        } else if ("Energía".equals(currentCategory.name)) {
            fromUnit = "julios (J)";
            toUnit = "kilocalorías (kcal)";
        } else if ("Temperatura".equals(currentCategory.name)) {
            fromUnit = "Celsius (°C)";
            toUnit = "Fahrenheit (°F)";
        } else if ("Velocidad".equals(currentCategory.name)) {
            fromUnit = "kilómetros/h (km/h)";
            toUnit = "metros/s (m/s)";
        } else if ("Potencia".equals(currentCategory.name)) {
            fromUnit = "kilovatios (kW)";
            toUnit = "caballos de fuerza (hp)";
        } else if ("Ángulo y pendiente".equals(currentCategory.name)) {
            fromUnit = "grados (°)";
            toUnit = "pendiente (%)";
        }
    }

    private void refreshSelectors() {
        if (categoryButton == null) return;
        categoryButton.setText(currentCategory.name + "  ▾");
        fromButton.setText(fromUnit + "  ▾");
        toButton.setText(toUnit + "  ▾");
        conversionSummaryView.setText("Convierte " + fromUnit + " → " + toUnit);
        recalculate();
    }

    private void swapUnits() {
        String temp = fromUnit;
        fromUnit = toUnit;
        toUnit = temp;
        refreshSelectors();
    }

    private void recalculate() {
        if (inputView == null || resultView == null || currentCategory == null) return;
        String raw = inputView.getText().toString().trim().replace(',', '.');
        if (raw.isEmpty() || raw.equals("-") || raw.equals(".")) {
            resultView.setText("—");
            formulaView.setText("Escribe un valor para convertir.");
            return;
        }
        try {
            double value = Double.parseDouble(raw);
            double result;
            if (currentCategory.angleMode) {
                result = radiansToAngle(angleToRadians(value, fromUnit), toUnit);
            } else {
                UnitDefinition from = currentCategory.units.get(fromUnit);
                UnitDefinition to = currentCategory.units.get(toUnit);
                if (from == null || to == null) throw new IllegalArgumentException("Unidad no válida");
                double baseValue = value * from.factor + from.offset;
                result = (baseValue - to.offset) / to.factor;
            }
            if (Double.isNaN(result) || Double.isInfinite(result)) {
                throw new IllegalArgumentException("Resultado no válido");
            }
            resultView.setText(formatNumber(result) + " " + shortUnit(toUnit));
            formulaView.setText(formatNumber(value) + " " + shortUnit(fromUnit) + " = "
                    + formatNumber(result) + " " + shortUnit(toUnit));
        } catch (Exception ex) {
            resultView.setText("Valor no válido");
            formulaView.setText("Revisa el número y las unidades elegidas.");
        }
    }

    private double angleToRadians(double value, String unit) {
        if (unit.startsWith("grados (")) return Math.toRadians(value);
        if (unit.startsWith("radianes")) return value;
        if (unit.startsWith("grados centesimales")) return value * Math.PI / 200.0;
        if (unit.startsWith("pendiente")) return Math.atan(value / 100.0);
        return value;
    }

    private double radiansToAngle(double radians, String unit) {
        if (unit.startsWith("grados (")) return Math.toDegrees(radians);
        if (unit.startsWith("radianes")) return radians;
        if (unit.startsWith("grados centesimales")) return radians * 200.0 / Math.PI;
        if (unit.startsWith("pendiente")) return Math.tan(radians) * 100.0;
        return radians;
    }

    private String shortUnit(String label) {
        int a = label.indexOf('(');
        int b = label.indexOf(')');
        if (a >= 0 && b > a) return label.substring(a + 1, b);
        if (label.equals("acres")) return "acres";
        if (label.equals("galones US")) return "gal US";
        return label;
    }

    private String formatNumber(double value) {
        double abs = Math.abs(value);
        if ((abs > 0 && abs < 0.000001) || abs >= 1.0e10) {
            return String.format(Locale.US, "%.8e", value);
        }
        return new DecimalFormat("0.##########", DecimalFormatSymbols.getInstance(Locale.US)).format(value);
    }

    private void copyResult() {
        String value = resultView.getText().toString();
        if (value.equals("—") || value.startsWith("Valor")) {
            Toast.makeText(this, "Todavía no hay un resultado.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Conversión GeoTopo", value));
        Toast.makeText(this, "Resultado copiado", Toast.LENGTH_SHORT).show();
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(9), dp(14), dp(9));
        bar.setBackgroundColor(appBarColor);

        TextView back = text("‹", 40, true);
        back.setTextColor(Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Volver");
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Conversor", 23, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView sub = text("Unidades topográficas y de campo", 12, false);
        sub.setTextColor(Color.rgb(193, 218, 240));
        titles.addView(sub);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    private Button selectorButton() {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        button.setTextColor(textColor);
        button.setTextSize(14);
        button.setPadding(dp(14), dp(8), dp(12), dp(8));
        button.setMinHeight(dp(54));
        button.setBackground(fieldBackground());
        return button;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), strokeColor);
        card.setBackground(bg);
        card.setElevation(dp(3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(lp);
        return card;
    }

    private GradientDrawable fieldBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cardColor);
        gd.setCornerRadius(dp(13));
        gd.setStroke(dp(1), strokeColor);
        return gd;
    }

    private TextView text(String value, float size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(textColor);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private TextView label(String value) {
        TextView view = text(value, 12, true);
        view.setTextColor(subTextColor);
        view.setPadding(dp(2), dp(10), 0, dp(5));
        return view;
    }

    private Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accentColor);
        bg.setCornerRadius(dp(14));
        button.setBackground(bg);
        return button;
    }

    private Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setTextSize(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), accentColor);
        button.setBackground(bg);
        return button;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private LinearLayout.LayoutParams weightParamsWrap() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class UnitDefinition {
        final double factor;
        final double offset;

        UnitDefinition(double factor, double offset) {
            this.factor = factor;
            this.offset = offset;
        }
    }

    private static final class UnitCategory {
        final String name;
        final boolean angleMode;
        final LinkedHashMap<String, UnitDefinition> units = new LinkedHashMap<>();

        UnitCategory(String name, boolean angleMode) {
            this.name = name;
            this.angleMode = angleMode;
        }

        void add(String label, double factor) {
            addAffine(label, factor, 0.0);
        }

        void addAffine(String label, double factor, double offset) {
            units.put(label, new UnitDefinition(factor, offset));
        }
    }
}
