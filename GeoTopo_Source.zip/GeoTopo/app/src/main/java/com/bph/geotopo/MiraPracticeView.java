package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Vista liviana dibujada por código para practicar lecturas de una mira tipo E.
 * No utiliza fotografías ni recursos bitmap.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int accentColor;
    private final int textColor;
    private final int subTextColor;
    private final int panelColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.accentColor = accentColor;
        this.textColor = textColor;
        this.subTextColor = subTextColor;
        this.panelColor = panelColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        int halfSpanMm = 35 + random.nextInt(76); // 35 mm a 110 mm por lado.
        int middleMm = 500 + random.nextInt(4001); // 0.500 m a 4.500 m.
        if (middleMm - halfSpanMm < 120) middleMm = 120 + halfSpanMm;
        if (middleMm + halfSpanMm > 4880) middleMm = 4880 - halfSpanMm;

        // Evita que todos los ejercicios caigan exactamente en una marca de centímetro.
        if (middleMm % 10 == 0) middleMm += 3 + random.nextInt(5);

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;

        double span = Math.max(0.36, (upperReading - lowerReading) + 0.18);
        double center = middleReading;
        visibleMin = Math.floor((center - span / 2.0) * 100.0) / 100.0;
        visibleMax = Math.ceil((center + span / 2.0) * 100.0) / 100.0;
        if (visibleMin < 0.0) {
            visibleMax -= visibleMin;
            visibleMin = 0.0;
        }
        if (visibleMax > 5.0) {
            visibleMin -= (visibleMax - 5.0);
            visibleMax = 5.0;
        }
        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = dp(400);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float footerHeight = dp(48);
        float cx = w / 2f;
        float cy = (h - footerHeight) / 2f;
        float radius = Math.min(w * 0.46f, (h - footerHeight) * 0.47f);
        float circleLeft = cx - radius;
        float circleTop = cy - radius;
        float circleRight = cx + radius;
        float circleBottom = cy + radius;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(14), dp(14), paint);

        Path fieldPath = new Path();
        fieldPath.addCircle(cx, cy, radius, Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(fieldPath);
        paint.setColor(Color.rgb(247, 247, 245));
        canvas.drawRect(circleLeft, circleTop, circleRight, circleBottom, paint);

        float staffWidth = Math.min(dp(112), radius * 0.72f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = circleTop - dp(4);
        float staffBottom = circleBottom + dp(4);

        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);
        paint.setColor(Color.rgb(72, 76, 82));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.2f));
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        float numberRight = staffLeft + staffWidth * 0.43f;
        float patternLeft = staffLeft + staffWidth * 0.48f;
        float patternRight = staffRight - dp(5);
        float centerLineX = patternLeft;

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.rgb(90, 93, 98));
        canvas.drawLine(centerLineX, staffTop, centerLineX, staffBottom, paint);

        int startCm = (int) Math.floor(visibleMin * 100.0) - 1;
        int endCm = (int) Math.ceil(visibleMax * 100.0) + 1;
        for (int cm = startCm; cm <= endCm; cm++) {
            double value = cm / 100.0;
            float y = readingToY(value, staffTop, staffBottom);
            if (y < staffTop - dp(3) || y > staffBottom + dp(3)) continue;

            boolean decimeter = floorMod(cm, 10) == 0;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(decimeter ? dp(1.2f) : dp(0.45f));
            paint.setColor(decimeter ? Color.rgb(102, 105, 110) : Color.rgb(213, 215, 218));
            canvas.drawLine(staffLeft, y, staffRight, y, paint);

            if (decimeter) {
                int dm = cm / 10;
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.rgb(24, 24, 26));
                paint.setTextSize(dp(18));
                paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                paint.setTextAlign(Paint.Align.RIGHT);
                String label = String.format(Locale.US, "%02d", Math.max(0, dm));
                canvas.drawText(label, numberRight - dp(3), y + dp(6), paint);
            }
        }

        // Cinco franjas rojas por cada tramo de 10 cm. Su ancho y lado cambian para imitar la mira tipo E.
        for (int cm = startCm; cm < endCm; cm++) {
            if (floorMod(cm, 2) != 0) continue;
            double bandLow = cm / 100.0;
            double bandHigh = (cm + 1) / 100.0;
            float yTop = readingToY(bandHigh, staffTop, staffBottom);
            float yBottom = readingToY(bandLow, staffTop, staffBottom);
            if (yBottom < staffTop || yTop > staffBottom) continue;

            int dm = floorDiv(cm, 10);
            int pos = floorMod(cm, 10);
            boolean extendRight = floorMod(dm, 2) == 0;
            float fullWidth = patternRight - patternLeft;
            float fraction;
            if (pos == 0 || pos == 8) fraction = 0.92f;
            else if (pos == 4) fraction = 0.78f;
            else fraction = 0.48f;
            float bandWidth = fullWidth * fraction;
            float left = extendRight ? patternLeft : patternRight - bandWidth;
            float right = extendRight ? patternLeft + bandWidth : patternRight;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(226, 35, 35));
            canvas.drawRect(left, yTop, right, yBottom, paint);
        }

        // Hilos del retículo.
        drawThread(canvas, "LS", upperReading, circleLeft, circleRight, staffTop, staffBottom, false);
        drawThread(canvas, "LM", middleReading, circleLeft, circleRight, staffTop, staffBottom, true);
        drawThread(canvas, "LI", lowerReading, circleLeft, circleRight, staffTop, staffBottom, false);

        canvas.restoreToCount(save);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(5));
        paint.setColor(Color.rgb(16, 22, 30));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(accentColor);
        canvas.drawCircle(cx, cy, radius - dp(4), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(11.5f));
        paint.setColor(subTextColor);
        canvas.drawText("14 = 1.40 m · 15 = 1.50 m", cx, h - dp(25), paint);
        canvas.drawText("Cada franja roja o blanca representa 1 cm", cx, h - dp(9), paint);
    }

    private void drawThread(Canvas canvas, String label, double reading, float left, float right,
                            float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(middle ? dp(2.4f) : dp(1.7f));
        paint.setColor(Color.rgb(20, 24, 29));
        canvas.drawLine(left + dp(4), y, right - dp(4), y, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accentColor);
        paint.setTextSize(dp(13));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(label, left + dp(11), y - dp(5), paint);

        // Pequeña marca central para que el cruce con la mira sea nítido.
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(Color.rgb(20, 24, 29));
        float cx = getWidth() / 2f;
        canvas.drawLine(cx, y - dp(7), cx, y + dp(7), paint);
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double t = (visibleMax - reading) / range;
        return (float) (top + t * (bottom - top));
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int floorDiv(int value, int divisor) {
        int quotient = value / divisor;
        int remainder = value % divisor;
        if (remainder != 0 && ((value < 0) != (divisor < 0))) quotient--;
        return quotient;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
