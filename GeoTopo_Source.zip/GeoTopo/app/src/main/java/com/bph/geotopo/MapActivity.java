package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private static final String MAP_PREFS = "geo_topo_offline_maps";
    private static final String KEY_MAPS = "map_packages";
    private static final int REQ_LOCATION = 9311;
    private static final double MAX_BASIC_AREA_KM2 = 12000.0;
    private static final double MAX_MEDIUM_AREA_KM2 = 2500.0;
    private static final double MAX_HIGH_AREA_KM2 = 80.0;
    private static final int MAX_OFFLINE_BYTES = 25 * 1024 * 1024;

    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;
    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68), Color.rgb(158, 169, 181), Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentColor;
    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int inputStrokeColor;

    private WebView webView;
    private boolean mapReady;
    private String currentMode = "standard";
    private double south = Double.NaN;
    private double west = Double.NaN;
    private double north = Double.NaN;
    private double east = Double.NaN;
    private int currentZoom = 5;
    private LocationManager locationManager;
    private Location currentLocation;
    private boolean followLocation;
    private TextView statusView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService downloadExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean cancelDownload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        buildUi();
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        int accentIndex = sp.getInt("accent", 0);
        accentColor = ACCENTS[((accentIndex % ACCENTS.length) + ACCENTS.length) % ACCENTS.length];
        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(94, 101, 112);
            inputStrokeColor = Color.rgb(196, 202, 212);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputStrokeColor = Color.rgb(79, 85, 96);
        } else {
            bgColor = Color.rgb(13, 18, 28);
            appBarColor = Color.rgb(6, 38, 63);
            cardColor = Color.rgb(22, 29, 40);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(184, 190, 198);
            inputStrokeColor = Color.rgb(85, 92, 104);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());
        root.addView(modeBar());

        webView = new WebView(this);
        webView.setBackgroundColor(bgColor);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.addJavascriptInterface(new MapBridge(), "Android");
        webView.setWebViewClient(new OfflineTileClient());
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(actionPanel());
        setContentView(root);
        webView.loadUrl("file:///android_asset/map.html");
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(10), dp(12), dp(10));
        bar.setBackgroundColor(appBarColor);

        TextView back = text("‹", 40, true);
        back.setTextColor(Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Mapa topográfico", 22, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView subtitle = text("Online, satélite y zonas offline", 12, false);
        subtitle.setTextColor(Color.rgb(193, 218, 240));
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button info = compactButton("ⓘ", false);
        info.setOnClickListener(v -> showMapInfo());
        bar.addView(info, new LinearLayout.LayoutParams(dp(52), dp(46)));
        return bar;
    }

    private View modeBar() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setBackgroundColor(cardColor);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(7), dp(8), dp(7));
        row.addView(modeButton("Estándar", "standard"));
        row.addView(modeButton("Satélite", "satellite"));
        row.addView(modeButton("Híbrido", "hybrid"));
        row.addView(modeButton("Topográfico", "topo"));
        row.addView(modeButton("Offline", "offline"));
        hsv.addView(row);
        return hsv;
    }

    private Button modeButton(String label, String mode) {
        Button b = compactButton(label, true);
        b.setOnClickListener(v -> {
            if ("offline".equals(mode)) showOfflineMaps();
            else setMode(mode);
        });
        return b;
    }

    private View actionPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(6), dp(8), dp(8));
        panel.setBackgroundColor(cardColor);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button locate = compactButton("⌖ Mi ubicación", true);
        locate.setOnClickListener(v -> centerOnCurrentLocation());
        row1.addView(locate, weightParams());
        Button minus = compactButton("−", true);
        minus.setOnClickListener(v -> js("zoomOut()"));
        row1.addView(minus, smallWeightParams());
        Button plus = compactButton("+", true);
        plus.setOnClickListener(v -> js("zoomIn()"));
        row1.addView(plus, smallWeightParams());
        Button points = compactButton("Puntos GPS", true);
        points.setOnClickListener(v -> loadSavedPoints(true));
        row1.addView(points, weightParams());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button measure = compactButton("📐 Medir", true);
        measure.setOnClickListener(v -> js("toggleMeasure()"));
        row2.addView(measure, weightParams());
        Button clearMeasure = compactButton("Limpiar medición", true);
        clearMeasure.setOnClickListener(v -> js("clearMeasure()"));
        row2.addView(clearMeasure, weightParams());
        panel.addView(row2);

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        Button download = compactButton("↓ Descargar zona", true);
        download.setOnClickListener(v -> showDownloadDialog());
        row3.addView(download, weightParams());
        Button manage = compactButton("▣ Mapas guardados", true);
        manage.setOnClickListener(v -> showOfflineMaps());
        row3.addView(manage, weightParams());
        panel.addView(row3);

        statusView = text("Mueve el mapa y elige el tipo de vista.", 11, false);
        statusView.setTextColor(subTextColor);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(4), dp(3), dp(4), 0);
        panel.addView(statusView);
        return panel;
    }

    private void setMode(String mode) {
        currentMode = mode;
        js("setMode(" + JSONObject.quote(mode) + ")");
        if ("satellite".equals(mode) || "hybrid".equals(mode)) {
            setStatus("Mapa satelital: necesita internet.");
        } else if ("topo".equals(mode) || "standard".equals(mode)) {
            setStatus("Mapa online. Descarga la zona actual para usarla después sin internet.");
        }
    }

    private void showMapInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Mapa de GeoTopo")
                .setMessage("Estándar, satélite, híbrido y topográfico usan internet. El modo offline descarga cartografía vectorial de una zona elegida: vías, agua, ferrocarril, uso de suelo y, en detalle alto, edificios. No descarga imagen satelital. El GPS y los puntos guardados funcionan sin internet.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void centerOnCurrentLocation() {
        followLocation = true;
        if (currentLocation != null) {
            sendLocationToMap(currentLocation, true);
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        startLocationUpdates();
    }

    private void startLocationUpdates() {
        if (locationManager == null) {
            setStatus("Ubicación no disponible.");
            return;
        }
        try {
            boolean any = false;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1200L, 0.5f, this);
                any = true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1600L, 1f, this);
                any = true;
            }
            if (!any) setStatus("Activa la ubicación del teléfono.");
            else setStatus("Buscando ubicación…");
        } catch (SecurityException e) {
            setStatus("Permiso de ubicación requerido.");
        }
    }

    private void stopLocationUpdates() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null) return;
        if (currentLocation == null || betterLocation(location, currentLocation)) currentLocation = new Location(location);
        sendLocationToMap(currentLocation, followLocation);
        followLocation = false;
        String accuracy = currentLocation.hasAccuracy() ? String.format(Locale.US, "± %.1f m", currentLocation.getAccuracy()) : "sin precisión";
        setStatus("Ubicación recibida: " + accuracy + ".");
    }

    private boolean betterLocation(Location candidate, Location current) {
        long dt = candidate.getTime() - current.getTime();
        if (dt > 30000L) return true;
        if (dt < -30000L) return false;
        if (!current.hasAccuracy()) return true;
        if (!candidate.hasAccuracy()) return dt > 0;
        return candidate.getAccuracy() <= current.getAccuracy() || (dt > 0 && candidate.getAccuracy() < current.getAccuracy() + 30f);
    }

    private void sendLocationToMap(Location location, boolean follow) {
        if (location == null) return;
        float accuracy = location.hasAccuracy() ? location.getAccuracy() : 0f;
        js(String.format(Locale.US, "showCurrentLocation(%.9f,%.9f,%.2f,%s)", location.getLatitude(), location.getLongitude(), accuracy, follow ? "true" : "false"));
    }

    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        boolean granted = false;
        for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
        if (granted) startLocationUpdates();
        else setStatus("Permiso de ubicación denegado.");
    }

    private void loadSavedPoints(boolean fit) {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        js("setPoints(" + JSONObject.quote(json) + "," + (fit ? "true" : "false") + ")");
        try {
            int count = new JSONArray(json).length();
            setStatus(count == 0 ? "No hay puntos GPS guardados." : "Mostrando " + count + " puntos GPS.");
        } catch (JSONException ignored) {
            setStatus("No se pudieron leer los puntos guardados.");
        }
    }

    private void showDownloadDialog() {
        if (Double.isNaN(south) || Double.isNaN(west) || Double.isNaN(north) || Double.isNaN(east)) {
            Toast.makeText(this, "Espera a que el mapa termine de cargar.", Toast.LENGTH_LONG).show();
            return;
        }
        final double[] selected = {south, west, north, east};
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(6), dp(8), dp(2));

        TextView note = text("Guarda un mapa vectorial offline con vías, ríos y elementos topográficos. No incluye imagen satelital. Puedes usar el área visible o buscar una provincia/departamento; los departamentos grandes deben descargarse por sectores.", 13, false);
        note.setTextColor(subTextColor);
        panel.addView(note);

        EditText place = new EditText(this);
        place.setHint("Provincia o departamento (opcional · búsqueda OSM)");
        place.setSingleLine(true);
        place.setInputType(InputType.TYPE_CLASS_TEXT);
        panel.addView(place);

        TextView areaInfo = text(formatAreaInfo(selected), 12, true);
        areaInfo.setTextColor(accentColor);
        areaInfo.setPadding(0, dp(4), 0, dp(4));
        panel.addView(areaInfo);

        Button search = compactButton("Buscar lugar", true);
        search.setOnClickListener(v -> searchOfflinePlace(place.getText().toString().trim(), selected, areaInfo));
        panel.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        EditText name = new EditText(this);
        name.setText("Zona_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()));
        name.setHint("Nombre del mapa");
        name.setSelectAllOnFocus(true);
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT);
        panel.addView(name);

        RadioGroup detail = new RadioGroup(this);
        RadioButton basic = radio("Básico: vías principales y agua");
        RadioButton medium = radio("Medio: red vial, agua, ferrocarril y uso de suelo");
        RadioButton high = radio("Alto: agrega edificios (solo áreas pequeñas)");
        detail.addView(basic); detail.addView(medium); detail.addView(high);
        medium.setChecked(true);
        panel.addView(detail);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Preparar mapa offline")
                .setView(panel)
                .setPositiveButton("Descargar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String displayName = name.getText().toString().trim();
            if (displayName.isEmpty()) {
                name.setError("Escribe un nombre");
                return;
            }
            double areaKm2 = bboxAreaKm2(selected[0], selected[1], selected[2], selected[3]);
            String level = high.isChecked() ? "alto" : basic.isChecked() ? "básico" : "medio";
            double maxArea = "alto".equals(level) ? MAX_HIGH_AREA_KM2
                    : "básico".equals(level) ? MAX_BASIC_AREA_KM2 : MAX_MEDIUM_AREA_KM2;
            if (areaKm2 <= 0 || areaKm2 > maxArea) {
                String advice = "básico".equals(level)
                        ? "Divide la provincia o departamento en varios sectores visibles."
                        : "Usa detalle básico o acerca el mapa a una zona más pequeña.";
                new AlertDialog.Builder(this)
                        .setTitle("Área demasiado grande")
                        .setMessage("El área seleccionada es de aproximadamente " + String.format(Locale.US, "%.0f", areaKm2)
                                + " km². Para detalle " + level + " el límite es " + String.format(Locale.US, "%.0f", maxArea)
                                + " km². " + advice)
                        .setPositiveButton("Entendido", null)
                        .show();
                return;
            }
            dialog.dismiss();
            new AlertDialog.Builder(this)
                    .setTitle("Confirmar descarga")
                    .setMessage("Zona: " + displayName + "\nÁrea aproximada: " + String.format(Locale.US, "%.1f", areaKm2)
                            + " km²\nDetalle: " + level + "\n\nSe descargará cartografía vectorial para usarla sin internet.")
                    .setPositiveButton("Descargar", (x, y) -> downloadVectorArea(displayName, level, selected))
                    .setNegativeButton("Cancelar", null)
                    .show();
        }));
        dialog.show();
    }

    private String formatAreaInfo(double[] b) {
        double km2 = bboxAreaKm2(b[0], b[1], b[2], b[3]);
        return "Área seleccionada: ≈ " + String.format(Locale.US, "%.1f", km2) + " km²";
    }

    private void searchOfflinePlace(String query, double[] selected, TextView areaInfo) {
        if (query == null || query.trim().length() < 3) {
            Toast.makeText(this, "Escribe el nombre de una provincia o departamento.", Toast.LENGTH_LONG).show();
            return;
        }
        areaInfo.setText("Buscando “" + query + "”…");
        cancelDownload = false;
        downloadExecutor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                String q = URLEncoder.encode(query + ", Perú", "UTF-8");
                URL url = new URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=pe&q=" + q);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(18000);
                connection.setRequestProperty("User-Agent", "GeoTopo/1.2 Android (com.bph.geotopo)");
                connection.setRequestProperty("Accept-Language", "es");
                if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 300) throw new Exception("HTTP");
                String json = readStream(connection.getInputStream(), 2 * 1024 * 1024);
                JSONArray results = new JSONArray(json);
                if (results.length() == 0) throw new Exception("EMPTY");
                JSONObject first = results.getJSONObject(0);
                JSONArray bb = first.getJSONArray("boundingbox");
                double s = Double.parseDouble(bb.getString(0));
                double n = Double.parseDouble(bb.getString(1));
                double w = Double.parseDouble(bb.getString(2));
                double e = Double.parseDouble(bb.getString(3));
                String display = first.optString("display_name", query);
                mainHandler.post(() -> {
                    selected[0] = s; selected[1] = w; selected[2] = n; selected[3] = e;
                    areaInfo.setText(display + "\n" + formatAreaInfo(selected));
                    js(String.format(Locale.US, "fitBounds(%.9f,%.9f,%.9f,%.9f)", s, w, n, e));
                });
            } catch (Exception ex) {
                mainHandler.post(() -> areaInfo.setText("No se encontró el lugar. Usa el área visible del mapa o prueba otro nombre."));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void downloadVectorArea(String displayName, String detail, double[] b) {
        final double s = b[0], w = b[1], n = b[2], e = b[3];
        final String folder = uniqueFolderName(displayName);
        final MapPackage pkg = new MapPackage();
        pkg.name = displayName;
        pkg.folder = folder;
        pkg.south = s; pkg.west = w; pkg.north = n; pkg.east = e;
        pkg.centerLat = (s + n) / 2.0;
        pkg.centerLon = centerLongitude(w, e);
        pkg.minZoom = Math.max(5, currentZoom);
        pkg.maxZoom = 19;
        pkg.openZoom = Math.max(8, currentZoom);
        pkg.createdAt = System.currentTimeMillis();
        pkg.detail = detail;

        ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("Descargando mapa offline");
        progress.setMessage("Consultando vías y elementos del área…");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setCancelable(true);
        cancelDownload = false;
        progress.setOnCancelListener(d -> cancelDownload = true);
        progress.show();

        downloadExecutor.execute(() -> {
            File packageDir = new File(offlineBaseDir(), folder);
            if (!packageDir.exists()) packageDir.mkdirs();
            File dataFile = new File(packageDir, "data.json");
            String query = buildOverpassQuery(detail, s, w, n, e);
            String error = null;
            int elementCount = 0;
            try {
                String response = postOverpass(query);
                if (cancelDownload) throw new InterruptedException("cancelled");
                JSONObject root = new JSONObject(response);
                JSONArray elements = root.optJSONArray("elements");
                elementCount = elements == null ? 0 : elements.length();
                if (elementCount == 0) throw new Exception("La zona no devolvió elementos cartográficos.");
                try (FileOutputStream out = new FileOutputStream(dataFile)) {
                    out.write(response.getBytes("UTF-8"));
                }
            } catch (InterruptedException ex) {
                error = "CANCELLED";
            } catch (Exception ex) {
                error = ex.getMessage() == null ? "No se pudo descargar la cartografía." : ex.getMessage();
            }
            final String finalError = error;
            final int finalCount = elementCount;
            mainHandler.post(() -> {
                if (progress.isShowing()) progress.dismiss();
                if (cancelDownload || "CANCELLED".equals(finalError)) {
                    deleteRecursive(packageDir);
                    setStatus("Descarga cancelada.");
                    return;
                }
                if (finalError != null || !dataFile.exists()) {
                    deleteRecursive(packageDir);
                    new AlertDialog.Builder(this)
                            .setTitle("No se pudo descargar")
                            .setMessage((finalError == null ? "Error desconocido." : finalError)
                                    + "\n\nPrueba con un área más pequeña o con detalle básico.")
                            .setPositiveButton("Cerrar", null)
                            .show();
                    return;
                }
                pkg.dataCount = finalCount;
                pkg.downloadedTiles = finalCount;
                saveMapPackage(pkg);
                openOfflinePackage(pkg);
                Toast.makeText(this, "Mapa offline guardado: " + pkg.name, Toast.LENGTH_LONG).show();
            });
        });
    }

    private String buildOverpassQuery(String detail, double s, double w, double n, double e) {
        String bbox = String.format(Locale.US, "(%.7f,%.7f,%.7f,%.7f)", s, w, n, e);
        StringBuilder q = new StringBuilder("[out:json][timeout:75];(");
        if ("básico".equals(detail)) {
            q.append("way[\"highway\"~\"motorway|trunk|primary|secondary|tertiary\"]").append(bbox).append(';');
            q.append("way[\"waterway\"]").append(bbox).append(';');
            q.append("way[\"natural\"=\"water\"]").append(bbox).append(';');
        } else {
            q.append("way[\"highway\"]").append(bbox).append(';');
            q.append("way[\"waterway\"]").append(bbox).append(';');
            q.append("way[\"railway\"]").append(bbox).append(';');
            q.append("way[\"natural\"=\"water\"]").append(bbox).append(';');
            q.append("way[\"landuse\"]").append(bbox).append(';');
            if ("alto".equals(detail)) {
                q.append("way[\"building\"]").append(bbox).append(';');
                q.append("node[\"place\"~\"city|town|village|hamlet\"]").append(bbox).append(';');
            }
        }
        q.append(");out geom;");
        return q.toString();
    }

    private String postOverpass(String query) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://overpass-api.de/api/interpreter");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(90000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.2 Android (com.bph.geotopo)");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            byte[] body = ("data=" + URLEncoder.encode(query, "UTF-8")).getBytes("UTF-8");
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body);
            }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String response = readStream(stream, MAX_OFFLINE_BYTES);
            if (code < 200 || code >= 300) throw new Exception("Servidor cartográfico respondió HTTP " + code + ".");
            return response;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readStream(InputStream input, int limitBytes) throws Exception {
        if (input == null) throw new Exception("Respuesta vacía.");
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            int total = 0;
            while ((read = in.read(buffer)) != -1) {
                if (cancelDownload) throw new InterruptedException("cancelled");
                total += read;
                if (total > limitBytes) throw new Exception("La zona genera demasiados datos. Reduce el área o el nivel de detalle.");
                out.write(buffer, 0, read);
            }
            return out.toString("UTF-8");
        }
    }

    private double bboxAreaKm2(double s, double w, double n, double e) {
        double midLat = Math.toRadians((s + n) / 2.0);
        double latKm = Math.abs(n - s) * 111.32;
        double lonDelta = Math.abs(e - w);
        if (lonDelta > 180) lonDelta = 360 - lonDelta;
        double lonKm = lonDelta * 111.32 * Math.max(0.05, Math.cos(midLat));
        return latKm * lonKm;
    }

    private void showOfflineMaps() {
        List<MapPackage> maps = loadMapPackages();
        if (maps.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Mapas guardados")
                    .setMessage("Todavía no hay mapas offline. Mueve y acerca el mapa, luego toca “Descargar zona”.")
                    .setPositiveButton("Cerrar", null)
                    .show();
            return;
        }
        String[] labels = new String[maps.size()];
        for (int i = 0; i < maps.size(); i++) {
            MapPackage p = maps.get(i);
            labels[i] = p.name + "\n" + (p.detail == null || p.detail.isEmpty() ? "Mapa vectorial" : "Detalle " + p.detail)
                    + " · " + p.dataCount + " elementos";
        }
        new AlertDialog.Builder(this)
                .setTitle("Mapas guardados")
                .setItems(labels, (d, which) -> showOfflineActions(maps.get(which)))
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showOfflineActions(MapPackage pkg) {
        String[] actions = {"Abrir sin internet", "Eliminar mapa"};
        new AlertDialog.Builder(this)
                .setTitle(pkg.name)
                .setItems(actions, (d, which) -> {
                    if (which == 0) openOfflinePackage(pkg);
                    else confirmDeleteOffline(pkg);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void openOfflinePackage(MapPackage pkg) {
        currentMode = "offline";
        js(String.format(Locale.US, "setOfflineVector(%s,%.9f,%.9f,%d,%.9f,%.9f,%.9f,%.9f)",
                JSONObject.quote(pkg.folder), pkg.centerLat, pkg.centerLon, pkg.openZoom,
                pkg.south, pkg.west, pkg.north, pkg.east));
        setStatus("Mapa vectorial offline abierto: " + pkg.name + ". Funciona sin internet dentro del área guardada.");
    }

    private void confirmDeleteOffline(MapPackage pkg) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar mapa")
                .setMessage("¿Eliminar “" + pkg.name + "” y sus datos cartográficos?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    deleteRecursive(new File(offlineBaseDir(), pkg.folder));
                    removeMapPackage(pkg.folder);
                    Toast.makeText(this, "Mapa eliminado", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private double centerLongitude(double w, double e) {
        if (w <= e) return (w + e) / 2.0;
        double value = (w + (e + 360.0)) / 2.0;
        if (value > 180.0) value -= 360.0;
        return value;
    }

    private File offlineBaseDir() {
        File external = getExternalFilesDir("offline_maps");
        File base = external != null ? external : new File(getFilesDir(), "offline_maps");
        if (!base.exists()) base.mkdirs();
        return base;
    }

    private String uniqueFolderName(String displayName) {
        String base = displayName.replaceAll("[^A-Za-z0-9_-]", "_").replaceAll("_+", "_");
        if (base.isEmpty()) base = "mapa";
        String folder = base;
        int index = 2;
        while (new File(offlineBaseDir(), folder).exists()) folder = base + "_" + index++;
        return folder;
    }

    private void saveMapPackage(MapPackage pkg) {
        List<MapPackage> maps = loadMapPackages();
        maps.add(pkg);
        JSONArray array = new JSONArray();
        for (MapPackage item : maps) array.put(item.toJson());
        getSharedPreferences(MAP_PREFS, MODE_PRIVATE).edit().putString(KEY_MAPS, array.toString()).apply();
    }

    private List<MapPackage> loadMapPackages() {
        List<MapPackage> maps = new ArrayList<>();
        String json = getSharedPreferences(MAP_PREFS, MODE_PRIVATE).getString(KEY_MAPS, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                MapPackage p = MapPackage.fromJson(o);
                if (p.folder != null) {
                    File folder = new File(offlineBaseDir(), p.folder);
                    File data = new File(folder, "data.json");
                    if (folder.exists() && data.exists() && data.length() > 0) maps.add(p);
                }
            }
        } catch (JSONException ignored) {}
        return maps;
    }

    private void removeMapPackage(String folder) {
        List<MapPackage> maps = loadMapPackages();
        JSONArray array = new JSONArray();
        for (MapPackage p : maps) if (!folder.equals(p.folder)) array.put(p.toJson());
        getSharedPreferences(MAP_PREFS, MODE_PRIVATE).edit().putString(KEY_MAPS, array.toString()).apply();
    }

    private boolean deleteRecursive(File file) {
        if (file == null || !file.exists()) return true;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        return file.delete();
    }

    private void js(String code) {
        if (webView == null) return;
        if (!mapReady) {
            mainHandler.postDelayed(() -> js(code), 250L);
            return;
        }
        webView.evaluateJavascript(code, null);
    }

    private void setStatus(String value) {
        if (statusView != null) statusView.setText(value);
    }

    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(textColor);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private Button compactButton(String value, boolean margins) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(bestContrastColor(accentColor));
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accentColor);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), accentColor);
        b.setBackground(bg);
        if (margins) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
            lp.setMargins(dp(3), 0, dp(3), 0);
            b.setLayoutParams(lp);
        }
        return b;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), dp(2), dp(3), dp(2));
        return lp;
    }

    private LinearLayout.LayoutParams smallWeightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(44));
        lp.setMargins(dp(3), dp(2), dp(3), dp(2));
        return lp;
    }

    private int bestContrastColor(int color) {
        double luminance = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
        return luminance > 170 ? Color.BLACK : Color.WHITE;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        stopLocationUpdates();
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopLocationUpdates();
        downloadExecutor.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private final class MapBridge {
        @JavascriptInterface
        public void onMapReady() {
            runOnUiThread(() -> {
                mapReady = true;
                loadSavedPoints(false);
                Intent intent = getIntent();
                if (intent != null && intent.hasExtra("latitude") && intent.hasExtra("longitude")) {
                    double lat = intent.getDoubleExtra("latitude", -9.19);
                    double lon = intent.getDoubleExtra("longitude", -75.015);
                    js(String.format(Locale.US, "centerOn(%.9f,%.9f,16)", lat, lon));
                }
            });
        }

        @JavascriptInterface
        public void onBoundsChanged(double s, double w, double n, double e, int z) {
            south = s; west = w; north = n; east = e; currentZoom = z;
        }

        @JavascriptInterface
        public void onMeasureResult(String text) {
            runOnUiThread(() -> setStatus(text == null || text.trim().isEmpty()
                    ? "Toca el mapa para medir distancia o área."
                    : text));
        }

        @JavascriptInterface
        public void onOfflineLoaded(int count) {
            runOnUiThread(() -> setStatus(count < 0
                    ? "No se pudieron abrir los datos del mapa offline."
                    : "Mapa offline cargado: " + count + " elementos cartográficos."));
        }
    }

    private final class OfflineTileClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (uri != null && "offline.local".equalsIgnoreCase(uri.getHost())) {
                List<String> parts = uri.getPathSegments();
                if (parts.size() == 2 && "data.json".equals(parts.get(1))) {
                    File data = new File(offlineBaseDir(), parts.get(0) + File.separator + "data.json");
                    if (data.exists() && data.length() > 0) {
                        try {
                            HashMap<String, String> headers = new HashMap<>();
                            headers.put("Access-Control-Allow-Origin", "*");
                            headers.put("Cache-Control", "no-store");
                            return new WebResourceResponse("application/json", "UTF-8", 200, "OK", headers, new FileInputStream(data));
                        } catch (Exception ignored) {}
                    }
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse("application/json", "UTF-8", 404, "Not Found", headers,
                            new java.io.ByteArrayInputStream("{\"elements\":[]}".getBytes()));
                }
            }
            return super.shouldInterceptRequest(view, request);
        }
    }

    private static final class MapPackage {
        String name;
        String folder;
        double south;
        double west;
        double north;
        double east;
        double centerLat;
        double centerLon;
        int minZoom;
        int maxZoom;
        int openZoom;
        int tileCount;
        int downloadedTiles;
        int dataCount;
        String detail;
        long createdAt;

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("name", name);
                o.put("folder", folder);
                o.put("south", south); o.put("west", west); o.put("north", north); o.put("east", east);
                o.put("centerLat", centerLat); o.put("centerLon", centerLon);
                o.put("minZoom", minZoom); o.put("maxZoom", maxZoom); o.put("openZoom", openZoom);
                o.put("tileCount", tileCount); o.put("downloadedTiles", downloadedTiles); o.put("dataCount", dataCount); o.put("detail", detail); o.put("createdAt", createdAt);
            } catch (JSONException ignored) {}
            return o;
        }

        static MapPackage fromJson(JSONObject o) {
            MapPackage p = new MapPackage();
            p.name = o.optString("name", "Mapa offline");
            p.folder = o.optString("folder", "");
            p.south = o.optDouble("south", 0); p.west = o.optDouble("west", 0); p.north = o.optDouble("north", 0); p.east = o.optDouble("east", 0);
            p.centerLat = o.optDouble("centerLat", 0); p.centerLon = o.optDouble("centerLon", 0);
            p.minZoom = o.optInt("minZoom", 10); p.maxZoom = o.optInt("maxZoom", 14); p.openZoom = o.optInt("openZoom", p.minZoom);
            p.tileCount = o.optInt("tileCount", 0); p.downloadedTiles = o.optInt("downloadedTiles", p.tileCount); p.dataCount = o.optInt("dataCount", p.downloadedTiles); p.detail = o.optString("detail", ""); p.createdAt = o.optLong("createdAt", 0L);
            return p;
        }
    }
}
