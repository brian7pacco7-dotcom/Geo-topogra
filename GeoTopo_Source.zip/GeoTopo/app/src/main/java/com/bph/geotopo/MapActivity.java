package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.text.InputType;
import android.util.JsonReader;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private static final String MAP_PREFS = "geo_topo_offline_maps";
    private static final String KEY_MAPS = "map_packages";
    private static final int REQ_LOCATION = 9311;
    // No hay un límite artificial para el tamaño total del mapa. Las zonas grandes
    // se dividen automáticamente en sectores para no saturar la memoria ni el servidor.
    private static final double TARGET_BASIC_CHUNK_KM2 = 900.0;
    private static final double TARGET_MEDIUM_CHUNK_KM2 = 160.0;
    private static final double TARGET_HIGH_CHUNK_KM2 = 12.0;
    private static final int MAX_ADAPTIVE_SPLIT_DEPTH = 5;
    private static final long MIN_FREE_STORAGE_BYTES = 8L * 1024L * 1024L;

    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;
    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68), Color.rgb(158, 169, 181), Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentColor;
    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int inputStrokeColor;

    private WebView webView;
    private boolean mapReady;
    private String currentMode = "standard";
    private double south = Double.NaN;
    private double west = Double.NaN;
    private double north = Double.NaN;
    private double east = Double.NaN;
    private int currentZoom = 5;
    private LocationManager locationManager;
    private Location currentLocation;
    private boolean followLocation;
    private boolean autoCenteredOnce;
    private TextView statusView;
    private TextView modeBadge;
    private TextView modeSubtitleView;
    private TextView measureButton;
    private LinearLayout measurePanel;
    private TextView measureTitleView;
    private TextView measureResultView;
    private TextView measureHintView;
    private LinearLayout mapDock;
    private LinearLayout downloadSelectionPanel;
    private TextView downloadSelectionInfoView;
    private boolean downloadSelectionActive;
    private double downloadSouth = Double.NaN;
    private double downloadWest = Double.NaN;
    private double downloadNorth = Double.NaN;
    private double downloadEast = Double.NaN;
    private String downloadSuggestedName = "";
    private String measurementMode = "distance";
    private boolean measurementActive = false;
    private int measurementPointCount = 0;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService downloadExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean cancelDownload;
    private final Runnable locationTimeout = () -> {
        if (currentLocation == null) {
            setStatus("No se obtuvo ubicación. Pulsa Ubicación para reintentar o abre GPS y puntos.");
        } else if (locationAgeMs(currentLocation) > 120000L) {
            setStatus("Mostrando la última ubicación guardada. Pulsa Ubicación para actualizar.");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        buildUi();
        if (getIntent().getBooleanExtra("show_saved_maps", false)) {
            mainHandler.postDelayed(this::showOfflineMaps, 650L);
        }
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        int accentIndex = sp.getInt("accent", 0);
        accentColor = ACCENTS[((accentIndex % ACCENTS.length) + ACCENTS.length) % ACCENTS.length];
        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(94, 101, 112);
            inputStrokeColor = Color.rgb(196, 202, 212);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputStrokeColor = Color.rgb(79, 85, 96);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputStrokeColor = Color.rgb(92, 112, 132);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());

        FrameLayout mapFrame = new FrameLayout(this);
        mapFrame.setBackgroundColor(bgColor);
        webView = new WebView(this);
        webView.setBackgroundColor(bgColor);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) settings.setOffscreenPreRaster(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webView.addJavascriptInterface(new MapBridge(), "Android");
        webView.setWebViewClient(new OfflineTileClient());
        mapFrame.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addMapOverlay(mapFrame);
        root.addView(mapFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        webView.loadUrl("file:///android_asset/map.html");
    }

    private void addMapOverlay(FrameLayout frame) {
        LinearLayout dock = new LinearLayout(this);
        mapDock = dock;
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(7), dp(6), dp(7), dp(5));
        GradientDrawable dockBg = new GradientDrawable();
        dockBg.setColor(Color.argb(242, 4, 36, 58));
        dockBg.setCornerRadius(dp(22));
        dockBg.setStroke(dp(1), Color.argb(75, 255, 255, 255));
        dock.setBackground(dockBg);
        dock.setElevation(dp(10));

        dock.addView(mapTool(R.drawable.ic_map_location, "Ubicación", v -> centerOnCurrentLocation()), mapToolParams());
        dock.addView(mapTool(R.drawable.ic_map_layers, "Capas", v -> showLayerDialog()), mapToolParams());
        dock.addView(mapTool(R.drawable.ic_map_points, "Puntos", v -> loadSavedPoints(true)), mapToolParams());
        dock.addView(mapTool(R.drawable.ic_map_measure, "Medir", v -> showMeasureModeDialog()), mapToolParams());
        dock.addView(mapTool(R.drawable.ic_map_download, "Descargar", v -> showDownloadDialog()), mapToolParams());

        FrameLayout.LayoutParams dockLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(70));
        dockLp.gravity = Gravity.BOTTOM;
        dockLp.setMargins(dp(10), 0, dp(10), dp(9));
        frame.addView(dock, dockLp);

        measurePanel = buildMeasurePanel();
        measurePanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams measureLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        measureLp.gravity = Gravity.BOTTOM;
        measureLp.setMargins(dp(12), 0, dp(12), dp(86));
        frame.addView(measurePanel, measureLp);

        downloadSelectionPanel = buildDownloadSelectionPanel();
        downloadSelectionPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams downloadLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        downloadLp.gravity = Gravity.BOTTOM;
        downloadLp.setMargins(dp(12), 0, dp(12), dp(10));
        frame.addView(downloadSelectionPanel, downloadLp);

        statusView = floatingLabel("Buscando tu ubicación actual…");
        statusView.setTextSize(11);
        statusView.setMaxLines(2);
        statusView.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.gravity = Gravity.BOTTOM;
        statusLp.setMargins(dp(24), 0, dp(24), dp(88));
        frame.addView(statusView, statusLp);
    }

    private LinearLayout buildDownloadSelectionPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(11), dp(14), dp(11));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(248, 5, 31, 50));
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), Color.argb(120, 255, 255, 255));
        panel.setBackground(bg);
        panel.setElevation(dp(14));

        TextView title = text("Selecciona tu mapa sin internet", 16, true);
        title.setTextColor(Color.WHITE);
        panel.addView(title);

        TextView hint = text("Paso 1: mueve el mapa. Paso 2: ajusta el marco desde las esquinas. Paso 3: pulsa “Usar esta zona”.", 11, false);
        hint.setTextColor(Color.rgb(194, 220, 239));
        hint.setPadding(0, dp(3), 0, dp(5));
        panel.addView(hint);

        downloadSelectionInfoView = text("Calculando área…", 13, true);
        downloadSelectionInfoView.setTextColor(Color.WHITE);
        panel.addView(downloadSelectionInfoView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(8), 0, 0);
        Button cancel = compactButton("Cancelar", false);
        cancel.setOnClickListener(v -> endDownloadSelection(true));
        actions.addView(cancel, weightParams());
        Button use = compactButton("Usar esta zona", false);
        use.setOnClickListener(v -> confirmSelectedDownloadArea());
        actions.addView(use, weightParams());
        panel.addView(actions);
        return panel;
    }

    private LinearLayout buildMeasurePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(245, 7, 29, 47));
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), Color.argb(105, 255, 255, 255));
        panel.setBackground(bg);
        panel.setElevation(dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        measureTitleView = text("Medir distancia", 15, true);
        measureTitleView.setTextColor(Color.WHITE);
        header.addView(measureTitleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("×", 25, true);
        close.setTextColor(Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("Cerrar panel de medición");
        close.setOnClickListener(v -> {
            js("finishMeasure()");
            measurementActive = false;
            panel.setVisibility(View.GONE);
            if (statusView != null) statusView.setVisibility(View.VISIBLE);
            setStatus(measurementPointCount > 0 ? "La medición queda dibujada. Pulsa Medir para continuar o empezar otra." : "Medición cerrada.");
        });
        header.addView(close, new LinearLayout.LayoutParams(dp(40), dp(36)));
        panel.addView(header);

        measureResultView = text("Toca el mapa para marcar el inicio.", 14, true);
        measureResultView.setTextColor(Color.WHITE);
        measureResultView.setPadding(0, dp(4), 0, dp(2));
        panel.addView(measureResultView);

        measureHintView = text("Cada toque crea un tramo recto. El resultado es aproximado sobre el mapa. Usa ↶ para corregir.", 11, false);
        measureHintView.setTextColor(Color.rgb(194, 220, 239));
        panel.addView(measureHintView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(8), 0, 0);

        Button undo = compactButton("↶ Deshacer", false);
        undo.setContentDescription("Deshacer último punto");
        undo.setOnClickListener(v -> js("undoMeasure()"));
        actions.addView(undo, weightParams());

        Button done = compactButton("✓ Finalizar", false);
        done.setContentDescription("Finalizar medición");
        done.setOnClickListener(v -> {
            js("finishMeasure()");
            measurementActive = false;
            measureHintView.setText("Medición finalizada. El resultado queda visible en el mapa.");
        });
        actions.addView(done, weightParams());

        Button clear = compactButton("Limpiar", false);
        clear.setContentDescription("Limpiar medición");
        clear.setOnClickListener(v -> js("clearMeasure()"));
        actions.addView(clear, weightParams());
        panel.addView(actions);
        return panel;
    }

    private void showMeasureModeDialog() {
        if (measurementPointCount > 0) {
            String[] items = {"Continuar medición actual", "Nueva distancia", "Nueva área y perímetro", "Limpiar medición"};
            new AlertDialog.Builder(this)
                    .setTitle("Medición sobre el mapa")
                    .setItems(items, (dialog, which) -> {
                        if (which == 0) {
                            measurementActive = true;
                            showMeasurePanel();
                            js("continueMeasure()");
                        } else if (which == 1) beginMeasurement("distance");
                        else if (which == 2) beginMeasurement("area");
                        else {
                            js("clearMeasure()");
                            measurementPointCount = 0;
                            showMeasurePanel();
                        }
                    })
                    .setNegativeButton("Cerrar", null)
                    .show();
            return;
        }
        String[] items = {"Distancia por tramos", "Área y perímetro"};
        new AlertDialog.Builder(this)
                .setTitle("¿Qué quieres medir?")
                .setItems(items, (dialog, which) -> beginMeasurement(which == 1 ? "area" : "distance"))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void beginMeasurement(String mode) {
        measurementMode = "area".equals(mode) ? "area" : "distance";
        measurementActive = true;
        measurementPointCount = 0;
        showMeasurePanel();
        js("startMeasure(" + JSONObject.quote(measurementMode) + ")");
    }

    private void showMeasurePanel() {
        if (measurePanel != null) measurePanel.setVisibility(View.VISIBLE);
        if (statusView != null) statusView.setVisibility(View.GONE);
        if (measureTitleView != null) measureTitleView.setText("area".equals(measurementMode) ? "Medir área y perímetro" : "Medir distancia");
        if (measureHintView != null) measureHintView.setText(measurementActive
                ? "Toca el mapa para agregar puntos. Usa ↶ si te equivocas."
                : "La medición está finalizada y permanece visible.");
    }

    private LinearLayout.LayoutParams mapToolParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private View mapTool(int iconRes, String label, View.OnClickListener listener) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setContentDescription(label);
        item.setOnClickListener(listener);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) item.setTooltipText(label);

        ImageButton icon = new ImageButton(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));
        icon.setColorFilter(Color.WHITE);
        icon.setContentDescription(label);
        icon.setOnClickListener(listener);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(accentColor);
        iconBg.setStroke(dp(1), Color.argb(105, 255, 255, 255));
        icon.setBackground(iconBg);
        item.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));

        TextView caption = new TextView(this);
        caption.setText(label);
        caption.setTextColor(Color.WHITE);
        caption.setTextSize(9);
        caption.setGravity(Gravity.CENTER);
        caption.setMaxLines(1);
        item.addView(caption, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));
        return item;
    }

    private ImageButton roundIconButton(int iconRes, String description) {
        ImageButton button = new ImageButton(this);
        button.setImageResource(iconRes);
        button.setColorFilter(Color.WHITE);
        button.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        button.setPadding(dp(10), dp(10), dp(10), dp(10));
        button.setContentDescription(description);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) button.setTooltipText(description);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(accentColor);
        bg.setStroke(dp(1), Color.argb(110, 255, 255, 255));
        button.setBackground(bg);
        button.setElevation(dp(6));
        return button;
    }

    private TextView floatingLabel(String value) {
        TextView view = text(value, 12, true);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(12), dp(7), dp(12), dp(7));
        view.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(228, 4, 36, 58));
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), Color.argb(90, 255, 255, 255));
        view.setBackground(bg);
        view.setElevation(dp(5));
        return view;
    }

    private void showLayerDialog() {
        String[] items = {"Calles y lugares", "Satélite", "Satélite + nombres", "Topográfico", "Relieve", "Mapa descargado", "Abrir esta zona en Google Earth"};
        new AlertDialog.Builder(this)
                .setTitle("Tipo de mapa")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) setMode("standard");
                    else if (which == 1) setMode("satellite");
                    else if (which == 2) setMode("hybrid");
                    else if (which == 3) setMode("topo");
                    else if (which == 4) setMode("relief");
                    else if (which == 5) showOfflineMaps();
                    else openInGoogleEarth();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showMapToolsDialog() {
        String[] items = {"Abrir GPS y puntos", "Medir distancia o área", "Deshacer último punto", "Limpiar medición", "Descargar mapa offline", "Mapas guardados", "Información del mapa"};
        new AlertDialog.Builder(this)
                .setTitle("Herramientas")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) startActivity(new Intent(this, GpsActivity.class));
                    else if (which == 1) showMeasureModeDialog();
                    else if (which == 2) js("undoMeasure()");
                    else if (which == 3) { js("clearMeasure()"); setStatus("Medición eliminada."); }
                    else if (which == 4) showDownloadDialog();
                    else if (which == 5) showOfflineMaps();
                    else showMapInfo();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(7), dp(8), dp(7));
        bar.setBackgroundColor(appBarColor);

        TextView back = text("‹", 38, true);
        back.setTextColor(Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Volver");
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Mapa topográfico", 20, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        modeSubtitleView = text("Calles y lugares · online", 11, false);
        modeSubtitleView.setTextColor(Color.rgb(193, 218, 240));
        titles.addView(modeSubtitleView);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageButton info = roundIconButton(R.drawable.ic_map_info, "Información del mapa");
        info.setOnClickListener(v -> showMapInfo());
        bar.addView(info, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return bar;
    }

    private View modeBar() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setBackgroundColor(cardColor);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(7), dp(8), dp(7));
        row.addView(modeButton("Estándar", "standard"));
        row.addView(modeButton("Satélite", "satellite"));
        row.addView(modeButton("Híbrido", "hybrid"));
        row.addView(modeButton("Topográfico", "topo"));
        row.addView(modeButton("Offline", "offline"));
        hsv.addView(row);
        return hsv;
    }

    private Button modeButton(String label, String mode) {
        Button b = compactButton(label, true);
        b.setOnClickListener(v -> {
            if ("offline".equals(mode)) showOfflineMaps();
            else setMode(mode);
        });
        return b;
    }

    private View actionPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(6), dp(8), dp(8));
        panel.setBackgroundColor(cardColor);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button locate = compactButton("⌖ Mi ubicación", true);
        locate.setOnClickListener(v -> centerOnCurrentLocation());
        row1.addView(locate, weightParams());
        Button minus = compactButton("−", true);
        minus.setOnClickListener(v -> js("zoomOut()"));
        row1.addView(minus, smallWeightParams());
        Button plus = compactButton("+", true);
        plus.setOnClickListener(v -> js("zoomIn()"));
        row1.addView(plus, smallWeightParams());
        Button points = compactButton("Puntos GPS", true);
        points.setOnClickListener(v -> loadSavedPoints(true));
        row1.addView(points, weightParams());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button measure = compactButton("📐 Medir", true);
        measure.setOnClickListener(v -> js("toggleMeasure()"));
        row2.addView(measure, weightParams());
        Button clearMeasure = compactButton("Limpiar medición", true);
        clearMeasure.setOnClickListener(v -> js("clearMeasure()"));
        row2.addView(clearMeasure, weightParams());
        panel.addView(row2);

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        Button download = compactButton("↓ Descargar zona", true);
        download.setOnClickListener(v -> showDownloadDialog());
        row3.addView(download, weightParams());
        Button manage = compactButton("▣ Mapas guardados", true);
        manage.setOnClickListener(v -> showOfflineMaps());
        row3.addView(manage, weightParams());
        panel.addView(row3);

        statusView = text("Mueve el mapa y elige el tipo de vista.", 11, false);
        statusView.setTextColor(subTextColor);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(4), dp(3), dp(4), 0);
        panel.addView(statusView);
        return panel;
    }

    private void setMode(String mode) {
        currentMode = mode;
        js("setMode(" + JSONObject.quote(mode) + ")");
        String label = "standard".equals(mode) ? "Calles y lugares"
                : "satellite".equals(mode) ? "Satélite"
                : "hybrid".equals(mode) ? "Satélite + nombres"
                : "topo".equals(mode) ? "Topográfico"
                : "relief".equals(mode) ? "Relieve" : "Offline";
        if (modeBadge != null) modeBadge.setText(label);
        if (modeSubtitleView != null) {
            modeSubtitleView.setText("Mapa " + label.toLowerCase(Locale.getDefault()) + ("offline".equals(mode) ? "" : " · online"));
        }
        if ("satellite".equals(mode)) {
            setStatus("Satélite sin etiquetas. Usa Satélite + nombres para ver calles y lugares.");
        } else if ("hybrid".equals(mode)) {
            setStatus("Satélite con calles, límites y nombres superpuestos.");
        } else if ("topo".equals(mode)) {
            setStatus("Mapa topográfico online.");
        } else if ("relief".equals(mode)) {
            setStatus("Relieve sombreado para interpretar montañas y pendientes. No es una vista 3D real.");
        } else if ("standard".equals(mode)) {
            setStatus("Pulsa Ubicación para ir a tu zona. Para guardar sin internet, pulsa Descargar.");
        }
    }

    private void openInGoogleEarth() {
        double lat;
        double lon;
        if (currentLocation != null) {
            lat = currentLocation.getLatitude();
            lon = currentLocation.getLongitude();
        } else if (!Double.isNaN(south) && !Double.isNaN(north) && !Double.isNaN(west) && !Double.isNaN(east)) {
            lat = (south + north) / 2.0;
            lon = (west + east) / 2.0;
        } else {
            lat = -9.19;
            lon = -75.015;
        }
        try {
            Uri uri = Uri.parse(String.format(Locale.US,
                    "https://earth.google.com/web/@%.7f,%.7f,1200a,35y,0h,0t,0r", lat, lon));
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir Google Earth.", Toast.LENGTH_LONG).show();
        }
    }

    private void showMapInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Mapa de GeoTopo")
                .setMessage("Barra inferior:\n"
                        + "• Ubicación: centra tu posición actual.\n"
                        + "• Capas: cambia entre calles, satélite, híbrido, topográfico, relieve u offline.\n"
                        + "• Puntos: muestra los puntos GPS guardados.\n"
                        + "• Medir: calcula distancia o área tocando el mapa.\n"
                        + "• Descargar: guarda cartografía para usar sin internet.\n\n"
                        + "Para descargar: elige un radio alrededor de tu ubicación, busca un lugar o marca un rectángulo. "
                        + "Después ajusta las esquinas, revisa el área y el tamaño estimado.\n\n"
                        + "El satélite necesita internet. Los mapas offline son vectoriales y no incluyen imagen satelital.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void centerOnCurrentLocation() {
        followLocation = true;
        if (currentLocation != null && locationAgeMs(currentLocation) <= 30000L) {
            sendLocationToMap(currentLocation, true);
            autoCenteredOnce = true;
            setLocationStatus(currentLocation);
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        startLocationUpdates();
    }

    private void startLocationUpdates() {
        if (locationManager == null) {
            setStatus("Ubicación no disponible.");
            return;
        }
        try {
            Location last = chooseBetterLocation(
                    safeLastKnownLocation(LocationManager.GPS_PROVIDER),
                    safeLastKnownLocation(LocationManager.NETWORK_PROVIDER));
            if (last != null && locationAgeMs(last) <= 120000L) {
                currentLocation = new Location(last);
                boolean shouldCenter = followLocation || !autoCenteredOnce;
                sendLocationToMap(currentLocation, shouldCenter);
                if (shouldCenter) autoCenteredOnce = true;
                setLocationStatus(currentLocation);
            }
            boolean any = false;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1200L, 0.5f, this);
                any = true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1600L, 1f, this);
                any = true;
            }
            if (!any) setStatus("Activa la ubicación del teléfono.");
            else if (currentLocation == null) {
                setStatus("Buscando tu ubicación actual…");
                mainHandler.removeCallbacks(locationTimeout);
                mainHandler.postDelayed(locationTimeout, 15000L);
            }
        } catch (SecurityException e) {
            setStatus("Permiso de ubicación requerido.");
        }
    }

    private void stopLocationUpdates() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null) return;
        if (currentLocation == null || betterLocation(location, currentLocation)) currentLocation = new Location(location);
        saveSharedLocation(currentLocation);
        mainHandler.removeCallbacks(locationTimeout);
        boolean shouldCenter = followLocation || !autoCenteredOnce;
        sendLocationToMap(currentLocation, shouldCenter);
        if (shouldCenter) autoCenteredOnce = true;
        followLocation = false;
        setLocationStatus(currentLocation);
    }

    private void saveSharedLocation(Location location) {
        if (location == null) return;
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.hasAccuracy() ? location.getAccuracy() : 0f)
                .putFloat("last_bearing", location.hasBearing() ? location.getBearing() : -1f)
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .apply();
    }

    private Location readSharedLocation() {
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        String latText = sp.getString("last_latitude", "");
        String lonText = sp.getString("last_longitude", "");
        if (latText == null || lonText == null || latText.isEmpty() || lonText.isEmpty()) return null;
        try {
            Location saved = new Location("GeoTopo");
            saved.setLatitude(Double.parseDouble(latText));
            saved.setLongitude(Double.parseDouble(lonText));
            float accuracy = sp.getFloat("last_accuracy", 0f);
            if (accuracy > 0f) saved.setAccuracy(accuracy);
            float bearing = sp.getFloat("last_bearing", -1f);
            if (bearing >= 0f) saved.setBearing(bearing);
            saved.setTime(sp.getLong("last_location_time", System.currentTimeMillis()));
            return saved;
        } catch (Exception ignored) {
            return null;
        }
    }

    private void setLocationStatus(Location location) {
        if (location == null) {
            setStatus("Ubicación no disponible.");
            return;
        }
        String accuracy = location.hasAccuracy() ? String.format(Locale.US, "± %.1f m", location.getAccuracy()) : "sin precisión";
        String source = LocationManager.GPS_PROVIDER.equals(location.getProvider()) ? "GPS/GNSS" : "ubicación asistida";
        long seconds = Math.max(0L, locationAgeMs(location) / 1000L);
        String age = seconds < 2L ? "ahora" : "hace " + seconds + " s";
        setStatus("Tu ubicación · " + accuracy + " · " + source + " · " + age);
    }

    private long locationAgeMs(Location location) {
        if (location == null) return Long.MAX_VALUE;
        long time = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        return Math.max(0L, System.currentTimeMillis() - time);
    }

    private Location safeLastKnownLocation(String provider) {
        if (locationManager == null) return null;
        try {
            return locationManager.getLastKnownLocation(provider);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Location chooseBetterLocation(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        if (a.getTime() > b.getTime() + 30000L) return a;
        if (b.getTime() > a.getTime() + 30000L) return b;
        if (a.hasAccuracy() && b.hasAccuracy()) return a.getAccuracy() <= b.getAccuracy() ? a : b;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private boolean betterLocation(Location candidate, Location current) {
        long dt = candidate.getTime() - current.getTime();
        if (dt > 30000L) return true;
        if (dt < -30000L) return false;
        if (!current.hasAccuracy()) return true;
        if (!candidate.hasAccuracy()) return dt > 0;
        return candidate.getAccuracy() <= current.getAccuracy() || (dt > 0 && candidate.getAccuracy() < current.getAccuracy() + 30f);
    }

    private void sendLocationToMap(Location location, boolean follow) {
        if (location == null) return;
        float accuracy = location.hasAccuracy() ? location.getAccuracy() : 0f;
        float bearing = location.hasBearing() && (!location.hasSpeed() || location.getSpeed() >= 0.7f) ? location.getBearing() : -1f;
        js(String.format(Locale.US, "showCurrentLocation(%.9f,%.9f,%.2f,%.2f,%s)",
                location.getLatitude(), location.getLongitude(), accuracy, bearing, follow ? "true" : "false"));
    }

    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        boolean granted = false;
        for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
        if (granted) { followLocation = true; startLocationUpdates(); }
        else setStatus("Permiso de ubicación denegado.");
    }

    private void loadSavedPoints(boolean fit) {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        js("setPoints(" + JSONObject.quote(json) + "," + (fit ? "true" : "false") + ")");
        try {
            int count = new JSONArray(json).length();
            setStatus(count == 0 ? "No hay puntos GPS guardados." : "Mostrando " + count + " puntos GPS.");
        } catch (JSONException ignored) {
            setStatus("No se pudieron leer los puntos guardados.");
        }
    }

    private void showDownloadDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(10), dp(18), dp(8));
        content.setBackgroundColor(Color.WHITE);

        TextView intro = text("Elige cuánto mapa quieres guardar. La opción por kilómetros usa tu ubicación actual como centro.", 13, false);
        intro.setTextColor(Color.rgb(55, 62, 72));
        intro.setPadding(0, 0, 0, dp(10));
        content.addView(intro);

        TextView radiusTitle = text("ALREDEDOR DE MI UBICACIÓN", 11, true);
        radiusTitle.setTextColor(Color.rgb(80, 88, 100));
        radiusTitle.setPadding(0, dp(2), 0, dp(6));
        content.addView(radiusTitle);

        LinearLayout firstRow = new LinearLayout(this);
        firstRow.setOrientation(LinearLayout.HORIZONTAL);
        Button oneKm = downloadRadiusButton("1 km", "zona pequeña");
        Button threeKm = downloadRadiusButton("3 km", "barrio o sector");
        LinearLayout.LayoutParams radiusLeft = new LinearLayout.LayoutParams(0, dp(64), 1f);
        radiusLeft.setMargins(dp(3), dp(3), dp(3), dp(3));
        LinearLayout.LayoutParams radiusRight = new LinearLayout.LayoutParams(0, dp(64), 1f);
        radiusRight.setMargins(dp(3), dp(3), dp(3), dp(3));
        firstRow.addView(oneKm, radiusLeft);
        firstRow.addView(threeKm, radiusRight);
        content.addView(firstRow);

        LinearLayout secondRow = new LinearLayout(this);
        secondRow.setOrientation(LinearLayout.HORIZONTAL);
        Button fiveKm = downloadRadiusButton("5 km", "zona urbana");
        Button tenKm = downloadRadiusButton("10 km", "zona amplia");
        LinearLayout.LayoutParams radiusLeft2 = new LinearLayout.LayoutParams(0, dp(64), 1f);
        radiusLeft2.setMargins(dp(3), dp(3), dp(3), dp(3));
        LinearLayout.LayoutParams radiusRight2 = new LinearLayout.LayoutParams(0, dp(64), 1f);
        radiusRight2.setMargins(dp(3), dp(3), dp(3), dp(3));
        secondRow.addView(fiveKm, radiusLeft2);
        secondRow.addView(tenKm, radiusRight2);
        content.addView(secondRow);

        TextView customTitle = text("OTRAS FORMAS", 11, true);
        customTitle.setTextColor(Color.rgb(80, 88, 100));
        customTitle.setPadding(0, dp(12), 0, dp(5));
        content.addView(customTitle);

        Button selectArea = downloadChoiceButton("Seleccionar un área en el mapa", "Ajusta un rectángulo con cuatro esquinas");
        Button searchPlace = downloadChoiceButton("Buscar ciudad o lugar", "Busca el lugar y luego ajusta la zona");
        Button visibleArea = downloadChoiceButton("Usar lo que veo en pantalla", "Guarda el sector visible actualmente");
        Button savedMaps = downloadChoiceButton("Mapas descargados", "Abrir, actualizar o eliminar mapas guardados");
        content.addView(selectArea);
        content.addView(searchPlace);
        content.addView(visibleArea);
        content.addView(savedMaps);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Descargar mapa sin internet")
                .setView(scroll)
                .setNegativeButton("Cancelar", null)
                .create();

        oneKm.setOnClickListener(v -> { dialog.dismiss(); startRadiusDownload(1.0); });
        threeKm.setOnClickListener(v -> { dialog.dismiss(); startRadiusDownload(3.0); });
        fiveKm.setOnClickListener(v -> { dialog.dismiss(); startRadiusDownload(5.0); });
        tenKm.setOnClickListener(v -> { dialog.dismiss(); startRadiusDownload(10.0); });
        selectArea.setOnClickListener(v -> { dialog.dismiss(); beginDownloadSelection(null, defaultOfflineName(), false); });
        searchPlace.setOnClickListener(v -> { dialog.dismiss(); showPlaceSearchDialog(); });
        visibleArea.setOnClickListener(v -> {
            if (!validBounds(south, west, north, east)) {
                Toast.makeText(this, "Espera a que el mapa termine de cargar.", Toast.LENGTH_LONG).show();
                return;
            }
            dialog.dismiss();
            beginDownloadSelection(new double[]{south, west, north, east}, defaultOfflineName(), false);
        });
        savedMaps.setOnClickListener(v -> { dialog.dismiss(); showOfflineMaps(); });
        dialog.show();
    }

    private Button downloadRadiusButton(String title, String subtitle) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(title + "\n" + subtitle);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accentColor);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.argb(85, 255, 255, 255));
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(64), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        button.setLayoutParams(lp);
        return button;
    }

    private Button downloadChoiceButton(String title, String subtitle) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(title + "\n" + subtitle);
        button.setTextColor(Color.rgb(26, 38, 50));
        button.setTextSize(13);
        button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        button.setPadding(dp(14), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(244, 247, 250));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Color.rgb(205, 214, 224));
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62));
        lp.setMargins(0, dp(3), 0, dp(3));
        button.setLayoutParams(lp);
        return button;
    }

    private void showRadiusDownloadDialog() {
        if (currentLocation == null || locationAgeMs(currentLocation) > 120000L) {
            new AlertDialog.Builder(this)
                    .setTitle("Ubicación actual necesaria")
                    .setMessage("Primero obtén una ubicación reciente para crear una zona alrededor de ti.")
                    .setPositiveButton("Obtener ubicación", (d, w) -> centerOnCurrentLocation())
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        String[] items = {
                "Radio 1 km · zona aproximada de 2 × 2 km",
                "Radio 3 km · zona aproximada de 6 × 6 km",
                "Radio 5 km · zona aproximada de 10 × 10 km",
                "Radio 10 km · zona aproximada de 20 × 20 km"
        };
        final double[] radii = {1.0, 3.0, 5.0, 10.0};
        new AlertDialog.Builder(this)
                .setTitle("Zona alrededor de mi ubicación")
                .setItems(items, (d, which) -> startRadiusDownload(radii[which]))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void startRadiusDownload(double radius) {
        if (currentLocation == null || locationAgeMs(currentLocation) > 120000L) {
            new AlertDialog.Builder(this)
                    .setTitle("Ubicación actual necesaria")
                    .setMessage("Primero obtén una ubicación reciente para usar una zona por kilómetros alrededor de ti.")
                    .setPositiveButton("Obtener ubicación", (d, w) -> centerOnCurrentLocation())
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        double[] b = boundsAround(currentLocation.getLatitude(), currentLocation.getLongitude(), radius);
        beginDownloadSelection(b, "Mi_zona_" + ((int) radius) + "km", true);
        setStatus("Zona de " + (int) radius + " km preparada. Si quieres, ajusta el marco y luego pulsa Usar esta zona.");
    }

    private void showPlaceSearchDialog() {
        EditText input = new EditText(this);
        input.setHint("Ejemplo: Juliaca, Puno");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setTextColor(Color.rgb(32, 36, 43));
        input.setHintTextColor(Color.rgb(120, 126, 136));
        int pad = dp(18);
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(pad, dp(4), pad, 0);
        wrap.addView(input, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Buscar lugar")
                .setMessage("La búsqueda solo centra el mapa. Después ajustarás el marco exacto que deseas guardar.")
                .setView(wrap)
                .setPositiveButton("Buscar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String query = input.getText().toString().trim();
            if (query.length() < 3) {
                input.setError("Escribe al menos 3 caracteres");
                return;
            }
            dialog.dismiss();
            searchPlaceForDownloadSelection(query);
        }));
        dialog.show();
    }

    private void searchPlaceForDownloadSelection(String query) {
        setStatus("Buscando “" + query + "”…");
        cancelDownload = false;
        downloadExecutor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                String q = URLEncoder.encode(query + ", Perú", "UTF-8");
                URL url = new URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=pe&q=" + q);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(18000);
                connection.setRequestProperty("User-Agent", "GeoTopo/1.8 Android (com.bph.geotopo)");
                connection.setRequestProperty("Accept-Language", "es");
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                String json = readStream(connection.getInputStream(), 2 * 1024 * 1024);
                JSONArray results = new JSONArray(json);
                if (results.length() == 0) throw new Exception("EMPTY");
                JSONObject first = results.getJSONObject(0);
                JSONArray bb = first.getJSONArray("boundingbox");
                double s = Double.parseDouble(bb.getString(0));
                double n = Double.parseDouble(bb.getString(1));
                double w = Double.parseDouble(bb.getString(2));
                double e = Double.parseDouble(bb.getString(3));
                String display = first.optString("display_name", query);
                String shortName = display.split(",")[0].trim();
                mainHandler.post(() -> {
                    js(String.format(Locale.US, "fitBounds(%.9f,%.9f,%.9f,%.9f)", s, w, n, e));
                    setStatus("Lugar encontrado. Ajusta el marco al sector que necesitas.");
                    mainHandler.postDelayed(() -> beginDownloadSelection(null,
                            shortName.isEmpty() ? defaultOfflineName() : shortName, false), 450L);
                });
            } catch (Exception ex) {
                mainHandler.post(() -> new AlertDialog.Builder(this)
                        .setTitle("Lugar no encontrado")
                        .setMessage("No se pudo localizar “" + query + "”. Prueba con ciudad y departamento, o selecciona el área directamente en el mapa.")
                        .setPositiveButton("Cerrar", null)
                        .show());
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void beginDownloadSelection(double[] bounds, String suggestedName, boolean fit) {
        downloadSelectionActive = true;
        downloadSuggestedName = suggestedName == null || suggestedName.trim().isEmpty() ? defaultOfflineName() : suggestedName.trim();
        if (measurePanel != null) measurePanel.setVisibility(View.GONE);
        measurementActive = false;
        js("finishMeasure()");
        if (mapDock != null) mapDock.setVisibility(View.GONE);
        if (statusView != null) statusView.setVisibility(View.GONE);
        if (downloadSelectionPanel != null) downloadSelectionPanel.setVisibility(View.VISIBLE);
        if (downloadSelectionInfoView != null) downloadSelectionInfoView.setText("Calculando área…");
        if (bounds != null && bounds.length >= 4 && validBounds(bounds[0], bounds[1], bounds[2], bounds[3])) {
            downloadSouth = bounds[0]; downloadWest = bounds[1]; downloadNorth = bounds[2]; downloadEast = bounds[3];
            js(String.format(Locale.US, "setDownloadSelection(%.9f,%.9f,%.9f,%.9f,%s)",
                    downloadSouth, downloadWest, downloadNorth, downloadEast, fit ? "true" : "false"));
        } else {
            downloadSouth = downloadWest = downloadNorth = downloadEast = Double.NaN;
            js("startDownloadSelection()");
        }
    }

    private void endDownloadSelection(boolean clear) {
        downloadSelectionActive = false;
        if (downloadSelectionPanel != null) downloadSelectionPanel.setVisibility(View.GONE);
        if (mapDock != null) mapDock.setVisibility(View.VISIBLE);
        if (statusView != null) statusView.setVisibility(View.VISIBLE);
        js("stopDownloadSelection()");
        if (clear) {
            downloadSouth = downloadWest = downloadNorth = downloadEast = Double.NaN;
            setStatus("Selección cancelada.");
        }
    }

    private void confirmSelectedDownloadArea() {
        if (!validBounds(downloadSouth, downloadWest, downloadNorth, downloadEast)) {
            Toast.makeText(this, "Ajusta el marco y espera a que se calcule el área.", Toast.LENGTH_LONG).show();
            return;
        }
        double[] b = {downloadSouth, downloadWest, downloadNorth, downloadEast};
        String suggested = downloadSuggestedName;
        endDownloadSelection(false);
        showPrepareDownloadDialog(b, suggested);
    }

    private void showPrepareDownloadDialog(double[] selected, String suggestedName) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(8), dp(14), dp(4));
        panel.setBackgroundColor(Color.WHITE);

        TextView note = text("Se guardará un mapa para usar sin internet. Incluye calles, caminos, ríos y otros elementos según el nivel de detalle. No incluye fotografía satelital.", 12, false);
        note.setTextColor(Color.rgb(75, 81, 91));
        panel.addView(note);

        TextView areaInfo = text(formatAreaInfo(selected), 13, true);
        areaInfo.setTextColor(accentColor);
        areaInfo.setPadding(0, dp(6), 0, dp(2));
        panel.addView(areaInfo);

        TextView estimateInfo = text("", 12, false);
        estimateInfo.setTextColor(Color.rgb(75, 81, 91));
        estimateInfo.setPadding(0, 0, 0, dp(5));
        panel.addView(estimateInfo);

        EditText name = new EditText(this);
        name.setText(suggestedName == null || suggestedName.trim().isEmpty() ? defaultOfflineName() : suggestedName.trim());
        name.setHint("Nombre del mapa");
        name.setTextColor(Color.rgb(32, 36, 43));
        name.setHintTextColor(Color.rgb(120, 126, 136));
        name.setSelectAllOnFocus(true);
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT);
        panel.addView(name);

        RadioGroup detail = new RadioGroup(this);
        RadioButton basic = radio("Básico · vías principales, poblaciones y agua");
        RadioButton medium = radio("Medio · calles, caminos, agua, ferrocarril y terreno");
        RadioButton high = radio("Alto · agrega edificios (solo sectores pequeños)");
        detail.addView(basic); detail.addView(medium); detail.addView(high);
        medium.setChecked(true);
        panel.addView(detail);

        CheckBox wifiOnly = new CheckBox(this);
        wifiOnly.setText("Descargar solo con Wi‑Fi");
        wifiOnly.setTextColor(Color.rgb(32, 36, 43));
        wifiOnly.setTextSize(13);
        wifiOnly.setChecked(true);
        panel.addView(wifiOnly);

        Runnable updateEstimate = () -> {
            String level = high.isChecked() ? "alto" : basic.isChecked() ? "básico" : "medio";
            long estimated = estimateOfflineBytes(bboxAreaKm2(selected[0], selected[1], selected[2], selected[3]), level);
            long free = availableStorageBytes();
            String warning;
            if (free > 0 && estimated > free) {
                warning = "\nAdvertencia: la estimación supera el espacio disponible. La descarga puede quedar incompleta.";
            } else if (estimated >= 100L * 1024L * 1024L) {
                warning = "\nDescarga grande: se dividirá automáticamente en varios sectores y puede tardar bastante.";
            } else {
                warning = "\nLa cifra puede variar según la cantidad de calles y edificios.";
            }
            estimateInfo.setText("Tamaño orientativo: " + formatBytes(estimated)
                    + " · espacio disponible: " + formatBytes(free) + warning);
        };
        detail.setOnCheckedChangeListener((group, checkedId) -> updateEstimate.run());
        updateEstimate.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Confirmar descarga")
                .setView(panel)
                .setPositiveButton("Descargar", null)
                .setNegativeButton("Volver al mapa", null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
                dialog.dismiss();
                beginDownloadSelection(selected, name.getText().toString().trim(), false);
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String displayName = name.getText().toString().trim();
                if (displayName.isEmpty()) {
                    name.setError("Escribe un nombre");
                    return;
                }
                String level = high.isChecked() ? "alto" : basic.isChecked() ? "básico" : "medio";
                double areaKm2 = bboxAreaKm2(selected[0], selected[1], selected[2], selected[3]);
                if (areaKm2 <= 0) {
                    new AlertDialog.Builder(this)
                            .setTitle("Área no válida")
                            .setMessage("Vuelve al mapa y selecciona una zona válida.")
                            .setPositiveButton("Entendido", null)
                            .show();
                    return;
                }
                long estimatedBytes = estimateOfflineBytes(areaKm2, level);
                if (wifiOnly.isChecked() && !isWifiConnected()) {
                    new AlertDialog.Builder(this)
                            .setTitle("Wi‑Fi no disponible")
                            .setMessage("La opción “solo con Wi‑Fi” está activada. Conéctate a una red Wi‑Fi o desactiva esa opción para usar datos móviles.")
                            .setPositiveButton("Entendido", null)
                            .show();
                    return;
                }
                dialog.dismiss();
                confirmLargeDownload(displayName, level, selected, estimatedBytes);
            });
        });
        dialog.show();
    }

    private void confirmLargeDownload(String displayName, String level, double[] selected, long estimatedBytes) {
        long free = availableStorageBytes();
        boolean large = estimatedBytes >= 100L * 1024L * 1024L;
        boolean mayNotFit = free > 0 && estimatedBytes > free;
        if (!large && !mayNotFit) {
            downloadVectorArea(displayName, level, selected);
            return;
        }
        StringBuilder message = new StringBuilder();
        message.append("Tamaño orientativo: ").append(formatBytes(estimatedBytes)).append(".\n\n");
        message.append("GeoTopo no bloqueará la descarga por peso. La zona se dividirá automáticamente en sectores para reducir fallos y consumo de memoria.");
        if (mayNotFit) {
            message.append("\n\nAdvertencia: el espacio disponible parece insuficiente. La descarga podría detenerse cuando el almacenamiento se llene.");
        } else {
            message.append("\n\nMantén una conexión estable. Una zona grande puede tardar varios minutos.");
        }
        new AlertDialog.Builder(this)
                .setTitle("Descarga grande")
                .setMessage(message.toString())
                .setPositiveButton("Descargar de todos modos", (d, w) -> downloadVectorArea(displayName, level, selected))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private String formatAreaInfo(double[] b) {
        double km2 = bboxAreaKm2(b[0], b[1], b[2], b[3]);
        double heightKm = northSouthKm(b[0], b[2]);
        double widthKm = eastWestKm(b[1], b[3], (b[0] + b[2]) / 2.0);
        return "Zona: ≈ " + String.format(Locale.US, "%.2f", km2) + " km²"
                + " · " + String.format(Locale.US, "%.1f", widthKm) + " × "
                + String.format(Locale.US, "%.1f", heightKm) + " km";
    }

    private String formatSelectionInfo(double s, double w, double n, double e) {
        return formatAreaInfo(new double[]{s, w, n, e}) + "\nArrastra una esquina para ajustar el sector.";
    }

    private double[] boundsAround(double lat, double lon, double radiusKm) {
        double latDelta = radiusKm / 111.32;
        double cos = Math.max(0.08, Math.cos(Math.toRadians(lat)));
        double lonDelta = radiusKm / (111.32 * cos);
        return new double[]{
                Math.max(-85.0, lat - latDelta),
                Math.max(-179.999, lon - lonDelta),
                Math.min(85.0, lat + latDelta),
                Math.min(179.999, lon + lonDelta)
        };
    }

    private boolean validBounds(double s, double w, double n, double e) {
        return !Double.isNaN(s) && !Double.isNaN(w) && !Double.isNaN(n) && !Double.isNaN(e)
                && n > s && e > w && s >= -85.1 && n <= 85.1;
    }

    private String defaultOfflineName() {
        return "Zona_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
    }

    private double northSouthKm(double s, double n) {
        return Math.abs(n - s) * 111.32;
    }

    private double eastWestKm(double w, double e, double midLat) {
        double delta = Math.abs(e - w);
        if (delta > 180.0) delta = 360.0 - delta;
        return delta * 111.32 * Math.max(0.05, Math.cos(Math.toRadians(midLat)));
    }

    private long estimateOfflineBytes(double areaKm2, String detail) {
        double mbPerKm2 = "alto".equals(detail) ? 0.95 : "básico".equals(detail) ? 0.035 : 0.18;
        double baseMb = "alto".equals(detail) ? 2.5 : 1.2;
        double estimatedMb = Math.max(1.0, baseMb + areaKm2 * mbPerKm2);
        return (long) (estimatedMb * 1024.0 * 1024.0);
    }

    private long availableStorageBytes() {
        try {
            return new StatFs(offlineBaseDir().getAbsolutePath()).getAvailableBytes();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "no disponible";
        double mb = bytes / (1024.0 * 1024.0);
        if (mb >= 1024.0) return String.format(Locale.US, "%.1f GB", mb / 1024.0);
        return String.format(Locale.US, mb >= 100 ? "%.0f MB" : "%.1f MB", mb);
    }

    private boolean isWifiConnected() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network network = cm.getActiveNetwork();
            NetworkCapabilities caps = network == null ? null : cm.getNetworkCapabilities(network);
            return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void downloadVectorArea(String displayName, String detail, double[] b) {
        final double s = b[0], w = b[1], n = b[2], e = b[3];
        final String folder = uniqueFolderName(displayName);
        final MapPackage pkg = new MapPackage();
        pkg.name = displayName;
        pkg.folder = folder;
        pkg.south = s; pkg.west = w; pkg.north = n; pkg.east = e;
        pkg.centerLat = (s + n) / 2.0;
        pkg.centerLon = centerLongitude(w, e);
        pkg.minZoom = Math.max(5, currentZoom);
        pkg.maxZoom = 19;
        pkg.openZoom = Math.max(8, currentZoom);
        pkg.createdAt = System.currentTimeMillis();
        pkg.detail = detail;

        ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("Descargando mapa offline");
        progress.setMessage("Preparando sectores…");
        progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progress.setIndeterminate(false);
        progress.setCancelable(true);
        cancelDownload = false;
        progress.setOnCancelListener(d -> cancelDownload = true);
        progress.show();

        downloadExecutor.execute(() -> {
            File packageDir = new File(offlineBaseDir(), folder);
            if (!packageDir.exists()) packageDir.mkdirs();
            String error = null;
            int elementCount = 0;
            int chunkCount = 0;
            long totalBytes = 0L;
            try {
                List<double[]> sectors = buildInitialSectors(b, detail);
                final int[] total = {sectors.size()};
                final int[] completed = {0};
                final int[] fileCounter = {1};
                final int[] elements = {0};
                final long[] bytes = {0L};
                final JSONArray chunks = new JSONArray();
                mainHandler.post(() -> {
                    progress.setMax(Math.max(1, total[0]));
                    progress.setProgress(0);
                    progress.setMessage("Descargando sector 1 de " + total[0] + "…");
                });
                for (double[] sector : sectors) {
                    if (cancelDownload) throw new InterruptedException("cancelled");
                    downloadSectorAdaptive(detail, sector, packageDir, chunks, fileCounter,
                            completed, total, elements, bytes, 0, progress);
                }
                if (chunks.length() == 0) throw new Exception("La zona no devolvió elementos cartográficos.");
                writeOfflineIndex(packageDir, displayName, detail, b, chunks, elements[0], bytes[0]);
                elementCount = elements[0];
                chunkCount = chunks.length();
                totalBytes = bytes[0];
            } catch (InterruptedException ex) {
                error = "CANCELLED";
            } catch (Exception ex) {
                error = ex.getMessage() == null ? "No se pudo descargar la cartografía." : ex.getMessage();
            }
            final String finalError = error;
            final int finalCount = elementCount;
            final int finalChunks = chunkCount;
            final long finalBytes = totalBytes;
            mainHandler.post(() -> {
                if (progress.isShowing()) progress.dismiss();
                if (cancelDownload || "CANCELLED".equals(finalError)) {
                    deleteRecursive(packageDir);
                    setStatus("Descarga cancelada.");
                    return;
                }
                File index = new File(packageDir, "index.json");
                if (finalError != null || !index.exists()) {
                    deleteRecursive(packageDir);
                    new AlertDialog.Builder(this)
                            .setTitle("No se pudo completar la descarga")
                            .setMessage((finalError == null ? "Error desconocido." : finalError)
                                    + "\n\nNo existe un límite artificial de peso en GeoTopo. Si falló, la causa fue la conexión, el servidor cartográfico o el espacio real del teléfono. Puedes reintentar o elegir menos detalle.")
                            .setPositiveButton("Cerrar", null)
                            .show();
                    return;
                }
                pkg.dataCount = finalCount;
                pkg.tileCount = finalChunks;
                pkg.downloadedTiles = finalChunks;
                saveMapPackage(pkg);
                openOfflinePackage(pkg);
                Toast.makeText(this, "Mapa guardado: " + pkg.name + " · " + finalChunks
                        + " sectores · " + formatBytes(finalBytes), Toast.LENGTH_LONG).show();
            });
        });
    }

    private List<double[]> buildInitialSectors(double[] b, String detail) {
        double target = "alto".equals(detail) ? TARGET_HIGH_CHUNK_KM2
                : "básico".equals(detail) ? TARGET_BASIC_CHUNK_KM2 : TARGET_MEDIUM_CHUNK_KM2;
        double width = Math.max(0.01, eastWestKm(b[1], b[3], (b[0] + b[2]) / 2.0));
        double height = Math.max(0.01, northSouthKm(b[0], b[2]));
        int desired = Math.max(1, (int) Math.ceil((width * height) / target));
        double ratio = Math.max(0.05, width / height);
        int cols = Math.max(1, (int) Math.ceil(Math.sqrt(desired * ratio)));
        int rows = Math.max(1, (int) Math.ceil((double) desired / cols));
        List<double[]> result = new ArrayList<>();
        for (int row = 0; row < rows; row++) {
            double cs = b[0] + (b[2] - b[0]) * row / rows;
            double cn = b[0] + (b[2] - b[0]) * (row + 1) / rows;
            for (int col = 0; col < cols; col++) {
                double cw = b[1] + (b[3] - b[1]) * col / cols;
                double ce = b[1] + (b[3] - b[1]) * (col + 1) / cols;
                result.add(new double[]{cs, cw, cn, ce});
            }
        }
        return result;
    }

    private void downloadSectorAdaptive(String detail, double[] b, File packageDir, JSONArray chunks,
                                        int[] fileCounter, int[] completed, int[] total,
                                        int[] totalElements, long[] totalBytes, int depth,
                                        ProgressDialog progress) throws Exception {
        if (cancelDownload) throw new InterruptedException("cancelled");
        String tempName = String.format(Locale.US, "part_%04d.tmp", fileCounter[0]);
        File tempFile = new File(packageDir, tempName);
        try {
            String query = buildOverpassQuery(detail, b[0], b[1], b[2], b[3]);
            postOverpassToFile(query, tempFile);
            if (cancelDownload) throw new InterruptedException("cancelled");
            int count = countJsonElements(tempFile);
            if (count <= 0) {
                tempFile.delete();
                completed[0]++;
                updateSectorProgress(progress, completed[0], total[0], "Sector sin elementos; continuando…");
                return;
            }
            String fileName = String.format(Locale.US, "chunk_%04d.json", fileCounter[0]++);
            File finalFile = new File(packageDir, fileName);
            if (!tempFile.renameTo(finalFile)) {
                copyFile(tempFile, finalFile);
                tempFile.delete();
            }
            JSONObject item = new JSONObject();
            item.put("file", fileName);
            item.put("south", b[0]); item.put("west", b[1]);
            item.put("north", b[2]); item.put("east", b[3]);
            item.put("elements", count);
            item.put("bytes", finalFile.length());
            chunks.put(item);
            totalElements[0] += count;
            totalBytes[0] += finalFile.length();
            completed[0]++;
            updateSectorProgress(progress, completed[0], total[0], "Sector " + completed[0] + " de " + total[0] + " guardado");
            try { Thread.sleep(220L); } catch (InterruptedException ex) { throw ex; }
        } catch (InterruptedException ex) {
            tempFile.delete();
            throw ex;
        } catch (Exception ex) {
            tempFile.delete();
            double area = bboxAreaKm2(b[0], b[1], b[2], b[3]);
            if (depth < MAX_ADAPTIVE_SPLIT_DEPTH && canSplitSector(area, detail) && shouldSplitDownloadError(ex)) {
                List<double[]> children = splitIntoFour(b);
                total[0] += 3;
                updateSectorProgress(progress, completed[0], total[0], "El servidor pidió dividir una zona; reintentando por partes…");
                for (double[] child : children) {
                    downloadSectorAdaptive(detail, child, packageDir, chunks, fileCounter,
                            completed, total, totalElements, totalBytes, depth + 1, progress);
                }
                return;
            }
            throw ex;
        }
    }

    private boolean canSplitSector(double areaKm2, String detail) {
        double min = "alto".equals(detail) ? 0.35 : "básico".equals(detail) ? 20.0 : 2.0;
        return areaKm2 > min;
    }

    private boolean shouldSplitDownloadError(Exception ex) {
        String m = ex.getMessage() == null ? "" : ex.getMessage().toLowerCase(Locale.US);
        return m.contains("http 400") || m.contains("http 429") || m.contains("http 500")
                || m.contains("http 502") || m.contains("http 503") || m.contains("http 504")
                || m.contains("timeout") || m.contains("timed out") || m.contains("runtime error")
                || m.contains("too many") || m.contains("memory") || m.contains("respuesta inválida");
    }

    private List<double[]> splitIntoFour(double[] b) {
        double midLat = (b[0] + b[2]) / 2.0;
        double midLon = (b[1] + b[3]) / 2.0;
        List<double[]> result = new ArrayList<>();
        result.add(new double[]{b[0], b[1], midLat, midLon});
        result.add(new double[]{b[0], midLon, midLat, b[3]});
        result.add(new double[]{midLat, b[1], b[2], midLon});
        result.add(new double[]{midLat, midLon, b[2], b[3]});
        return result;
    }

    private void updateSectorProgress(ProgressDialog progress, int completed, int total, String message) {
        mainHandler.post(() -> {
            if (!progress.isShowing()) return;
            progress.setMax(Math.max(1, total));
            progress.setProgress(Math.min(completed, total));
            progress.setMessage(message + "\nPuedes cancelar cuando quieras.");
        });
    }

    private void writeOfflineIndex(File packageDir, String name, String detail, double[] b,
                                   JSONArray chunks, int elementCount, long bytes) throws Exception {
        JSONObject index = new JSONObject();
        index.put("version", 2);
        index.put("name", name);
        index.put("detail", detail);
        index.put("south", b[0]); index.put("west", b[1]);
        index.put("north", b[2]); index.put("east", b[3]);
        index.put("elements", elementCount);
        index.put("bytes", bytes);
        index.put("chunks", chunks);
        File file = new File(packageDir, "index.json");
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(index.toString().getBytes("UTF-8"));
        }
    }

    private String buildOverpassQuery(String detail, double s, double w, double n, double e) {
        String bbox = String.format(Locale.US, "(%.7f,%.7f,%.7f,%.7f)", s, w, n, e);
        StringBuilder q = new StringBuilder("[out:json][timeout:75];(");
        if ("básico".equals(detail)) {
            q.append("way[\"highway\"~\"motorway|trunk|primary|secondary|tertiary\"]").append(bbox).append(';');
            q.append("way[\"waterway\"]").append(bbox).append(';');
            q.append("way[\"natural\"=\"water\"]").append(bbox).append(';');
        } else {
            q.append("way[\"highway\"]").append(bbox).append(';');
            q.append("way[\"waterway\"]").append(bbox).append(';');
            q.append("way[\"railway\"]").append(bbox).append(';');
            q.append("way[\"natural\"=\"water\"]").append(bbox).append(';');
            q.append("way[\"landuse\"]").append(bbox).append(';');
            if ("alto".equals(detail)) {
                q.append("way[\"building\"]").append(bbox).append(';');
                q.append("node[\"place\"~\"city|town|village|hamlet\"]").append(bbox).append(';');
            }
        }
        q.append(");out geom;");
        return q.toString();
    }

    private void postOverpassToFile(String query, File target) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://overpass-api.de/api/interpreter");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(180000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.11 Android (com.bph.geotopo)");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            byte[] body = ("data=" + URLEncoder.encode(query, "UTF-8")).getBytes("UTF-8");
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = new BufferedOutputStream(connection.getOutputStream())) {
                out.write(body);
            }
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) {
                InputStream error = connection.getErrorStream();
                String detail = "";
                try { detail = readStream(error, 256 * 1024); } catch (Exception ignored) {}
                throw new Exception("Servidor cartográfico respondió HTTP " + code
                        + (detail.isEmpty() ? "." : ": " + cleanServerMessage(detail)));
            }
            copyResponseToFile(connection.getInputStream(), target);
            if (!target.exists() || target.length() < 20) throw new Exception("Respuesta cartográfica vacía.");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private long copyResponseToFile(InputStream input, File target) throws Exception {
        if (input == null) throw new Exception("Respuesta vacía.");
        long total = 0L;
        try (InputStream in = new BufferedInputStream(input);
             OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
            byte[] buffer = new byte[32768];
            int read;
            while ((read = in.read(buffer)) != -1) {
                if (cancelDownload) throw new InterruptedException("cancelled");
                out.write(buffer, 0, read);
                total += read;
                if ((total & ((1L << 20) - 1L)) < read && availableStorageBytes() < MIN_FREE_STORAGE_BYTES) {
                    throw new Exception("El almacenamiento del teléfono se quedó sin espacio disponible.");
                }
            }
        }
        return total;
    }

    private int countJsonElements(File file) throws Exception {
        int count = 0;
        boolean found = false;
        String remark = "";
        try (Reader base = new InputStreamReader(new BufferedInputStream(new FileInputStream(file)), "UTF-8");
             JsonReader reader = new JsonReader(base)) {
            reader.beginObject();
            while (reader.hasNext()) {
                String name = reader.nextName();
                if ("elements".equals(name)) {
                    found = true;
                    reader.beginArray();
                    while (reader.hasNext()) {
                        reader.skipValue();
                        count++;
                    }
                    reader.endArray();
                } else if ("remark".equals(name)) {
                    remark = reader.nextString();
                } else {
                    reader.skipValue();
                }
            }
            reader.endObject();
        } catch (Exception ex) {
            throw new Exception("Respuesta inválida del servidor cartográfico.", ex);
        }
        if (!found) throw new Exception("Respuesta inválida: no contiene elementos cartográficos.");
        if (remark != null && !remark.trim().isEmpty()) {
            throw new Exception("Servidor cartográfico: " + cleanServerMessage(remark));
        }
        return count;
    }

    private void copyFile(File source, File target) throws Exception {
        try (InputStream in = new BufferedInputStream(new FileInputStream(source));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
            byte[] buffer = new byte[32768];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
        }
    }

    private String cleanServerMessage(String raw) {
        String text = raw == null ? "" : raw.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim();
        return text.length() > 180 ? text.substring(0, 180) + "…" : text;
    }

    private String readStream(InputStream input, int limitBytes) throws Exception {
        if (input == null) throw new Exception("Respuesta vacía.");
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            int total = 0;
            while ((read = in.read(buffer)) != -1) {
                if (cancelDownload) throw new InterruptedException("cancelled");
                total += read;
                if (total > limitBytes) throw new Exception("Respuesta demasiado grande para esta operación.");
                out.write(buffer, 0, read);
            }
            return out.toString("UTF-8");
        }
    }

    private double bboxAreaKm2(double s, double w, double n, double e) {
        double midLat = Math.toRadians((s + n) / 2.0);
        double latKm = Math.abs(n - s) * 111.32;
        double lonDelta = Math.abs(e - w);
        if (lonDelta > 180) lonDelta = 360 - lonDelta;
        double lonKm = lonDelta * 111.32 * Math.max(0.05, Math.cos(midLat));
        return latKm * lonKm;
    }

    private void showOfflineMaps() {
        List<MapPackage> maps = loadMapPackages();
        if (maps.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Mis mapas descargados")
                    .setMessage("Todavía no hay mapas guardados. Pulsa Descargar en la barra inferior, elige 1, 3, 5 o 10 km y completa la descarga.")
                    .setPositiveButton("Descargar ahora", (d, w) -> showDownloadDialog())
                    .setNegativeButton("Cerrar", null)
                    .show();
            return;
        }
        String[] labels = new String[maps.size()];
        for (int i = 0; i < maps.size(); i++) {
            MapPackage p = maps.get(i);
            double area = bboxAreaKm2(p.south, p.west, p.north, p.east);
            labels[i] = p.name
                    + "\nDisponible sin internet · "
                    + String.format(Locale.US, "%.1f km²", area)
                    + " · " + (p.detail == null || p.detail.isEmpty() ? "vectorial" : "detalle " + p.detail);
        }
        new AlertDialog.Builder(this)
                .setTitle("Mis mapas descargados")
                .setMessage("Toca un mapa para abrirlo sin internet o ver la misma zona con mapas online.")
                .setItems(labels, (d, which) -> showOfflineActions(maps.get(which)))
                .setPositiveButton("Descargar otro", (d, w) -> showDownloadDialog())
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showOfflineActions(MapPackage pkg) {
        String[] actions = {
                "Abrir mapa guardado · sin internet",
                "Ver la zona con calles · requiere internet",
                "Ver la zona en satélite · requiere internet",
                "Ver satélite con nombres · requiere internet",
                "Eliminar mapa"
        };
        new AlertDialog.Builder(this)
                .setTitle(pkg.name)
                .setMessage("El mapa descargado funciona sin internet y es vectorial. La vista satelital siempre requiere conexión.")
                .setItems(actions, (d, which) -> {
                    if (which == 0) openOfflinePackage(pkg);
                    else if (which == 1) openOnlinePackage(pkg, "standard");
                    else if (which == 2) openOnlinePackage(pkg, "satellite");
                    else if (which == 3) openOnlinePackage(pkg, "hybrid");
                    else confirmDeleteOffline(pkg);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void openOfflinePackage(MapPackage pkg) {
        currentMode = "offline";
        if (modeBadge != null) modeBadge.setText("Offline · " + pkg.name);
        if (modeSubtitleView != null) modeSubtitleView.setText("Mapa descargado · sin internet");
        js(String.format(Locale.US, "setOfflineVector(%s,%.9f,%.9f,%d,%.9f,%.9f,%.9f,%.9f)",
                JSONObject.quote(pkg.folder), pkg.centerLat, pkg.centerLon, pkg.openZoom,
                pkg.south, pkg.west, pkg.north, pkg.east));
        setStatus("Mapa guardado abierto: " + pkg.name + ". Esta vista funciona sin internet.");
    }

    private void openOnlinePackage(MapPackage pkg, String mode) {
        setMode(mode);
        mainHandler.postDelayed(() -> js(String.format(Locale.US, "fitBounds(%.9f,%.9f,%.9f,%.9f)",
                pkg.south, pkg.west, pkg.north, pkg.east)), 180L);
        String type = "satellite".equals(mode) ? "satélite"
                : "hybrid".equals(mode) ? "satélite con nombres" : "calles y lugares";
        setStatus("Mostrando la zona de “" + pkg.name + "” con " + type + ". Requiere internet.");
    }

    private void confirmDeleteOffline(MapPackage pkg) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar mapa")
                .setMessage("¿Eliminar “" + pkg.name + "” y sus datos cartográficos?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    deleteRecursive(new File(offlineBaseDir(), pkg.folder));
                    removeMapPackage(pkg.folder);
                    Toast.makeText(this, "Mapa eliminado", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private double centerLongitude(double w, double e) {
        if (w <= e) return (w + e) / 2.0;
        double value = (w + (e + 360.0)) / 2.0;
        if (value > 180.0) value -= 360.0;
        return value;
    }

    private File offlineBaseDir() {
        File external = getExternalFilesDir("offline_maps");
        File base = external != null ? external : new File(getFilesDir(), "offline_maps");
        if (!base.exists()) base.mkdirs();
        return base;
    }

    private String uniqueFolderName(String displayName) {
        String base = displayName.replaceAll("[^A-Za-z0-9_-]", "_").replaceAll("_+", "_");
        if (base.isEmpty()) base = "mapa";
        String folder = base;
        int index = 2;
        while (new File(offlineBaseDir(), folder).exists()) folder = base + "_" + index++;
        return folder;
    }

    private void saveMapPackage(MapPackage pkg) {
        List<MapPackage> maps = loadMapPackages();
        maps.add(pkg);
        JSONArray array = new JSONArray();
        for (MapPackage item : maps) array.put(item.toJson());
        getSharedPreferences(MAP_PREFS, MODE_PRIVATE).edit().putString(KEY_MAPS, array.toString()).apply();
    }

    private List<MapPackage> loadMapPackages() {
        List<MapPackage> maps = new ArrayList<>();
        String json = getSharedPreferences(MAP_PREFS, MODE_PRIVATE).getString(KEY_MAPS, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                MapPackage p = MapPackage.fromJson(o);
                if (p.folder != null) {
                    File folder = new File(offlineBaseDir(), p.folder);
                    File index = new File(folder, "index.json");
                    File legacy = new File(folder, "data.json");
                    if (folder.exists() && ((index.exists() && index.length() > 0)
                            || (legacy.exists() && legacy.length() > 0))) maps.add(p);
                }
            }
        } catch (JSONException ignored) {}
        return maps;
    }

    private void removeMapPackage(String folder) {
        List<MapPackage> maps = loadMapPackages();
        JSONArray array = new JSONArray();
        for (MapPackage p : maps) if (!folder.equals(p.folder)) array.put(p.toJson());
        getSharedPreferences(MAP_PREFS, MODE_PRIVATE).edit().putString(KEY_MAPS, array.toString()).apply();
    }

    private boolean deleteRecursive(File file) {
        if (file == null || !file.exists()) return true;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        return file.delete();
    }

    private void js(String code) {
        if (webView == null) return;
        if (!mapReady) {
            mainHandler.postDelayed(() -> js(code), 250L);
            return;
        }
        webView.evaluateJavascript(code, null);
    }

    private void setStatus(String value) {
        if (statusView != null) statusView.setText(value);
    }

    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(textColor);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private RadioButton radio(String value) {
        RadioButton button = new RadioButton(this);
        button.setText(value);
        button.setTextColor(Color.rgb(32, 36, 43));
        button.setTextSize(13);
        button.setPadding(dp(4), dp(4), dp(4), dp(4));
        return button;
    }

    private Button compactButton(String value, boolean margins) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(bestContrastColor(accentColor));
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accentColor);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), accentColor);
        b.setBackground(bg);
        if (margins) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
            lp.setMargins(dp(3), 0, dp(3), 0);
            b.setLayoutParams(lp);
        }
        return b;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), dp(2), dp(3), dp(2));
        return lp;
    }

    private LinearLayout.LayoutParams smallWeightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(44));
        lp.setMargins(dp(3), dp(2), dp(3), dp(2));
        return lp;
    }

    private int bestContrastColor(int color) {
        double luminance = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
        return luminance > 170 ? Color.BLACK : Color.WHITE;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (mapReady && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startLocationUpdates();
        }
    }

    @Override
    protected void onPause() {
        stopLocationUpdates();
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopLocationUpdates();
        mainHandler.removeCallbacks(locationTimeout);
        downloadExecutor.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private final class MapBridge {
        @JavascriptInterface
        public void onMapReady() {
            runOnUiThread(() -> {
                mapReady = true;
                loadSavedPoints(false);
                Intent intent = getIntent();
                boolean hasOrientation = intent != null && intent.hasExtra("ab_a_lat") && intent.hasExtra("ab_b_lat");
                if (intent != null && intent.hasExtra("latitude") && intent.hasExtra("longitude")) {
                    double lat = intent.getDoubleExtra("latitude", -9.19);
                    double lon = intent.getDoubleExtra("longitude", -75.015);
                    float accuracy = intent.getFloatExtra("location_accuracy", 0f);
                    float bearing = intent.getFloatExtra("location_bearing", -1f);
                    js(String.format(Locale.US, "showCurrentLocation(%.9f,%.9f,%.2f,%.2f,true)", lat, lon, accuracy, bearing));
                    autoCenteredOnce = true;
                } else {
                    Location saved = readSharedLocation();
                    if (saved != null && locationAgeMs(saved) <= 24L * 60L * 60L * 1000L) {
                        currentLocation = saved;
                        sendLocationToMap(saved, true);
                        autoCenteredOnce = true;
                        setLocationStatus(saved);
                    }
                }
                if (hasOrientation) {
                    double aLat = intent.getDoubleExtra("ab_a_lat", 0);
                    double aLon = intent.getDoubleExtra("ab_a_lon", 0);
                    double aAcc = intent.getDoubleExtra("ab_a_acc", 0);
                    double bLat = intent.getDoubleExtra("ab_b_lat", 0);
                    double bLon = intent.getDoubleExtra("ab_b_lon", 0);
                    double bAcc = intent.getDoubleExtra("ab_b_acc", 0);
                    double bearing = intent.getDoubleExtra("ab_bearing", 0);
                    double distance = intent.getDoubleExtra("ab_distance", 0);
                    js(String.format(Locale.US,
                            "showOrientationLine(%.9f,%.9f,%.2f,%.9f,%.9f,%.2f,%.3f,%.3f)",
                            aLat, aLon, aAcc, bLat, bLon, bAcc, bearing, distance));
                    setStatus(String.format(Locale.US, "Línea A–B: %.2f m · azimut %.2f°", distance, bearing));
                }
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    followLocation = !hasOrientation && !autoCenteredOnce;
                    startLocationUpdates();
                } else if (!hasOrientation && !autoCenteredOnce) {
                    setStatus("Pulsa Ubicación para mostrar tu posición actual.");
                }
            });
        }

        @JavascriptInterface
        public void onBoundsChanged(double s, double w, double n, double e, int z) {
            south = s; west = w; north = n; east = e; currentZoom = z;
        }

        @JavascriptInterface
        public void onDownloadSelectionChanged(double s, double w, double n, double e) {
            runOnUiThread(() -> {
                downloadSouth = s; downloadWest = w; downloadNorth = n; downloadEast = e;
                if (downloadSelectionActive && downloadSelectionInfoView != null) {
                    downloadSelectionInfoView.setText(formatSelectionInfo(s, w, n, e));
                }
            });
        }

        @JavascriptInterface
        public void onMeasureState(String json) {
            runOnUiThread(() -> {
                try {
                    JSONObject state = new JSONObject(json == null ? "{}" : json);
                    measurementMode = state.optString("mode", "distance");
                    measurementActive = state.optBoolean("active", false);
                    measurementPointCount = state.optInt("points", 0);
                    String summary = state.optString("summary", "");
                    if (measureTitleView != null) measureTitleView.setText("area".equals(measurementMode)
                            ? "Medir área y perímetro" : "Medir distancia");
                    if (measureResultView != null) measureResultView.setText(summary);
                    if (measureHintView != null) {
                        if (measurementActive) measureHintView.setText("Toca el mapa para agregar puntos. Cada tramo es una línea recta. Usa ↶ si te equivocas.");
                        else if (measurementPointCount > 0) measureHintView.setText("Medición finalizada. El resultado permanece dibujado.");
                        else measureHintView.setText("Elige un tipo de medición y toca el mapa.");
                    }
                    if (measurementPointCount > 0 && measurePanel != null && measurePanel.getVisibility() == View.VISIBLE) {
                        if (statusView != null) statusView.setVisibility(View.GONE);
                    }
                    setStatus(summary);
                } catch (JSONException ignored) {
                    setStatus("No se pudo leer el resultado de la medición.");
                }
            });
        }

        @JavascriptInterface
        public void onMeasureResult(String text) {
            runOnUiThread(() -> setStatus(text == null || text.trim().isEmpty()
                    ? "Toca el mapa para medir distancia o área."
                    : text));
        }

        @JavascriptInterface
        public void onOfflineLoaded(int count) {
            runOnUiThread(() -> setStatus(count < 0
                    ? "No se pudieron abrir los datos del mapa offline."
                    : "Mapa offline cargado: " + count + " elementos cartográficos."));
        }

        @JavascriptInterface
        public void onTileProblem(final String mode, final int zoom) {
            runOnUiThread(() -> {
                if ("satellite".equals(mode) || "hybrid".equals(mode)) {
                    setStatus("La imagen satelital no tiene más detalle aquí. Reduce el zoom o usa Calles y lugares.");
                } else {
                    setStatus("No se pudo cargar parte del mapa. Revisa internet o cambia de capa.");
                }
            });
        }
    }

    private final class OfflineTileClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (uri != null && "offline.local".equalsIgnoreCase(uri.getHost())) {
                List<String> parts = uri.getPathSegments();
                if (parts.size() == 2 && parts.get(1).matches("[A-Za-z0-9_.-]+\\.json")) {
                    try {
                        File packageDir = new File(offlineBaseDir(), parts.get(0));
                        File data = new File(packageDir, parts.get(1));
                        String basePath = packageDir.getCanonicalPath() + File.separator;
                        if (data.getCanonicalPath().startsWith(basePath) && data.exists() && data.length() > 0) {
                            HashMap<String, String> headers = new HashMap<>();
                            headers.put("Access-Control-Allow-Origin", "*");
                            headers.put("Cache-Control", "no-store");
                            return new WebResourceResponse("application/json", "UTF-8", 200, "OK", headers, new FileInputStream(data));
                        }
                    } catch (Exception ignored) {}
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse("application/json", "UTF-8", 404, "Not Found", headers,
                            new java.io.ByteArrayInputStream("{\"elements\":[],\"chunks\":[]}".getBytes()));
                }
            }
            return super.shouldInterceptRequest(view, request);
        }
    }

    private static final class MapPackage {
        String name;
        String folder;
        double south;
        double west;
        double north;
        double east;
        double centerLat;
        double centerLon;
        int minZoom;
        int maxZoom;
        int openZoom;
        int tileCount;
        int downloadedTiles;
        int dataCount;
        String detail;
        long createdAt;

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("name", name);
                o.put("folder", folder);
                o.put("south", south); o.put("west", west); o.put("north", north); o.put("east", east);
                o.put("centerLat", centerLat); o.put("centerLon", centerLon);
                o.put("minZoom", minZoom); o.put("maxZoom", maxZoom); o.put("openZoom", openZoom);
                o.put("tileCount", tileCount); o.put("downloadedTiles", downloadedTiles); o.put("dataCount", dataCount); o.put("detail", detail); o.put("createdAt", createdAt);
            } catch (JSONException ignored) {}
            return o;
        }

        static MapPackage fromJson(JSONObject o) {
            MapPackage p = new MapPackage();
            p.name = o.optString("name", "Mapa offline");
            p.folder = o.optString("folder", "");
            p.south = o.optDouble("south", 0); p.west = o.optDouble("west", 0); p.north = o.optDouble("north", 0); p.east = o.optDouble("east", 0);
            p.centerLat = o.optDouble("centerLat", 0); p.centerLon = o.optDouble("centerLon", 0);
            p.minZoom = o.optInt("minZoom", 10); p.maxZoom = o.optInt("maxZoom", 14); p.openZoom = o.optInt("openZoom", p.minZoom);
            p.tileCount = o.optInt("tileCount", 0); p.downloadedTiles = o.optInt("downloadedTiles", p.tileCount); p.dataCount = o.optInt("dataCount", p.downloadedTiles); p.detail = o.optString("detail", ""); p.createdAt = o.optLong("createdAt", 0L);
            return p;
        }
    }
}
