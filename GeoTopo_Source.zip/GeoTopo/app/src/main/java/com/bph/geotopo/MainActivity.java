package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;

    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 184, 148),
            Color.rgb(255, 171, 0),
            Color.rgb(142, 68, 173),
            Color.rgb(231, 76, 60)
    };
    private static final int[] COMPASS_ARROW_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 184, 148),
            Color.rgb(255, 171, 0),
            Color.rgb(231, 76, 60),
            Color.rgb(255, 255, 255)
    };
    private static final int[] COMPASS_RING_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 184, 148),
            Color.rgb(255, 171, 0),
            Color.rgb(194, 170, 120),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentIndex;
    private int arrowColorIndex;
    private int ringColorIndex;

    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;
    private int cellEditColor;
    private int cellLockedColor;
    private int tableLineColor;
    private int compassArrowColor;
    private int compassRingColor;

    private ZoomLayout zoomLayout;

    private EditText azInput;
    private TextView compassCaption;
    private TextView azModeHint;
    private Button modeAzBtn;
    private Button modeRumboBtn;
    private Button modeContraAzBtn;
    private Button modeContraRumboBtn;
    private TextView compassAzLabel;
    private TextView compassRumboLabel;
    private TextView compassContraAzLabel;
    private TextView compassContraRumboLabel;
    private int azInputMode = 0;
    private CompassView compassAzView;
    private CompassView compassRumboView;
    private CompassView compassContraAzView;
    private CompassView compassContraRumboView;

    private EditText coordAzInput;
    private EditText distanceInput;
    private TextView coordResult;

    private EditText dhInput;
    private EditText diInput;
    private EditText angleInput;
    private EditText desnivelInput;
    private TextView distanceCalcResult;

    private EditText polyX0Input;
    private EditText polyY0Input;
    private TextView polyCheckResult;

    private TextView levelCheckResult;
    private TextView stadiaCheckResult;

    private final List<TableDataRow> tableRows = new ArrayList<>();
    private final List<LevelDataRow> levelRows = new ArrayList<>();
    private final List<StadiaLevelRow> stadiaRows = new ArrayList<>();
    private TableLayout coordTable;
    private TableLayout levelTable;
    private TableLayout stadiaTable;
    private boolean suppressWorkCapture = false;
    private boolean showingSettings = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        buildUi();
    }

    @Override
    protected void onPause() {
        saveCurrentWork();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (showingSettings) {
            showingSettings = false;
            buildUi();
        } else {
            super.onBackPressed();
        }
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        accentIndex = sp.getInt("accent", 0);
        arrowColorIndex = sp.getInt("arrow_color", 0);
        ringColorIndex = sp.getInt("ring_color", 0);
    }

    private void savePrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("theme", themeMode)
                .putInt("accent", accentIndex)
                .putInt("arrow_color", arrowColorIndex)
                .putInt("ring_color", ringColorIndex)
                .apply();
    }

    private void applyPalette() {
        borderColor = ACCENTS[accentIndex % ACCENTS.length];
        compassArrowColor = COMPASS_ARROW_COLORS[arrowColorIndex % COMPASS_ARROW_COLORS.length];
        compassRingColor = COMPASS_RING_COLORS[ringColorIndex % COMPASS_RING_COLORS.length];

        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputFillColor = Color.WHITE;
            inputStrokeColor = Color.rgb(178, 184, 196);
            resultFillColor = Color.rgb(245, 252, 248);
            resultStrokeColor = Color.rgb(29, 185, 84);
            cellEditColor = Color.rgb(252, 253, 255);
            cellLockedColor = Color.rgb(244, 246, 250);
            tableLineColor = Color.rgb(190, 196, 206);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(12, 18, 28);
            cellLockedColor = Color.rgb(21, 23, 28);
            tableLineColor = Color.rgb(74, 78, 88);
        } else {
            bgColor = Color.rgb(13, 18, 28);
            appBarColor = Color.rgb(6, 38, 63);
            cardColor = Color.rgb(22, 29, 40);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(184, 190, 198);
            inputFillColor = Color.rgb(15, 21, 31);
            inputStrokeColor = Color.rgb(85, 92, 104);
            resultFillColor = Color.rgb(13, 42, 30);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(11, 25, 41);
            cellLockedColor = Color.rgb(25, 31, 42);
            tableLineColor = Color.rgb(78, 84, 96);
        }
    }

    private void buildUi() {
        if (!suppressWorkCapture) saveCurrentWork();
        showingSettings = false;
        applyPalette();
        tableRows.clear();
        levelRows.clear();
        stadiaRows.clear();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        zoomLayout = new ZoomLayout(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        content.addView(azimuthBlock());
        content.addView(coordBlock());
        content.addView(distanceBlock());
        content.addView(partialTableBlock());
        content.addView(levelingBlock());
        content.addView(stadiaLevelingBlock());

        zoomLayout.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        scroll.addView(zoomLayout);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));
        setContentView(root);
        restoreCurrentWork();
    }

    private void saveCurrentWork() {
        if (azInput == null) return;

        SharedPreferences.Editor ed = getSharedPreferences(PREFS, MODE_PRIVATE).edit();

        putText(ed, "work_az_input", azInput);
        putText(ed, "work_az_label", compassAzLabel);
        putText(ed, "work_rumbo_label", compassRumboLabel);
        putText(ed, "work_contraaz_label", compassContraAzLabel);
        putText(ed, "work_contrarumbo_label", compassContraRumboLabel);
        putText(ed, "work_compass_caption", compassCaption);

        putText(ed, "work_coord_az", coordAzInput);
        putText(ed, "work_coord_dist", distanceInput);
        putText(ed, "work_coord_result", coordResult);

        putText(ed, "work_dh", dhInput);
        putText(ed, "work_di", diInput);
        putText(ed, "work_angle", angleInput);
        putText(ed, "work_desnivel", desnivelInput);
        putText(ed, "work_distance_result", distanceCalcResult);
        putText(ed, "work_poly_x0", polyX0Input);
        putText(ed, "work_poly_y0", polyY0Input);
        putText(ed, "work_poly_check", polyCheckResult);

        putText(ed, "work_level_check", levelCheckResult);
        putText(ed, "work_stadia_check", stadiaCheckResult);

        ed.putInt("work_coord_count", tableRows.size());
        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            putText(ed, "work_coord_" + i + "_est", r.est);
            putText(ed, "work_coord_" + i + "_pv", r.pv);
            putText(ed, "work_coord_" + i + "_az", r.az);
            putText(ed, "work_coord_" + i + "_dist", r.dist);
            putText(ed, "work_coord_" + i + "_rumbo", r.rumbo);
            putText(ed, "work_coord_" + i + "_sen", r.sen);
            putText(ed, "work_coord_" + i + "_cos", r.cos);
            putText(ed, "work_coord_" + i + "_este", r.este);
            putText(ed, "work_coord_" + i + "_oeste", r.oeste);
            putText(ed, "work_coord_" + i + "_norte", r.norte);
            putText(ed, "work_coord_" + i + "_sur", r.sur);
            putText(ed, "work_coord_" + i + "_ec", r.eCorr);
            putText(ed, "work_coord_" + i + "_wc", r.wCorr);
            putText(ed, "work_coord_" + i + "_nc", r.nCorr);
            putText(ed, "work_coord_" + i + "_sc", r.sCorr);
            putText(ed, "work_coord_" + i + "_x", r.x);
            putText(ed, "work_coord_" + i + "_y", r.y);
        }

        ed.putInt("work_level_count", levelRows.size());
        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            putText(ed, "work_level_" + i + "_pv", r.pv);
            putText(ed, "work_level_" + i + "_va", r.vAtras);
            putText(ed, "work_level_" + i + "_vi", r.vIntermedia);
            putText(ed, "work_level_" + i + "_vf", r.vAdelante);
            putText(ed, "work_level_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_level_" + i + "_cn", r.cotaNivel);
        }

        ed.putInt("work_stadia_count", stadiaRows.size());
        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            putText(ed, "work_stadia_" + i + "_pv", r.pv);
            putText(ed, "work_stadia_" + i + "_tipo", r.tipo);
            putText(ed, "work_stadia_" + i + "_hi", r.hInf);
            putText(ed, "work_stadia_" + i + "_hm", r.hMedio);
            putText(ed, "work_stadia_" + i + "_hs", r.hSup);
            putText(ed, "work_stadia_" + i + "_dist", r.distancia);
            putText(ed, "work_stadia_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        ed.apply();
    }

    private void restoreCurrentWork() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);

        setTextIfExists(sp, "work_az_input", azInput);
        setTextIfExists(sp, "work_az_label", compassAzLabel);
        setTextIfExists(sp, "work_rumbo_label", compassRumboLabel);
        setTextIfExists(sp, "work_contraaz_label", compassContraAzLabel);
        setTextIfExists(sp, "work_contrarumbo_label", compassContraRumboLabel);
        setTextIfExists(sp, "work_compass_caption", compassCaption);

        setTextIfExists(sp, "work_coord_az", coordAzInput);
        setTextIfExists(sp, "work_coord_dist", distanceInput);
        setTextIfExists(sp, "work_coord_result", coordResult);

        setTextIfExists(sp, "work_dh", dhInput);
        setTextIfExists(sp, "work_di", diInput);
        setTextIfExists(sp, "work_angle", angleInput);
        setTextIfExists(sp, "work_desnivel", desnivelInput);
        setTextIfExists(sp, "work_distance_result", distanceCalcResult);
        setTextIfExists(sp, "work_poly_x0", polyX0Input);
        setTextIfExists(sp, "work_poly_y0", polyY0Input);
        setTextIfExists(sp, "work_poly_check", polyCheckResult);

        setTextIfExists(sp, "work_level_check", levelCheckResult);
        setTextIfExists(sp, "work_stadia_check", stadiaCheckResult);

        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            setTextIfExists(sp, "work_coord_" + i + "_est", r.est);
            setTextIfExists(sp, "work_coord_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_coord_" + i + "_az", r.az);
            setTextIfExists(sp, "work_coord_" + i + "_dist", r.dist);
            setTextIfExists(sp, "work_coord_" + i + "_rumbo", r.rumbo);
            setTextIfExists(sp, "work_coord_" + i + "_sen", r.sen);
            setTextIfExists(sp, "work_coord_" + i + "_cos", r.cos);
            setTextIfExists(sp, "work_coord_" + i + "_este", r.este);
            setTextIfExists(sp, "work_coord_" + i + "_oeste", r.oeste);
            setTextIfExists(sp, "work_coord_" + i + "_norte", r.norte);
            setTextIfExists(sp, "work_coord_" + i + "_sur", r.sur);
            setTextIfExists(sp, "work_coord_" + i + "_ec", r.eCorr);
            setTextIfExists(sp, "work_coord_" + i + "_wc", r.wCorr);
            setTextIfExists(sp, "work_coord_" + i + "_nc", r.nCorr);
            setTextIfExists(sp, "work_coord_" + i + "_sc", r.sCorr);
            setTextIfExists(sp, "work_coord_" + i + "_x", r.x);
            setTextIfExists(sp, "work_coord_" + i + "_y", r.y);
        }

        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            setTextIfExists(sp, "work_level_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_level_" + i + "_va", r.vAtras);
            setTextIfExists(sp, "work_level_" + i + "_vi", r.vIntermedia);
            setTextIfExists(sp, "work_level_" + i + "_vf", r.vAdelante);
            setTextIfExists(sp, "work_level_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_level_" + i + "_cn", r.cotaNivel);
        }

        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            setTextIfExists(sp, "work_stadia_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_stadia_" + i + "_tipo", r.tipo);
            setTextIfExists(sp, "work_stadia_" + i + "_hi", r.hInf);
            setTextIfExists(sp, "work_stadia_" + i + "_hm", r.hMedio);
            setTextIfExists(sp, "work_stadia_" + i + "_hs", r.hSup);
            setTextIfExists(sp, "work_stadia_" + i + "_dist", r.distancia);
            setTextIfExists(sp, "work_stadia_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        try {
            String s = azInput.getText().toString().trim();
            if (!s.isEmpty()) {
                double az = normalize(parseAngle(s));
                double contra = contraAzimuth(az);
                if (compassAzView != null) compassAzView.setAzimuth(az);
                if (compassRumboView != null) compassRumboView.setAzimuth(az);
                if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
                if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
            }
        } catch (Exception ignored) {
        }
    }

    private void putText(SharedPreferences.Editor ed, String key, TextView view) {
        if (view != null) ed.putString(key, view.getText().toString());
    }

    private void setTextIfExists(SharedPreferences sp, String key, TextView view) {
        if (view != null && sp.contains(key)) view.setText(sp.getString(key, ""));
    }

    private void clearWorkAndRebuild() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        for (String key : sp.getAll().keySet()) {
            if (key.startsWith("work_")) ed.remove(key);
        }
        ed.commit();
        suppressWorkCapture = true;
        buildUi();
        suppressWorkCapture = false;
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(14), dp(14), dp(14));
        bar.setBackgroundColor(appBarColor);

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleWrap.setLayoutParams(titleParams);

        TextView title = new TextView(this);
        title.setText("Geo Topo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleWrap.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Cálculos topográficos");
        sub.setTextColor(Color.rgb(193, 218, 240));
        sub.setTextSize(13);
        titleWrap.addView(sub);
        bar.addView(titleWrap);

        Button settings = new Button(this);
        settings.setText("Ajustes");
        settings.setAllCaps(false);
        settings.setTextColor(Color.WHITE);
        settings.setTextSize(14);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        settings.setBackground(gd);
        settings.setPadding(dp(14), dp(8), dp(14), dp(8));
        settings.setOnClickListener(v -> showSettingsScreen());
        bar.addView(settings);

        return bar;
    }

    private void showSettingsScreen() {
        saveCurrentWork();
        applyPalette();
        showingSettings = true;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(settingsBar());

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(18), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        content.addView(settingHeader("APARIENCIA"));
        content.addView(themeRow("☀", "Tema claro", "Fondo blanco limpio", THEME_LIGHT));
        content.addView(themeRow("☾", "Tema oscuro", "Fondo azul oscuro", THEME_DARK));
        content.addView(themeRow("●", "Tema negro", "Fondo negro AMOLED", THEME_BLACK));

        content.addView(settingHeader("COLORES"));
        content.addView(valueRow("▣", "Color de cuadros", accentName(accentIndex), v -> {
            accentIndex = (accentIndex + 1) % ACCENTS.length;
            savePrefs();
            showSettingsScreen();
        }));
        content.addView(valueRow("➤", "Flecha de brújula", arrowName(arrowColorIndex), v -> {
            arrowColorIndex = (arrowColorIndex + 1) % COMPASS_ARROW_COLORS.length;
            savePrefs();
            showSettingsScreen();
        }));
        content.addView(valueRow("◎", "Círculo de brújula", ringName(ringColorIndex), v -> {
            ringColorIndex = (ringColorIndex + 1) % COMPASS_RING_COLORS.length;
            savePrefs();
            showSettingsScreen();
        }));

        content.addView(settingHeader("TABLAS Y DATOS"));
        content.addView(infoRow("＋", "Agregar filas", "Usa + Fila o + Punto dentro de cada cuadro"));
        content.addView(infoRow("□", "Recordar datos", "Abrir donde te quedaste"));
        content.addView(valueRow("🧹", "Limpiar datos guardados", "Borra todos los cuadros", v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Limpiar datos")
                    .setMessage("¿Quieres borrar los datos guardados de los cuadros?")
                    .setPositiveButton("Borrar", (d, w) -> {
                        clearWorkAndRebuild();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        }));

        content.addView(settingHeader("VISUALIZACIÓN"));
        content.addView(infoRow("⌕", "Zoom fluido", "Usa dos dedos en los cuadros"));
        content.addView(valueRow("↺", "Reset zoom", "Volver a tamaño normal", v -> {
            if (zoomLayout != null) zoomLayout.resetZoom();
            Toast.makeText(this, "Zoom reiniciado", Toast.LENGTH_SHORT).show();
        }));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private View settingsBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(16), dp(14), dp(16));
        bar.setBackgroundColor(appBarColor);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(40);
        back.setGravity(Gravity.CENTER);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setOnClickListener(v -> {
            showingSettings = false;
            buildUi();
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView title = new TextView(this);
        title.setText("Ajustes");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView ok = new TextView(this);
        ok.setText("✓");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(34);
        ok.setGravity(Gravity.CENTER);
        ok.setTypeface(Typeface.DEFAULT_BOLD);
        ok.setOnClickListener(v -> {
            savePrefs();
            showingSettings = false;
            buildUi();
        });
        bar.addView(ok, new LinearLayout.LayoutParams(dp(54), dp(54)));
        return bar;
    }

    private TextView settingHeader(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(borderColor);
        v.setTextSize(14);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(4), dp(18), dp(4), dp(8));
        return v;
    }

    private View themeRow(String icon, String title, String subtitle, int mode) {
        return settingRow(icon, title, subtitle, themeMode == mode ? "◉" : "○", v -> {
            themeMode = mode;
            savePrefs();
            showSettingsScreen();
        });
    }

    private View valueRow(String icon, String title, String subtitle, View.OnClickListener listener) {
        return settingRow(icon, title, subtitle, "›", listener);
    }

    private View infoRow(String icon, String title, String subtitle) {
        return settingRow(icon, title, subtitle, "", null);
    }

    private View settingRow(String icon, String title, String subtitle, String right, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 35, 52));
        bg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(225, 230, 238) : Color.rgb(16, 48, 70));
        row.setBackground(bg);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, 0, 0, dp(6));
        row.setLayoutParams(rlp);
        if (listener != null) row.setOnClickListener(listener);

        TextView ico = new TextView(this);
        ico.setText(icon);
        ico.setTextSize(24);
        ico.setTextColor(borderColor);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(58), dp(54)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(textColor);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(t);
        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(subTextColor);
        s.setTextSize(13);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView rr = new TextView(this);
        rr.setText(right);
        rr.setTextColor(right.equals("◉") ? borderColor : subTextColor);
        rr.setTextSize(right.equals("›") ? 30 : 20);
        rr.setGravity(Gravity.CENTER);
        row.addView(rr, new LinearLayout.LayoutParams(dp(42), dp(54)));
        return row;
    }

    private String accentName(int idx) {
        String[] names = {"Azul", "Verde", "Ámbar", "Morado", "Rojo"};
        return names[idx % names.length];
    }

    private String arrowName(int idx) {
        String[] names = {"Azul", "Verde", "Ámbar", "Rojo", "Blanco"};
        return names[idx % names.length];
    }

    private String ringName(int idx) {
        String[] names = {"Azul", "Verde", "Ámbar", "Bronce", "Blanco"};
        return names[idx % names.length];
    }

    private View azimuthBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("1. Conversión angular"));
        box.addView(small("Elige qué dato tienes, escribe el valor y calcula azimut, rumbo, contraazimut y contrarumbo."));

        azModeHint = small("¿Qué dato tienes? Azimut");
        azModeHint.setPadding(0, dp(6), 0, dp(2));
        box.addView(azModeHint);

        LinearLayout modeRow1 = new LinearLayout(this);
        modeRow1.setOrientation(LinearLayout.HORIZONTAL);
        modeAzBtn = smallModeBtn("Azimut", 0);
        modeRumboBtn = smallModeBtn("Rumbo", 1);
        modeRow1.addView(modeAzBtn, weightParams());
        modeRow1.addView(modeRumboBtn, weightParams());
        box.addView(modeRow1);

        LinearLayout modeRow2 = new LinearLayout(this);
        modeRow2.setOrientation(LinearLayout.HORIZONTAL);
        modeContraAzBtn = smallModeBtn("Contraazimut", 2);
        modeContraRumboBtn = smallModeBtn("Contrarumbo", 3);
        modeRow2.addView(modeContraAzBtn, weightParams());
        modeRow2.addView(modeContraRumboBtn, weightParams());
        box.addView(modeRow2);

        azInput = edit("Ejemplo: 150°00'00\"");
        box.addView(azInput);
        setAzInputMode(0);

        Button calc = btn("Calcular");
        calc.setOnClickListener(v -> calculateAzimuth());
        box.addView(calc);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(compassItem("Azimut", 0), weightParams());
        row1.addView(compassItem("Rumbo", 1), weightParams());
        box.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(compassItem("Contraazimut", 2), weightParams());
        row2.addView(compassItem("Contrarumbo", 3), weightParams());
        box.addView(row2);

        compassCaption = smallCenter("Vista de referencia");
        compassCaption.setPadding(0, dp(6), 0, 0);
        box.addView(compassCaption);
        return box;
    }

    private Button smallModeBtn(String text, int mode) {
        Button b = btn(text);
        b.setTextSize(13);
        b.setOnClickListener(v -> setAzInputMode(mode));
        return b;
    }

    private void setAzInputMode(int mode) {
        azInputMode = mode;
        if (azModeHint != null) {
            String[] names = {"Azimut", "Rumbo", "Contraazimut", "Contrarumbo"};
            azModeHint.setText("¿Qué dato tienes? " + names[mode]);
        }
        if (azInput != null) {
            if (mode == 0) azInput.setHint("Ejemplo: 150°00'00\"");
            else if (mode == 1) azInput.setHint("Ejemplo: S 30°00'00\" E");
            else if (mode == 2) azInput.setHint("Ejemplo: 330°00'00\"");
            else azInput.setHint("Ejemplo: N 30°00'00\" W");
        }
        styleModeButton(modeAzBtn, mode == 0);
        styleModeButton(modeRumboBtn, mode == 1);
        styleModeButton(modeContraAzBtn, mode == 2);
        styleModeButton(modeContraRumboBtn, mode == 3);
    }

    private void styleModeButton(Button b, boolean active) {
        if (b == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(18));
        gd.setColor(active ? borderColor : inputFillColor);
        gd.setStroke(dp(active ? 2 : 1), active ? borderColor : inputStrokeColor);
        b.setBackground(gd);
        b.setTextColor(active ? Color.WHITE : textColor);
    }

    private View compassItem(String title, int type) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(4), dp(8), dp(4), dp(8));

        CompassView cv = new CompassView(this);
        cv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(185)));
        if (type == 0) compassAzView = cv;
        else if (type == 1) compassRumboView = cv;
        else if (type == 2) compassContraAzView = cv;
        else compassContraRumboView = cv;
        wrap.addView(cv);

        TextView t = compassResultChip(title, "—");
        if (type == 0) compassAzLabel = t;
        else if (type == 1) compassRumboLabel = t;
        else if (type == 2) compassContraAzLabel = t;
        else compassContraRumboLabel = t;
        wrap.addView(t);
        return wrap;
    }

    private TextView compassResultChip(String title, String value) {
        TextView v = tv(title.toUpperCase(Locale.US) + "\n" + value, 13, true);
        v.setGravity(Gravity.CENTER);
        v.setLineSpacing(0, 1.12f);
        v.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(2), dp(6), dp(2), 0);
        v.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(16, 25, 38));
        gd.setCornerRadius(dp(10));
        gd.setStroke(dp(1), borderColor);
        v.setBackground(gd);
        return v;
    }

    private View coordBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("2. Distancia y coordenadas parciales"));
        box.addView(small("Ingresa azimut y distancia horizontal para obtener seno, coseno, ΔX, ΔY y E/O/N/S."));

        coordAzInput = edit("Azimut");
        distanceInput = edit("Distancia horizontal");
        distanceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(coordAzInput);
        box.addView(distanceInput);

        Button calc = btn("Calcular E/O/N/S");
        calc.setOnClickListener(v -> calculateCoordinateSingle());
        box.addView(calc);

        coordResult = resultBox("Resultado pendiente");
        box.addView(coordResult);
        return box;
    }

    private View distanceBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("3. Distancia, desnivel y pendiente"));
        box.addView(small("Completa dos datos mínimos. Ejemplos: distancia horizontal + desnivel, o distancia inclinada + ángulo vertical."));

        dhInput = edit("Distancia horizontal");
        diInput = edit("Distancia inclinada");
        angleInput = edit("Ángulo vertical");
        desnivelInput = edit("Desnivel / diferencia de cota");

        dhInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        diInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        desnivelInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(dhInput);
        box.addView(diInput);
        box.addView(angleInput);
        box.addView(desnivelInput);

        Button calc = btn("Calcular distancia");
        calc.setOnClickListener(v -> calculateDistanceData());
        box.addView(calc);

        distanceCalcResult = resultBox("Resultado pendiente");
        box.addView(distanceCalcResult);
        return box;
    }

    private View partialTableBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("4. Poligonal cerrada"));
        box.addView(small("Llena estación, P.V., azimut y distancia. La app calcula rumbo, E/W/N/S, corrección y coordenadas X/Y."));

        LinearLayout xyRow = new LinearLayout(this);
        xyRow.setOrientation(LinearLayout.HORIZONTAL);
        polyX0Input = edit("X inicial");
        polyY0Input = edit("Y inicial");
        polyX0Input.setText("0.000");
        polyY0Input.setText("0.000");
        polyX0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        polyY0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        xyRow.addView(polyX0Input, weightParams());
        xyRow.addView(polyY0Input, weightParams());
        box.addView(xyRow);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        coordTable = new TableLayout(this);
        coordTable.setStretchAllColumns(false);
        coordTable.addView(headerRow("EST.", "P.V.", "AZIMUT", "DIST.", "RUMBO", "E", "W", "N", "S", "E CORR.", "W CORR.", "N CORR.", "S CORR.", "X", "Y"));
        int coordCount = Math.max(6, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_coord_count", 6));
        for (int i = 0; i < coordCount; i++) addCoordRow();
        hsv.addView(coordTable);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Fila");
        add.setOnClickListener(v -> addCoordRow());
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular poligonal");
        calc.setOnClickListener(v -> calculateTable());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);

        polyCheckResult = resultBox("Verificación pendiente");
        box.addView(polyCheckResult);
        return box;
    }

    private View levelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("5. Nivelación: cota terreno y cota nivel"));
        box.addView(small("Llena BM o punto inicial con cota conocida. Usa vista atrás, intermedia y adelante. Puedes agregar más puntos con +."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        levelTable = new TableLayout(this);
        levelTable.setStretchAllColumns(false);
        levelTable.addView(headerRow("P.V.", "V. ATRÁS (+)", "V. INTERMEDIA (-)", "V. ADELANTE (-)", "COTA TERRENO", "COTA NIVEL"));
        int levelCount = Math.max(12, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_level_count", 12));
        for (int i = 0; i < levelCount; i++) addLevelRow(i == 0 ? "BM1" : "", i == 0 ? "1000.000" : "");
        hsv.addView(levelTable);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Punto");
        add.setOnClickListener(v -> addLevelRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular cotas");
        calc.setOnClickListener(v -> calculateLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);
        levelCheckResult = resultBox("Verificación pendiente");
        box.addView(levelCheckResult);
        return box;
    }


    private View stadiaLevelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("6. Nivelación con tres hilos"));
        box.addView(small("Cuadro básico: tipo de vista, hilo inferior, hilo medio e hilo superior. Puedes agregar más filas con +."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        stadiaTable = new TableLayout(this);
        stadiaTable.setStretchAllColumns(false);
        stadiaTable.addView(headerRow("P.V.", "TIPO", "H. INF.", "H. MEDIO", "H. SUP.", "DIST.", "COTA TERRENO", "COTA NIVEL"));
        int stadiaCount = Math.max(10, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_stadia_count", 10));
        for (int i = 0; i < stadiaCount; i++) addStadiaRow(i == 0 ? "BM1" : "", i == 0 ? "A" : "");
        hsv.addView(stadiaTable);
        box.addView(hsv);

        box.addView(small("Tipo: A = vista atrás, I = vista intermedia, D = vista adelante. La distancia se calcula con (H. superior - H. inferior) × 100."));

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Fila");
        add.setOnClickListener(v -> addStadiaRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular hilos");
        calc.setOnClickListener(v -> calculateStadiaLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);
        stadiaCheckResult = resultBox("Verificación pendiente");
        box.addView(stadiaCheckResult);
        return box;
    }

    private void addCoordRow() {
        TableDataRow row = new TableDataRow();
        TableRow tr = new TableRow(this);
        row.est = cellEdit("", false);
        row.pv = cellEdit("", false);
        row.az = cellEdit("", false);
        row.dist = cellEdit("", true);
        row.rumbo = cellText("—");
        row.sen = cellText("—");
        row.cos = cellText("—");
        row.este = cellText("—");
        row.oeste = cellText("—");
        row.norte = cellText("—");
        row.sur = cellText("—");
        row.eCorr = cellText("—");
        row.wCorr = cellText("—");
        row.nCorr = cellText("—");
        row.sCorr = cellText("—");
        row.x = cellText("—");
        row.y = cellText("—");
        tr.addView(row.est); tr.addView(row.pv); tr.addView(row.az); tr.addView(row.dist);
        tr.addView(row.rumbo); tr.addView(row.este); tr.addView(row.oeste); tr.addView(row.norte); tr.addView(row.sur);
        tr.addView(row.eCorr); tr.addView(row.wCorr); tr.addView(row.nCorr); tr.addView(row.sCorr); tr.addView(row.x); tr.addView(row.y);
        coordTable.addView(tr);
        tableRows.add(row);
    }

    private void addLevelRow(String label, String cotaDefault) {
        LevelDataRow row = new LevelDataRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEdit(label, false);
        row.vAtras = cellEdit("", true);
        row.vIntermedia = cellEdit("", true);
        row.vAdelante = cellEdit("", true);
        row.cotaTerreno = cellEdit(cotaDefault, true);
        row.cotaNivel = cellText("—");
        tr.addView(row.pv); tr.addView(row.vAtras); tr.addView(row.vIntermedia); tr.addView(row.vAdelante); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        levelTable.addView(tr);
        levelRows.add(row);
    }

    private void addStadiaRow(String label, String tipoDefault) {
        StadiaLevelRow row = new StadiaLevelRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEdit(label, false);
        row.tipo = cellEdit(tipoDefault, false);
        row.hInf = cellEdit("", true);
        row.hMedio = cellEdit("", true);
        row.hSup = cellEdit("", true);
        row.distancia = cellText("—");
        row.cotaTerreno = cellEdit("", true);
        row.cotaNivel = cellText("—");
        tr.addView(row.pv); tr.addView(row.tipo); tr.addView(row.hInf); tr.addView(row.hMedio); tr.addView(row.hSup); tr.addView(row.distancia); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        stadiaTable.addView(tr);
        stadiaRows.add(row);
    }

    private void calculateStadiaLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (StadiaLevelRow row : stadiaRows) {
            String pv = row.pv.getText().toString().trim();
            String tipoText = row.tipo.getText().toString().trim();
            Double hInf = optNumber(row.hInf.getText().toString());
            Double hMedio = optNumber(row.hMedio.getText().toString());
            Double hSup = optNumber(row.hSup.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && tipoText.isEmpty() && hInf == null && hMedio == null && hSup == null && cota == null;
            if (empty) {
                row.distancia.setText("—");
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (hInf != null && hSup != null) {
                    double dist = (hSup - hInf) * 100.0;
                    if (dist < 0) throw new IllegalArgumentException("bad stadia order");
                    row.distancia.setText(f3(dist));
                } else {
                    row.distancia.setText("");
                }

                if (hMedio == null) throw new IllegalArgumentException("missing middle hair");

                int tipo = parseViewType(tipoText, cota != null, currentHI);
                if (tipo == 1) {
                    if (cota == null && lastCota != null) cota = lastCota;
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    row.cotaTerreno.setText(f3(cota));
                    currentHI = cota + hMedio;
                    sumBack += hMedio;
                    row.cotaNivel.setText(f3(currentHI));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                } else {
                    if (Double.isNaN(currentHI)) throw new IllegalArgumentException("no HI");
                    cota = currentHI - hMedio;
                    row.cotaTerreno.setText(f3(cota));
                    row.cotaNivel.setText("");
                    if (tipo == 3) sumForesight += hMedio;
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                calculated++;
            } catch (Exception e) {
                row.distancia.setText(row.distancia.getText().toString().equals("—") ? "ERROR" : row.distancia.getText().toString());
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Fórmula distancia: (H. superior - H. inferior) × 100\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);

        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣA - ΣD: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }

        stadiaCheckResult.setText(check);
        Toast.makeText(this, "Nivelación con hilos calculada", Toast.LENGTH_SHORT).show();
    }

    private int parseViewType(String tipoText, boolean hasKnownCota, double currentHI) {
        String t = tipoText.trim().toUpperCase(Locale.US);
        t = t.replace("Á", "A");
        if (t.isEmpty()) {
            if (Double.isNaN(currentHI) || hasKnownCota) return 1;
            return 2;
        }
        if (t.equals("A") || t.equals("VA") || t.contains("ATRAS")) return 1;
        if (t.equals("I") || t.equals("VI") || t.contains("INTER")) return 2;
        if (t.equals("D") || t.equals("F") || t.equals("FS") || t.equals("VAD") || t.contains("ADEL")) return 3;
        throw new IllegalArgumentException("bad view type");
    }


    private void calculateDistanceData() {
        try {
            Double dh = optNumber(dhInput.getText().toString());
            Double di = optNumber(diInput.getText().toString());
            Double angle = optAngle(angleInput.getText().toString());
            Double dn = optNumber(desnivelInput.getText().toString());

            double horizontal;
            double inclinada;
            double desnivel;
            double angulo;

            if (dh != null && dn != null) {
                horizontal = dh;
                desnivel = dn;
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
                angulo = Math.toDegrees(Math.atan2(desnivel, horizontal));
            } else if (di != null && angle != null) {
                inclinada = di;
                angulo = angle;
                horizontal = inclinada * Math.cos(Math.toRadians(angulo));
                desnivel = inclinada * Math.sin(Math.toRadians(angulo));
            } else if (dh != null && angle != null) {
                horizontal = dh;
                angulo = angle;
                desnivel = horizontal * Math.tan(Math.toRadians(angulo));
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
            } else if (di != null && dn != null) {
                inclinada = di;
                desnivel = dn;
                double inside = inclinada * inclinada - desnivel * desnivel;
                if (inside < 0) throw new IllegalArgumentException("invalid");
                horizontal = Math.sqrt(inside);
                angulo = Math.toDegrees(Math.asin(desnivel / inclinada));
            } else {
                showError("Faltan datos. Usa DH + desnivel, DI + ángulo, DH + ángulo, o DI + desnivel.");
                return;
            }

            if (Math.abs(horizontal) < 0.0000001) throw new IllegalArgumentException("zero horizontal");
            double pendiente = (desnivel / horizontal) * 100.0;

            distanceCalcResult.setText("Distancia horizontal: " + f3(horizontal) + "\n"
                    + "Distancia inclinada: " + f3(inclinada) + "\n"
                    + "Desnivel: " + f3(desnivel) + "\n"
                    + "Ángulo vertical: " + formatDms(angulo) + "\n"
                    + "Pendiente: " + f3(pendiente) + " %");
        } catch (Exception e) {
            showError("Revisa los datos. Ejemplo: DH 100 y desnivel 5, o DI 100 y ángulo 3°00'00\".");
        }
    }

    private void calculateLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (LevelDataRow row : levelRows) {
            String pv = row.pv.getText().toString().trim();
            Double va = optNumber(row.vAtras.getText().toString());
            Double vi = optNumber(row.vIntermedia.getText().toString());
            Double vad = optNumber(row.vAdelante.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && va == null && vi == null && vad == null && cota == null;
            if (empty) {
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (cota == null && !Double.isNaN(currentHI)) {
                    if (vi != null) cota = currentHI - vi;
                    else if (vad != null) cota = currentHI - vad;
                }

                if (cota != null) {
                    row.cotaTerreno.setText(f3(cota));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                if (vad != null) sumForesight += vad;
                if (va != null) {
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    sumBack += va;
                    currentHI = cota + va;
                    row.cotaNivel.setText(f3(currentHI));
                } else {
                    row.cotaNivel.setText(vi != null || vad != null ? "" : "—");
                }
                calculated++;
            } catch (Exception e) {
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);
        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣVA - ΣVAdelante: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }
        levelCheckResult.setText(check);
        Toast.makeText(this, "Nivelación calculada", Toast.LENGTH_SHORT).show();
    }

    private void calculateAzimuth() {
        try {
            String raw = azInput.getText().toString().trim();
            double az;
            if (azInputMode == 0) {
                az = normalize(parseAngle(raw));
            } else if (azInputMode == 1) {
                az = normalize(parseRumbo(raw));
            } else if (azInputMode == 2) {
                double contraAz = normalize(parseAngle(raw));
                az = contraAzimuth(contraAz);
            } else {
                double contraAz = normalize(parseRumbo(raw));
                az = contraAzimuth(contraAz);
            }
            double contra = contraAzimuth(az);
            if (compassAzView != null) compassAzView.setAzimuth(az);
            if (compassRumboView != null) compassRumboView.setAzimuth(az);
            if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
            if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
            if (compassAzLabel != null) compassAzLabel.setText("AZIMUT\n" + formatDms(az));
            if (compassRumboLabel != null) compassRumboLabel.setText("RUMBO\n" + rumbo(az));
            if (compassContraAzLabel != null) compassContraAzLabel.setText("CONTRAAZIMUT\n" + formatDms(contra));
            if (compassContraRumboLabel != null) compassContraRumboLabel.setText("CONTRARUMBO\n" + rumbo(contra));
            compassCaption.setText("Cuadrante: " + quadrantLabel(az));
        } catch (Exception e) {
            if (azInputMode == 0 || azInputMode == 2) {
                showError("Revisa el dato angular. Ejemplo correcto: 150°00'00\"");
            } else {
                showError("Revisa el rumbo. Ejemplo correcto: N 30°00'00\" W");
            }
        }
    }

    private void calculateCoordinateSingle() {
        try {
            double az = normalize(parseAngle(coordAzInput.getText().toString()));
            double distance = parseNumber(distanceInput.getText().toString());
            CoordinateResult r = coordinateResult(az, distance);
            coordResult.setText(coordinateOutput(az, distance, r));
        } catch (Exception e) {
            showError("Revisa azimut y distancia. Ejemplo: azimut 326°30'00\" y distancia 75.00");
        }
    }

    private void calculateTable() {
        ArrayList<TableDataRow> validRows = new ArrayList<>();
        ArrayList<Double> distances = new ArrayList<>();
        ArrayList<Double> dxs = new ArrayList<>();
        ArrayList<Double> dys = new ArrayList<>();
        double sumDx = 0;
        double sumDy = 0;
        double perimeter = 0;
        int ok = 0;

        for (TableDataRow row : tableRows) {
            String azText = row.az.getText().toString().trim();
            String distText = row.dist.getText().toString().trim();
            String estText = row.est.getText().toString().trim();
            String pvText = row.pv.getText().toString().trim();
            if (azText.isEmpty() && distText.isEmpty() && estText.isEmpty() && pvText.isEmpty()) {
                blankPolyRow(row);
                continue;
            }
            try {
                double az = normalize(parseAngle(azText));
                row.rumbo.setText(rumbo(az));
                if (distText.isEmpty()) {
                    blankPolyNumbers(row);
                    continue;
                }
                double distance = parseNumber(distText);
                CoordinateResult r = coordinateResult(az, distance);
                row.sen.setText(f6(r.sen));
                row.cos.setText(f6(r.cos));
                setDirection(row.este, row.oeste, r.dx);
                setDirection(row.norte, row.sur, r.dy);
                validRows.add(row);
                distances.add(distance);
                dxs.add(r.dx);
                dys.add(r.dy);
                sumDx += r.dx;
                sumDy += r.dy;
                perimeter += Math.abs(distance);
                ok++;
            } catch (Exception e) {
                row.rumbo.setText("ERROR");
                blankPolyNumbers(row);
            }
        }

        if (validRows.isEmpty() || perimeter == 0) {
            if (polyCheckResult != null) polyCheckResult.setText("Agrega azimut y distancia para calcular la poligonal.");
            Toast.makeText(this, "No hay filas válidas", Toast.LENGTH_SHORT).show();
            return;
        }

        double x = optNumber(polyX0Input.getText().toString()) != null ? optNumber(polyX0Input.getText().toString()) : 0;
        double y = optNumber(polyY0Input.getText().toString()) != null ? optNumber(polyY0Input.getText().toString()) : 0;
        double startX = x;
        double startY = y;

        for (int i = 0; i < validRows.size(); i++) {
            TableDataRow row = validRows.get(i);
            double distance = distances.get(i);
            double corrX = -sumDx * (Math.abs(distance) / perimeter);
            double corrY = -sumDy * (Math.abs(distance) / perimeter);
            double cdx = dxs.get(i) + corrX;
            double cdy = dys.get(i) + corrY;
            setDirection(row.eCorr, row.wCorr, cdx);
            setDirection(row.nCorr, row.sCorr, cdy);
            x += cdx;
            y += cdy;
            row.x.setText(f3(x));
            row.y.setText(f3(y));
        }

        double closeError = Math.sqrt(sumDx * sumDx + sumDy * sumDy);
        double precision = closeError == 0 ? 0 : perimeter / closeError;
        String check = "Filas calculadas: " + ok
                + "\nPerímetro: " + f3(perimeter)
                + "\nError X: " + f3(sumDx)
                + "\nError Y: " + f3(sumDy)
                + "\nError de cierre: " + f3(closeError)
                + "\nPrecisión aprox.: 1/" + (precision == 0 ? "∞" : String.format(Locale.US, "%.0f", precision))
                + "\nInicio: X " + f3(startX) + "  Y " + f3(startY)
                + "\nFinal corregido: X " + f3(x) + "  Y " + f3(y);
        if (polyCheckResult != null) polyCheckResult.setText(check);
        Toast.makeText(this, "Poligonal calculada: " + ok + " lados", Toast.LENGTH_SHORT).show();
    }

    private void setDirection(TextView positive, TextView negative, double value) {
        double v = cleanZero(value);
        if (v > 0) {
            positive.setText(f3(v));
            negative.setText("");
        } else if (v < 0) {
            positive.setText("");
            negative.setText(f3(-v));
        } else {
            positive.setText("0.000");
            negative.setText("");
        }
    }

    private void blankPolyRow(TableDataRow row) {
        row.rumbo.setText("—");
        blankPolyNumbers(row);
    }

    private void blankPolyNumbers(TableDataRow row) {
        row.sen.setText("—"); row.cos.setText("—");
        row.este.setText("—"); row.oeste.setText("—"); row.norte.setText("—"); row.sur.setText("—");
        row.eCorr.setText("—"); row.wCorr.setText("—"); row.nCorr.setText("—"); row.sCorr.setText("—");
        row.x.setText("—"); row.y.setText("—");
    }

    private CoordinateResult coordinateResult(double az, double distance) {
        double rad = Math.toRadians(az);
        double sen = Math.sin(rad);
        double cos = Math.cos(rad);
        double dx = distance * sen;
        double dy = distance * cos;
        CoordinateResult r = new CoordinateResult();
        r.sen = sen;
        r.cos = cos;
        r.dx = dx;
        r.dy = dy;
        r.este = dx > 0 ? dx : 0;
        r.oeste = dx < 0 ? -dx : 0;
        r.norte = dy > 0 ? dy : 0;
        r.sur = dy < 0 ? -dy : 0;
        return r;
    }

    private String coordinateOutput(double az, double distance, CoordinateResult r) {
        return "Azimut: " + formatDms(az) + "\n"
                + "Rumbo: " + rumbo(az) + "\n"
                + "Distancia: " + f3(distance) + "\n"
                + "Seno: " + f6(r.sen) + "\n"
                + "Coseno: " + f6(r.cos) + "\n"
                + "ΔX = D × sen(Az): " + f3(r.dx) + "\n"
                + "ΔY = D × cos(Az): " + f3(r.dy) + "\n"
                + "Este: " + f3(r.este) + "   Oeste: " + f3(r.oeste) + "\n"
                + "Norte: " + f3(r.norte) + "   Sur: " + f3(r.sur);
    }

    private double parseAngle(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");

        Matcher m = Pattern.compile("-?\\d+(?:\\.\\d+)?").matcher(s);
        ArrayList<Double> nums = new ArrayList<>();
        while (m.find()) nums.add(Double.parseDouble(m.group()));
        if (nums.isEmpty()) throw new IllegalArgumentException("no number");

        double deg = nums.get(0);
        double sign = deg < 0 ? -1 : 1;
        deg = Math.abs(deg);
        double min = nums.size() > 1 ? Math.abs(nums.get(1)) : 0;
        double sec = nums.size() > 2 ? Math.abs(nums.get(2)) : 0;

        if (nums.size() == 1 && !s.contains("°") && !s.contains("º") && !s.contains("'") && !s.contains("\"") && !s.contains(" ")) {
            String clean = s.startsWith("-") ? s.substring(1) : s;
            if (clean.matches("\\d+\\.\\d{2}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1]);
                if (mm < 60) return sign * (d + mm / 60.0);
            }
            if (clean.matches("\\d+\\.\\d{4}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1].substring(0, 2));
                double ss = Double.parseDouble(parts[1].substring(2, 4));
                if (mm < 60 && ss < 60) return sign * (d + mm / 60.0 + ss / 3600.0);
            }
            return nums.get(0);
        }
        return sign * (deg + min / 60.0 + sec / 3600.0);
    }

    private Double optNumber(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseNumber(s);
    }

    private Double optAngle(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseAngle(s);
    }

    private double parseRumbo(String value) {
        String s = value.trim().toUpperCase(Locale.US).replace("º", "°").replace("O", "W");
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        s = s.replaceAll("\\s+", " ").trim();
        char first = 0;
        char last = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 'N' || c == 'S') { first = c; break; }
        }
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == 'E' || c == 'W') { last = c; break; }
        }
        if (first == 0 || last == 0) throw new IllegalArgumentException("bad rumbo");
        int i1 = s.indexOf(first);
        int i2 = s.lastIndexOf(last);
        if (i2 <= i1) throw new IllegalArgumentException("bad rumbo");
        String middle = s.substring(i1 + 1, i2).trim();
        double ang = parseAngle(middle);
        if (ang < 0 || ang > 90) throw new IllegalArgumentException("angle out of range");
        if (first == 'N' && last == 'E') return ang;
        if (first == 'S' && last == 'E') return 180.0 - ang;
        if (first == 'S' && last == 'W') return 180.0 + ang;
        return 360.0 - ang;
    }

    private double parseNumber(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        return Double.parseDouble(s);
    }

    private double normalize(double angle) {
        double a = angle % 360.0;
        if (a < 0) a += 360.0;
        if (Math.abs(a - 360.0) < 0.0000001) a = 0;
        return a;
    }

    private double contraAzimuth(double az) {
        return normalize(az + 180.0);
    }

    private String rumbo(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N";
        if (near(a, 90)) return "E";
        if (near(a, 180)) return "S";
        if (near(a, 270)) return "W";
        if (a > 0 && a < 90) return "N " + formatDms(a) + " E";
        if (a > 90 && a < 180) return "S " + formatDms(180 - a) + " E";
        if (a > 180 && a < 270) return "S " + formatDms(a - 180) + " W";
        return "N " + formatDms(360 - a) + " W";
    }

    private String quadrantLabel(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 90) || near(a, 180) || near(a, 270) || near(a, 360)) {
            return "Eje cardinal";
        }
        if (a > 0 && a < 90) return "NE";
        if (a > 90 && a < 180) return "SE";
        if (a > 180 && a < 270) return "SW";
        return "NW";
    }

    private boolean near(double a, double b) {
        return Math.abs(a - b) < 0.0000001;
    }

    private String formatDms(double angle) {
        double a = Math.abs(angle);
        int deg = (int) Math.floor(a);
        double minFloat = (a - deg) * 60.0;
        int min = (int) Math.floor(minFloat);
        double secFloat = (minFloat - min) * 60.0;
        int sec = (int) Math.round(secFloat);
        if (sec == 60) { sec = 0; min++; }
        if (min == 60) { min = 0; deg++; }
        return String.format(Locale.US, "%02d°%02d'%02d\"", deg, min, sec);
    }

    private String f3(double v) {
        return String.format(Locale.US, "%.3f", cleanZero(v));
    }

    private String f6(double v) {
        return String.format(Locale.US, "%.6f", cleanZero(v));
    }

    private double cleanZero(double v) {
        return Math.abs(v) < 0.0000000001 ? 0 : v;
    }

    private void showError(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cardColor);
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(2), borderColor);
        box.setBackground(gd);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = tv(text, 20, true);
        v.setPadding(0, 0, 0, dp(8));
        return v;
    }

    private TextView small(String text) {
        TextView v = tv(text, 13, false);
        v.setTextColor(subTextColor);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    private TextView smallCenter(String text) {
        TextView v = small(text);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(2), 0, 0);
        return v;
    }

    private TextView tv(String text, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        e.setLayoutParams(lp);
        e.setBackground(inputBg(false));
        return e;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        b.setBackground(gd);
        return b;
    }

    private TextView resultBox(String text) {
        TextView v = tv(text, 15, false);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setBackground(inputBg(true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(10), 0, 0);
        v.setLayoutParams(lp);
        return v;
    }

    private GradientDrawable inputBg(boolean result) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(result ? resultFillColor : inputFillColor);
        gd.setCornerRadius(dp(9));
        gd.setStroke(dp(1), result ? resultStrokeColor : inputStrokeColor);
        return gd;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private TableRow headerRow(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellText(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEdit(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(13);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(6), dp(3), dp(6), dp(3));
        e.setMinWidth(dp(96));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(7), dp(6), dp(7));
        v.setMinWidth(dp(96));
        v.setBackground(cellBg(true));
        return v;
    }

    private GradientDrawable cellBg(boolean locked) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(locked ? cellLockedColor : cellEditColor);
        gd.setStroke(1, tableLineColor);
        return gd;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private static class CoordinateResult {
        double sen;
        double cos;
        double dx;
        double dy;
        double este;
        double oeste;
        double norte;
        double sur;
    }

    private static class TableDataRow {
        EditText est;
        EditText pv;
        EditText az;
        EditText dist;
        TextView rumbo;
        TextView sen;
        TextView cos;
        TextView este;
        TextView oeste;
        TextView norte;
        TextView sur;
        TextView eCorr;
        TextView wCorr;
        TextView nCorr;
        TextView sCorr;
        TextView x;
        TextView y;
    }

    private static class LevelDataRow {
        EditText pv;
        EditText vAtras;
        EditText vIntermedia;
        EditText vAdelante;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class StadiaLevelRow {
        EditText pv;
        EditText tipo;
        EditText hInf;
        EditText hMedio;
        EditText hSup;
        TextView distancia;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    public static class ZoomLayout extends FrameLayout {
        private final ScaleGestureDetector detector;
        private float scale = 1.0f;

        public ZoomLayout(Context context) {
            super(context);
            detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    scale *= d.getScaleFactor();
                    scale = Math.max(0.80f, Math.min(scale, 3.00f));
                    setScaleX(scale);
                    setScaleY(scale);
                    setPivotX(0);
                    setPivotY(0);
                    return true;
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            detector.onTouchEvent(event);
            return true;
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            detector.onTouchEvent(ev);
            return super.dispatchTouchEvent(ev);
        }

        public void resetZoom() {
            scale = 1.0f;
            setScaleX(scale);
            setScaleY(scale);
        }
    }

    public class CompassView extends View {
        private final Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private double azimuth;

        public CompassView(Context context) {
            super(context);
            circlePaint.setStyle(Paint.Style.STROKE);
            circlePaint.setStrokeWidth(dp(2));
            circlePaint.setColor(compassRingColor);

            crossPaint.setStyle(Paint.Style.STROKE);
            crossPaint.setStrokeWidth(dp(1));
            crossPaint.setColor(subTextColor);

            textPaint.setColor(textColor);
            textPaint.setTextSize(dp(12));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(Paint.Align.CENTER);

            arrowPaint.setStyle(Paint.Style.STROKE);
            arrowPaint.setStrokeWidth(dp(3));
            arrowPaint.setStrokeCap(Paint.Cap.ROUND);
            arrowPaint.setStrokeJoin(Paint.Join.ROUND);
            arrowPaint.setColor(compassArrowColor);
        }

        public void setAzimuth(double azimuth) {
            this.azimuth = azimuth;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) * 0.34f;

            Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(250, 252, 255) : Color.rgb(13, 18, 28));
            canvas.drawCircle(cx, cy, r, fillPaint);
            canvas.drawCircle(cx, cy, r, circlePaint);
            for (int i = 0; i < 36; i++) {
                double rr = Math.toRadians(i * 10 - 90);
                float outerX = (float) (cx + Math.cos(rr) * r);
                float outerY = (float) (cy + Math.sin(rr) * r);
                float innerFactor = (i % 9 == 0) ? 0.84f : 0.90f;
                float innerX = (float) (cx + Math.cos(rr) * r * innerFactor);
                float innerY = (float) (cy + Math.sin(rr) * r * innerFactor);
                canvas.drawLine(innerX, innerY, outerX, outerY, crossPaint);
            }
            canvas.drawLine(cx, cy - r, cx, cy + r, crossPaint);
            canvas.drawLine(cx - r, cy, cx + r, cy, crossPaint);

            canvas.drawText("N", cx, cy - r - dp(10), textPaint);
            canvas.drawText("S", cx, cy + r + dp(18), textPaint);
            canvas.drawText("E", cx + r + dp(16), cy + dp(4), textPaint);
            canvas.drawText("W", cx - r - dp(16), cy + dp(4), textPaint);

            double rad = Math.toRadians(azimuth - 90.0);
            float tipX = (float) (cx + Math.cos(rad) * r * 0.92f);
            float tipY = (float) (cy + Math.sin(rad) * r * 0.92f);
            float backX = (float) (cx - Math.cos(rad) * r * 0.20f);
            float backY = (float) (cy - Math.sin(rad) * r * 0.20f);
            canvas.drawLine(backX, backY, tipX, tipY, arrowPaint);

            double leftRad = rad + Math.toRadians(150);
            double rightRad = rad - Math.toRadians(150);
            float side = r * 0.18f;
            canvas.drawLine(tipX, tipY, (float) (tipX + Math.cos(leftRad) * side), (float) (tipY + Math.sin(leftRad) * side), arrowPaint);
            canvas.drawLine(tipX, tipY, (float) (tipX + Math.cos(rightRad) * side), (float) (tipY + Math.sin(rightRad) * side), arrowPaint);

            Paint centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            centerPaint.setColor(compassArrowColor);
            canvas.drawCircle(cx, cy, dp(4), centerPaint);

            // Texto inferior del círculo se muestra fuera del dibujo, en cada tarjeta.
        }
    }
}
