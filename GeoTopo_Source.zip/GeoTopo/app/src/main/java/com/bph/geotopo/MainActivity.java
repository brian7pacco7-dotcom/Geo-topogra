package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;

    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 184, 148),
            Color.rgb(255, 171, 0),
            Color.rgb(142, 68, 173),
            Color.rgb(231, 76, 60)
    };

    private int themeMode;
    private int accentIndex;

    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;
    private int cellEditColor;
    private int cellLockedColor;
    private int tableLineColor;

    private ZoomLayout zoomLayout;

    private EditText azInput;
    private TextView azResult;
    private TextView compassCaption;
    private CompassView compassView;

    private EditText coordAzInput;
    private EditText distanceInput;
    private TextView coordResult;

    private EditText dhInput;
    private EditText diInput;
    private EditText angleInput;
    private EditText desnivelInput;
    private TextView distanceCalcResult;

    private TextView levelCheckResult;
    private TextView stadiaCheckResult;

    private final List<TableDataRow> tableRows = new ArrayList<>();
    private final List<LevelDataRow> levelRows = new ArrayList<>();
    private final List<StadiaLevelRow> stadiaRows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        buildUi();
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        accentIndex = sp.getInt("accent", 0);
    }

    private void savePrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("theme", themeMode)
                .putInt("accent", accentIndex)
                .apply();
    }

    private void applyPalette() {
        borderColor = ACCENTS[accentIndex % ACCENTS.length];

        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputFillColor = Color.WHITE;
            inputStrokeColor = Color.rgb(178, 184, 196);
            resultFillColor = Color.rgb(245, 252, 248);
            resultStrokeColor = Color.rgb(29, 185, 84);
            cellEditColor = Color.rgb(252, 253, 255);
            cellLockedColor = Color.rgb(244, 246, 250);
            tableLineColor = Color.rgb(190, 196, 206);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(12, 18, 28);
            cellLockedColor = Color.rgb(21, 23, 28);
            tableLineColor = Color.rgb(74, 78, 88);
        } else {
            bgColor = Color.rgb(13, 18, 28);
            appBarColor = Color.rgb(6, 38, 63);
            cardColor = Color.rgb(22, 29, 40);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(184, 190, 198);
            inputFillColor = Color.rgb(15, 21, 31);
            inputStrokeColor = Color.rgb(85, 92, 104);
            resultFillColor = Color.rgb(13, 42, 30);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(11, 25, 41);
            cellLockedColor = Color.rgb(25, 31, 42);
            tableLineColor = Color.rgb(78, 84, 96);
        }
    }

    private void buildUi() {
        applyPalette();
        tableRows.clear();
        levelRows.clear();
        stadiaRows.clear();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        zoomLayout = new ZoomLayout(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        content.addView(azimuthBlock());
        content.addView(coordBlock());
        content.addView(distanceBlock());
        content.addView(partialTableBlock());
        content.addView(levelingBlock());
        content.addView(stadiaLevelingBlock());

        zoomLayout.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        scroll.addView(zoomLayout);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));
        setContentView(root);
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(14), dp(14), dp(14));
        bar.setBackgroundColor(appBarColor);

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleWrap.setLayoutParams(titleParams);

        TextView title = new TextView(this);
        title.setText("Geo Topografía");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleWrap.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Cálculos topográficos");
        sub.setTextColor(Color.rgb(193, 218, 240));
        sub.setTextSize(13);
        titleWrap.addView(sub);
        bar.addView(titleWrap);

        Button settings = new Button(this);
        settings.setText("Ajustes");
        settings.setAllCaps(false);
        settings.setTextColor(Color.WHITE);
        settings.setTextSize(14);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        settings.setBackground(gd);
        settings.setPadding(dp(14), dp(8), dp(14), dp(8));
        settings.setOnClickListener(v -> showSettingsDialog());
        bar.addView(settings);

        return bar;
    }

    private void showSettingsDialog() {
        String[] items = {"Tema", "Color de cuadros", "Reset zoom"};
        new AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) showThemeDialog();
                    if (which == 1) showAccentDialog();
                    if (which == 2 && zoomLayout != null) zoomLayout.resetZoom();
                })
                .show();
    }

    private void showThemeDialog() {
        String[] items = {"Tema claro", "Tema oscuro", "Tema negro"};
        new AlertDialog.Builder(this)
                .setTitle("Apariencia")
                .setSingleChoiceItems(items, themeMode, (dialog, which) -> themeMode = which)
                .setPositiveButton("Aplicar", (dialog, which) -> {
                    savePrefs();
                    buildUi();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showAccentDialog() {
        String[] items = {"Azul", "Verde", "Ámbar", "Morado", "Rojo"};
        new AlertDialog.Builder(this)
                .setTitle("Color de cuadros")
                .setSingleChoiceItems(items, accentIndex, (dialog, which) -> accentIndex = which)
                .setPositiveButton("Aplicar", (dialog, which) -> {
                    savePrefs();
                    buildUi();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private View azimuthBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("1. Azimut a rumbo"));
        box.addView(small("Escribe el azimut y la app te devuelve rumbo, contraazimut y contrarumbo."));

        azInput = edit("Ejemplo: 150°00'00\"");
        box.addView(azInput);

        Button calc = btn("Calcular");
        calc.setOnClickListener(v -> calculateAzimuth());
        box.addView(calc);

        compassView = new CompassView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220));
        cp.setMargins(0, dp(12), 0, dp(6));
        compassView.setLayoutParams(cp);
        box.addView(compassView);

        compassCaption = smallCenter("Vista de referencia");
        box.addView(compassCaption);

        azResult = resultBox("Resultado pendiente");
        box.addView(azResult);
        return box;
    }

    private View coordBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("2. Distancia y coordenadas parciales"));
        box.addView(small("Ingresa azimut y distancia horizontal para obtener seno, coseno, ΔX, ΔY y E/O/N/S."));

        coordAzInput = edit("Azimut");
        distanceInput = edit("Distancia horizontal");
        distanceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(coordAzInput);
        box.addView(distanceInput);

        Button calc = btn("Calcular E/O/N/S");
        calc.setOnClickListener(v -> calculateCoordinateSingle());
        box.addView(calc);

        coordResult = resultBox("Resultado pendiente");
        box.addView(coordResult);
        return box;
    }

    private View distanceBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("3. Distancia, desnivel y pendiente"));
        box.addView(small("Completa dos datos mínimos. Ejemplos: distancia horizontal + desnivel, o distancia inclinada + ángulo vertical."));

        dhInput = edit("Distancia horizontal");
        diInput = edit("Distancia inclinada");
        angleInput = edit("Ángulo vertical");
        desnivelInput = edit("Desnivel / diferencia de cota");

        dhInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        diInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        desnivelInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(dhInput);
        box.addView(diInput);
        box.addView(angleInput);
        box.addView(desnivelInput);

        Button calc = btn("Calcular distancia");
        calc.setOnClickListener(v -> calculateDistanceData());
        box.addView(calc);

        distanceCalcResult = resultBox("Resultado pendiente");
        box.addView(distanceCalcResult);
        return box;
    }

    private View partialTableBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("4. Cuadro de coordenadas parciales"));
        box.addView(small("Completa estación, punto visado, azimut y distancia. Luego toca Calcular tabla."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(false);
        table.addView(headerRow("EST.", "P.V.", "AZIMUT", "DIST.", "RUMBO", "SEN", "COS", "ESTE", "OESTE", "NORTE", "SUR"));

        for (int i = 0; i < 6; i++) {
            TableDataRow row = new TableDataRow();
            TableRow tr = new TableRow(this);
            row.est = cellEdit("", false);
            row.pv = cellEdit("", false);
            row.az = cellEdit("", false);
            row.dist = cellEdit("", true);
            row.rumbo = cellText("—");
            row.sen = cellText("—");
            row.cos = cellText("—");
            row.este = cellText("—");
            row.oeste = cellText("—");
            row.norte = cellText("—");
            row.sur = cellText("—");
            tr.addView(row.est);
            tr.addView(row.pv);
            tr.addView(row.az);
            tr.addView(row.dist);
            tr.addView(row.rumbo);
            tr.addView(row.sen);
            tr.addView(row.cos);
            tr.addView(row.este);
            tr.addView(row.oeste);
            tr.addView(row.norte);
            tr.addView(row.sur);
            table.addView(tr);
            tableRows.add(row);
        }

        hsv.addView(table);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);

        Button calc = btn("Calcular tabla");
        calc.setOnClickListener(v -> calculateTable());
        rowButtons.addView(calc, weightParams());

        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> buildUi());
        rowButtons.addView(clear, weightParams());

        box.addView(rowButtons);
        return box;
    }

    private View levelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("5. Nivelación: cota terreno y cota nivel"));
        box.addView(small("Llena BM o punto inicial con cota conocida. Usa vista atrás, intermedia y adelante. En puntos de cambio puedes poner vista adelante y vista atrás en la misma fila."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(false);
        table.addView(headerRow("P.V.", "V. ATRÁS (+)", "V. INTERMEDIA (-)", "V. ADELANTE (-)", "COTA TERRENO", "COTA NIVEL"));

        for (int i = 0; i < 16; i++) {
            LevelDataRow row = new LevelDataRow();
            TableRow tr = new TableRow(this);
            row.pv = cellEdit(i == 0 ? "BM1" : "", false);
            row.vAtras = cellEdit("", true);
            row.vIntermedia = cellEdit("", true);
            row.vAdelante = cellEdit("", true);
            row.cotaTerreno = cellEdit("", true);
            row.cotaNivel = cellText("—");
            tr.addView(row.pv);
            tr.addView(row.vAtras);
            tr.addView(row.vIntermedia);
            tr.addView(row.vAdelante);
            tr.addView(row.cotaTerreno);
            tr.addView(row.cotaNivel);
            table.addView(tr);
            levelRows.add(row);
        }

        hsv.addView(table);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);

        Button calc = btn("Calcular cotas");
        calc.setOnClickListener(v -> calculateLeveling());
        rowButtons.addView(calc, weightParams());

        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> buildUi());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);

        levelCheckResult = resultBox("Verificación pendiente");
        box.addView(levelCheckResult);
        return box;
    }


    private View stadiaLevelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("6. Nivelación con tres hilos"));
        box.addView(small("Cuadro básico: coloca tipo de vista, hilo inferior, hilo medio y hilo superior. La distancia se calcula con (H. superior - H. inferior) × 100. El hilo medio se usa para calcular cotas."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(false);
        table.addView(headerRow("P.V.", "TIPO", "H. INF.", "H. MEDIO", "H. SUP.", "DIST.", "COTA TERRENO", "COTA NIVEL"));

        for (int i = 0; i < 14; i++) {
            StadiaLevelRow row = new StadiaLevelRow();
            TableRow tr = new TableRow(this);
            row.pv = cellEdit(i == 0 ? "BM1" : "", false);
            row.tipo = cellEdit(i == 0 ? "A" : "", false);
            row.hInf = cellEdit("", true);
            row.hMedio = cellEdit("", true);
            row.hSup = cellEdit("", true);
            row.distancia = cellText("—");
            row.cotaTerreno = cellEdit("", true);
            row.cotaNivel = cellText("—");

            tr.addView(row.pv);
            tr.addView(row.tipo);
            tr.addView(row.hInf);
            tr.addView(row.hMedio);
            tr.addView(row.hSup);
            tr.addView(row.distancia);
            tr.addView(row.cotaTerreno);
            tr.addView(row.cotaNivel);

            table.addView(tr);
            stadiaRows.add(row);
        }

        hsv.addView(table);
        box.addView(hsv);

        box.addView(small("Tipo: A = vista atrás, I = vista intermedia, D = vista adelante. En el primer punto escribe la cota conocida. En un punto de cambio, usa D y en la siguiente fila A."));

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);

        Button calc = btn("Calcular hilos");
        calc.setOnClickListener(v -> calculateStadiaLeveling());
        rowButtons.addView(calc, weightParams());

        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> buildUi());
        rowButtons.addView(clear, weightParams());

        box.addView(rowButtons);

        stadiaCheckResult = resultBox("Verificación pendiente");
        box.addView(stadiaCheckResult);
        return box;
    }

    private void calculateStadiaLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (StadiaLevelRow row : stadiaRows) {
            String pv = row.pv.getText().toString().trim();
            String tipoText = row.tipo.getText().toString().trim();
            Double hInf = optNumber(row.hInf.getText().toString());
            Double hMedio = optNumber(row.hMedio.getText().toString());
            Double hSup = optNumber(row.hSup.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && tipoText.isEmpty() && hInf == null && hMedio == null && hSup == null && cota == null;
            if (empty) {
                row.distancia.setText("—");
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (hInf != null && hSup != null) {
                    double dist = (hSup - hInf) * 100.0;
                    if (dist < 0) throw new IllegalArgumentException("bad stadia order");
                    row.distancia.setText(f3(dist));
                } else {
                    row.distancia.setText("");
                }

                if (hMedio == null) throw new IllegalArgumentException("missing middle hair");

                int tipo = parseViewType(tipoText, cota != null, currentHI);
                if (tipo == 1) {
                    if (cota == null && lastCota != null) cota = lastCota;
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    row.cotaTerreno.setText(f3(cota));
                    currentHI = cota + hMedio;
                    sumBack += hMedio;
                    row.cotaNivel.setText(f3(currentHI));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                } else {
                    if (Double.isNaN(currentHI)) throw new IllegalArgumentException("no HI");
                    cota = currentHI - hMedio;
                    row.cotaTerreno.setText(f3(cota));
                    row.cotaNivel.setText("");
                    if (tipo == 3) sumForesight += hMedio;
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                calculated++;
            } catch (Exception e) {
                row.distancia.setText(row.distancia.getText().toString().equals("—") ? "ERROR" : row.distancia.getText().toString());
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Fórmula distancia: (H. superior - H. inferior) × 100\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);

        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣA - ΣD: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }

        stadiaCheckResult.setText(check);
        Toast.makeText(this, "Nivelación con hilos calculada", Toast.LENGTH_SHORT).show();
    }

    private int parseViewType(String tipoText, boolean hasKnownCota, double currentHI) {
        String t = tipoText.trim().toUpperCase(Locale.US);
        t = t.replace("Á", "A");
        if (t.isEmpty()) {
            if (Double.isNaN(currentHI) || hasKnownCota) return 1;
            return 2;
        }
        if (t.equals("A") || t.equals("VA") || t.contains("ATRAS")) return 1;
        if (t.equals("I") || t.equals("VI") || t.contains("INTER")) return 2;
        if (t.equals("D") || t.equals("F") || t.equals("FS") || t.equals("VAD") || t.contains("ADEL")) return 3;
        throw new IllegalArgumentException("bad view type");
    }


    private void calculateDistanceData() {
        try {
            Double dh = optNumber(dhInput.getText().toString());
            Double di = optNumber(diInput.getText().toString());
            Double angle = optAngle(angleInput.getText().toString());
            Double dn = optNumber(desnivelInput.getText().toString());

            double horizontal;
            double inclinada;
            double desnivel;
            double angulo;

            if (dh != null && dn != null) {
                horizontal = dh;
                desnivel = dn;
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
                angulo = Math.toDegrees(Math.atan2(desnivel, horizontal));
            } else if (di != null && angle != null) {
                inclinada = di;
                angulo = angle;
                horizontal = inclinada * Math.cos(Math.toRadians(angulo));
                desnivel = inclinada * Math.sin(Math.toRadians(angulo));
            } else if (dh != null && angle != null) {
                horizontal = dh;
                angulo = angle;
                desnivel = horizontal * Math.tan(Math.toRadians(angulo));
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
            } else if (di != null && dn != null) {
                inclinada = di;
                desnivel = dn;
                double inside = inclinada * inclinada - desnivel * desnivel;
                if (inside < 0) throw new IllegalArgumentException("invalid");
                horizontal = Math.sqrt(inside);
                angulo = Math.toDegrees(Math.asin(desnivel / inclinada));
            } else {
                showError("Faltan datos. Usa DH + desnivel, DI + ángulo, DH + ángulo, o DI + desnivel.");
                return;
            }

            if (Math.abs(horizontal) < 0.0000001) throw new IllegalArgumentException("zero horizontal");
            double pendiente = (desnivel / horizontal) * 100.0;

            distanceCalcResult.setText("Distancia horizontal: " + f3(horizontal) + "\n"
                    + "Distancia inclinada: " + f3(inclinada) + "\n"
                    + "Desnivel: " + f3(desnivel) + "\n"
                    + "Ángulo vertical: " + formatDms(angulo) + "\n"
                    + "Pendiente: " + f3(pendiente) + " %");
        } catch (Exception e) {
            showError("Revisa los datos. Ejemplo: DH 100 y desnivel 5, o DI 100 y ángulo 3°00'00\".");
        }
    }

    private void calculateLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (LevelDataRow row : levelRows) {
            String pv = row.pv.getText().toString().trim();
            Double va = optNumber(row.vAtras.getText().toString());
            Double vi = optNumber(row.vIntermedia.getText().toString());
            Double vad = optNumber(row.vAdelante.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && va == null && vi == null && vad == null && cota == null;
            if (empty) {
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (cota == null && !Double.isNaN(currentHI)) {
                    if (vi != null) cota = currentHI - vi;
                    else if (vad != null) cota = currentHI - vad;
                }

                if (cota != null) {
                    row.cotaTerreno.setText(f3(cota));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                if (vad != null) sumForesight += vad;
                if (va != null) {
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    sumBack += va;
                    currentHI = cota + va;
                    row.cotaNivel.setText(f3(currentHI));
                } else {
                    row.cotaNivel.setText(vi != null || vad != null ? "" : "—");
                }
                calculated++;
            } catch (Exception e) {
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);
        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣVA - ΣVAdelante: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }
        levelCheckResult.setText(check);
        Toast.makeText(this, "Nivelación calculada", Toast.LENGTH_SHORT).show();
    }

    private void calculateAzimuth() {
        try {
            double az = normalize(parseAngle(azInput.getText().toString()));
            double contra = contraAzimuth(az);
            compassView.setAzimuth(az);
            compassCaption.setText("Cuadrante: " + quadrantLabel(az) + " · Dirección visual del rumbo");
            String out = "Azimut: " + formatDms(az) + "\n"
                    + "Rumbo: " + rumbo(az) + "\n"
                    + "Contraazimut: " + formatDms(contra) + "\n"
                    + "Contrarumbo: " + rumbo(contra);
            azResult.setText(out);
        } catch (Exception e) {
            showError("Revisa el azimut. Ejemplo correcto: 150°00'00\"");
        }
    }

    private void calculateCoordinateSingle() {
        try {
            double az = normalize(parseAngle(coordAzInput.getText().toString()));
            double distance = parseNumber(distanceInput.getText().toString());
            CoordinateResult r = coordinateResult(az, distance);
            coordResult.setText(coordinateOutput(az, distance, r));
        } catch (Exception e) {
            showError("Revisa azimut y distancia. Ejemplo: azimut 326°30'00\" y distancia 75.00");
        }
    }

    private void calculateTable() {
        int ok = 0;
        for (TableDataRow row : tableRows) {
            String azText = row.az.getText().toString().trim();
            String distText = row.dist.getText().toString().trim();
            String estText = row.est.getText().toString().trim();
            String pvText = row.pv.getText().toString().trim();
            if (azText.isEmpty() && distText.isEmpty() && estText.isEmpty() && pvText.isEmpty()) continue;
            try {
                double az = normalize(parseAngle(azText));
                double distance = parseNumber(distText);
                CoordinateResult r = coordinateResult(az, distance);
                row.rumbo.setText(rumbo(az));
                row.sen.setText(f6(r.sen));
                row.cos.setText(f6(r.cos));
                row.este.setText(r.este > 0 ? f3(r.este) : "");
                row.oeste.setText(r.oeste > 0 ? f3(r.oeste) : "");
                row.norte.setText(r.norte > 0 ? f3(r.norte) : "");
                row.sur.setText(r.sur > 0 ? f3(r.sur) : "");
                ok++;
            } catch (Exception e) {
                row.rumbo.setText("ERROR");
                row.sen.setText("—");
                row.cos.setText("—");
                row.este.setText("—");
                row.oeste.setText("—");
                row.norte.setText("—");
                row.sur.setText("—");
            }
        }
        Toast.makeText(this, "Filas calculadas: " + ok, Toast.LENGTH_SHORT).show();
    }

    private CoordinateResult coordinateResult(double az, double distance) {
        double rad = Math.toRadians(az);
        double sen = Math.sin(rad);
        double cos = Math.cos(rad);
        double dx = distance * sen;
        double dy = distance * cos;
        CoordinateResult r = new CoordinateResult();
        r.sen = sen;
        r.cos = cos;
        r.dx = dx;
        r.dy = dy;
        r.este = dx > 0 ? dx : 0;
        r.oeste = dx < 0 ? -dx : 0;
        r.norte = dy > 0 ? dy : 0;
        r.sur = dy < 0 ? -dy : 0;
        return r;
    }

    private String coordinateOutput(double az, double distance, CoordinateResult r) {
        return "Azimut: " + formatDms(az) + "\n"
                + "Rumbo: " + rumbo(az) + "\n"
                + "Distancia: " + f3(distance) + "\n"
                + "Seno: " + f6(r.sen) + "\n"
                + "Coseno: " + f6(r.cos) + "\n"
                + "ΔX = D × sen(Az): " + f3(r.dx) + "\n"
                + "ΔY = D × cos(Az): " + f3(r.dy) + "\n"
                + "Este: " + f3(r.este) + "   Oeste: " + f3(r.oeste) + "\n"
                + "Norte: " + f3(r.norte) + "   Sur: " + f3(r.sur);
    }

    private double parseAngle(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");

        Matcher m = Pattern.compile("-?\\d+(?:\\.\\d+)?").matcher(s);
        ArrayList<Double> nums = new ArrayList<>();
        while (m.find()) nums.add(Double.parseDouble(m.group()));
        if (nums.isEmpty()) throw new IllegalArgumentException("no number");

        double deg = nums.get(0);
        double sign = deg < 0 ? -1 : 1;
        deg = Math.abs(deg);
        double min = nums.size() > 1 ? Math.abs(nums.get(1)) : 0;
        double sec = nums.size() > 2 ? Math.abs(nums.get(2)) : 0;

        if (nums.size() == 1 && !s.contains("°") && !s.contains("º") && !s.contains("'") && !s.contains("\"") && !s.contains(" ")) {
            String clean = s.startsWith("-") ? s.substring(1) : s;
            if (clean.matches("\\d+\\.\\d{2}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1]);
                if (mm < 60) return sign * (d + mm / 60.0);
            }
            if (clean.matches("\\d+\\.\\d{4}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1].substring(0, 2));
                double ss = Double.parseDouble(parts[1].substring(2, 4));
                if (mm < 60 && ss < 60) return sign * (d + mm / 60.0 + ss / 3600.0);
            }
            return nums.get(0);
        }
        return sign * (deg + min / 60.0 + sec / 3600.0);
    }

    private Double optNumber(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseNumber(s);
    }

    private Double optAngle(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseAngle(s);
    }

    private double parseNumber(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        return Double.parseDouble(s);
    }

    private double normalize(double angle) {
        double a = angle % 360.0;
        if (a < 0) a += 360.0;
        if (Math.abs(a - 360.0) < 0.0000001) a = 0;
        return a;
    }

    private double contraAzimuth(double az) {
        return normalize(az + 180.0);
    }

    private String rumbo(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N";
        if (near(a, 90)) return "E";
        if (near(a, 180)) return "S";
        if (near(a, 270)) return "W";
        if (a > 0 && a < 90) return "N " + formatDms(a) + " E";
        if (a > 90 && a < 180) return "S " + formatDms(180 - a) + " E";
        if (a > 180 && a < 270) return "S " + formatDms(a - 180) + " W";
        return "N " + formatDms(360 - a) + " W";
    }

    private String quadrantLabel(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 90) || near(a, 180) || near(a, 270) || near(a, 360)) {
            return "Eje cardinal";
        }
        if (a > 0 && a < 90) return "NE";
        if (a > 90 && a < 180) return "SE";
        if (a > 180 && a < 270) return "SW";
        return "NW";
    }

    private boolean near(double a, double b) {
        return Math.abs(a - b) < 0.0000001;
    }

    private String formatDms(double angle) {
        double a = Math.abs(angle);
        int deg = (int) Math.floor(a);
        double minFloat = (a - deg) * 60.0;
        int min = (int) Math.floor(minFloat);
        double secFloat = (minFloat - min) * 60.0;
        int sec = (int) Math.round(secFloat);
        if (sec == 60) { sec = 0; min++; }
        if (min == 60) { min = 0; deg++; }
        return String.format(Locale.US, "%02d°%02d'%02d\"", deg, min, sec);
    }

    private String f3(double v) {
        return String.format(Locale.US, "%.3f", cleanZero(v));
    }

    private String f6(double v) {
        return String.format(Locale.US, "%.6f", cleanZero(v));
    }

    private double cleanZero(double v) {
        return Math.abs(v) < 0.0000000001 ? 0 : v;
    }

    private void showError(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cardColor);
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(2), borderColor);
        box.setBackground(gd);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = tv(text, 20, true);
        v.setPadding(0, 0, 0, dp(8));
        return v;
    }

    private TextView small(String text) {
        TextView v = tv(text, 13, false);
        v.setTextColor(subTextColor);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    private TextView smallCenter(String text) {
        TextView v = small(text);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(2), 0, 0);
        return v;
    }

    private TextView tv(String text, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        e.setLayoutParams(lp);
        e.setBackground(inputBg(false));
        return e;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        b.setBackground(gd);
        return b;
    }

    private TextView resultBox(String text) {
        TextView v = tv(text, 15, false);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setBackground(inputBg(true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(10), 0, 0);
        v.setLayoutParams(lp);
        return v;
    }

    private GradientDrawable inputBg(boolean result) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(result ? resultFillColor : inputFillColor);
        gd.setCornerRadius(dp(9));
        gd.setStroke(dp(1), result ? resultStrokeColor : inputStrokeColor);
        return gd;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private TableRow headerRow(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellText(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEdit(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(13);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(6), dp(3), dp(6), dp(3));
        e.setMinWidth(dp(96));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(7), dp(6), dp(7));
        v.setMinWidth(dp(96));
        v.setBackground(cellBg(true));
        return v;
    }

    private GradientDrawable cellBg(boolean locked) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(locked ? cellLockedColor : cellEditColor);
        gd.setStroke(1, tableLineColor);
        return gd;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private static class CoordinateResult {
        double sen;
        double cos;
        double dx;
        double dy;
        double este;
        double oeste;
        double norte;
        double sur;
    }

    private static class TableDataRow {
        EditText est;
        EditText pv;
        EditText az;
        EditText dist;
        TextView rumbo;
        TextView sen;
        TextView cos;
        TextView este;
        TextView oeste;
        TextView norte;
        TextView sur;
    }

    private static class LevelDataRow {
        EditText pv;
        EditText vAtras;
        EditText vIntermedia;
        EditText vAdelante;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class StadiaLevelRow {
        EditText pv;
        EditText tipo;
        EditText hInf;
        EditText hMedio;
        EditText hSup;
        TextView distancia;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    public static class ZoomLayout extends FrameLayout {
        private final ScaleGestureDetector detector;
        private float scale = 1.0f;

        public ZoomLayout(Context context) {
            super(context);
            detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    scale *= d.getScaleFactor();
                    scale = Math.max(0.80f, Math.min(scale, 3.00f));
                    setScaleX(scale);
                    setScaleY(scale);
                    setPivotX(0);
                    setPivotY(0);
                    return true;
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            detector.onTouchEvent(event);
            return true;
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            detector.onTouchEvent(ev);
            return super.dispatchTouchEvent(ev);
        }

        public void resetZoom() {
            scale = 1.0f;
            setScaleX(scale);
            setScaleY(scale);
        }
    }

    public class CompassView extends View {
        private final Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private double azimuth;

        public CompassView(Context context) {
            super(context);
            circlePaint.setStyle(Paint.Style.STROKE);
            circlePaint.setStrokeWidth(dp(2));
            circlePaint.setColor(borderColor);

            crossPaint.setStyle(Paint.Style.STROKE);
            crossPaint.setStrokeWidth(dp(1));
            crossPaint.setColor(subTextColor);

            textPaint.setColor(textColor);
            textPaint.setTextSize(dp(12));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(Paint.Align.CENTER);

            arrowPaint.setStyle(Paint.Style.STROKE);
            arrowPaint.setStrokeWidth(dp(3));
            arrowPaint.setStrokeCap(Paint.Cap.ROUND);
            arrowPaint.setStrokeJoin(Paint.Join.ROUND);
            arrowPaint.setColor(borderColor);
        }

        public void setAzimuth(double azimuth) {
            this.azimuth = azimuth;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) * 0.34f;

            canvas.drawCircle(cx, cy, r, circlePaint);
            canvas.drawLine(cx, cy - r, cx, cy + r, crossPaint);
            canvas.drawLine(cx - r, cy, cx + r, cy, crossPaint);

            canvas.drawText("N", cx, cy - r - dp(10), textPaint);
            canvas.drawText("S", cx, cy + r + dp(18), textPaint);
            canvas.drawText("E", cx + r + dp(16), cy + dp(4), textPaint);
            canvas.drawText("W", cx - r - dp(16), cy + dp(4), textPaint);

            double rad = Math.toRadians(azimuth - 90.0);
            float tipX = (float) (cx + Math.cos(rad) * r * 0.92f);
            float tipY = (float) (cy + Math.sin(rad) * r * 0.92f);
            float backX = (float) (cx - Math.cos(rad) * r * 0.20f);
            float backY = (float) (cy - Math.sin(rad) * r * 0.20f);
            canvas.drawLine(backX, backY, tipX, tipY, arrowPaint);

            double leftRad = rad + Math.toRadians(150);
            double rightRad = rad - Math.toRadians(150);
            float side = r * 0.18f;
            canvas.drawLine(tipX, tipY, (float) (tipX + Math.cos(leftRad) * side), (float) (tipY + Math.sin(leftRad) * side), arrowPaint);
            canvas.drawLine(tipX, tipY, (float) (tipX + Math.cos(rightRad) * side), (float) (tipY + Math.sin(rightRad) * side), arrowPaint);

            Paint centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            centerPaint.setColor(borderColor);
            canvas.drawCircle(cx, cy, dp(4), centerPaint);

            Paint smallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            smallPaint.setColor(subTextColor);
            smallPaint.setTextAlign(Paint.Align.CENTER);
            smallPaint.setTextSize(dp(11));
            canvas.drawText("Azimut: " + formatDms(azimuth), cx, h - dp(16), smallPaint);
        }
    }
}
