package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;

    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };
    private static final int[] COMPASS_ARROW_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(231, 76, 60),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };
    private static final int[] COMPASS_RING_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(231, 76, 60),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentIndex;
    private int arrowColorIndex;
    private int ringColorIndex;

    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;
    private int cellEditColor;
    private int cellLockedColor;
    private int tableLineColor;
    private int compassArrowColor;
    private int compassRingColor;
    private int sinColor;
    private int cosColor;

    private ZoomLayout zoomLayout;

    private EditText azInput;
    private EditText activeAngleInput;
    private TextView compassCaption;
    private TextView azModeHint;
    private Button modeAzBtn;
    private Button modeRumboBtn;
    private Button modeContraAzBtn;
    private Button modeContraRumboBtn;
    private TextView compassAzLabel;
    private TextView compassRumboLabel;
    private TextView compassContraAzLabel;
    private TextView compassContraRumboLabel;
    private int azInputMode = 0;
    private CompassView compassAzView;
    private CompassView compassRumboView;
    private CompassView compassContraAzView;
    private CompassView compassContraRumboView;

    private EditText coordAzInput;
    private EditText distanceInput;
    private TextView coordResult;

    private EditText dhInput;
    private EditText diInput;
    private EditText angleInput;
    private EditText desnivelInput;
    private TextView distanceCalcResult;

    private EditText polyX0Input;
    private EditText polyY0Input;
    private TextView polyCheckResult;
    private TextView polyProcedureResult;
    private EditText hiloSupCalcInput;
    private EditText hiloInfCalcInput;
    private TextView hiloDistValue;
    private TextView hiloDistCalcResult;

    private TextView levelCheckResult;
    private TextView stadiaCheckResult;

    private final List<TableDataRow> tableRows = new ArrayList<>();
    private final List<LevelDataRow> levelRows = new ArrayList<>();
    private final List<StadiaLevelRow> stadiaRows = new ArrayList<>();
    private TableLayout coordTable;
    private TableLayout levelTable;
    private TableLayout stadiaTable;
    private boolean suppressWorkCapture = false;
    private boolean showingSettings = false;

    private View selectedColorCell;
    private TableLayout selectedColorTable;
    private int selectedColorRow = -1;
    private int selectedColorCol = -1;
    private EditText selectedDistCell;
    private int manualTextColorIndex = 0;
    private int manualBgColorIndex = 0;
    private final int[] manualTextColors = {
            Color.rgb(245, 245, 247),
            Color.rgb(255, 171, 0),
            Color.rgb(0, 184, 148),
            Color.rgb(64, 158, 255),
            Color.rgb(255, 82, 82),
            Color.rgb(30, 33, 40)
    };
    private final int[] manualBgColors = {
            Color.rgb(25, 31, 42),
            Color.rgb(51, 38, 10),
            Color.rgb(9, 45, 35),
            Color.rgb(12, 44, 82),
            Color.rgb(70, 24, 24),
            Color.rgb(245, 246, 250)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        buildUi();
    }

    @Override
    protected void onPause() {
        saveCurrentWork();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (showingSettings) {
            showingSettings = false;
            buildUi();
        } else {
            super.onBackPressed();
        }
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        accentIndex = sp.getInt("accent", 0);
        arrowColorIndex = sp.getInt("arrow_color", 0);
        ringColorIndex = sp.getInt("ring_color", 0);
    }

    private void savePrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("theme", themeMode)
                .putInt("accent", accentIndex)
                .putInt("arrow_color", arrowColorIndex)
                .putInt("ring_color", ringColorIndex)
                .apply();
    }

    private void applyPalette() {
        borderColor = ACCENTS[accentIndex % ACCENTS.length];
        compassArrowColor = COMPASS_ARROW_COLORS[arrowColorIndex % COMPASS_ARROW_COLORS.length];
        compassRingColor = COMPASS_RING_COLORS[ringColorIndex % COMPASS_RING_COLORS.length];

        sinColor = Color.rgb(255, 171, 0);
        cosColor = Color.rgb(0, 184, 148);

        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputFillColor = Color.WHITE;
            inputStrokeColor = Color.rgb(178, 184, 196);
            resultFillColor = Color.rgb(245, 252, 248);
            resultStrokeColor = Color.rgb(29, 185, 84);
            cellEditColor = Color.rgb(252, 253, 255);
            cellLockedColor = Color.rgb(244, 246, 250);
            tableLineColor = Color.rgb(190, 196, 206);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(12, 18, 28);
            cellLockedColor = Color.rgb(21, 23, 28);
            tableLineColor = Color.rgb(74, 78, 88);
        } else {
            bgColor = Color.rgb(13, 18, 28);
            appBarColor = Color.rgb(6, 38, 63);
            cardColor = Color.rgb(22, 29, 40);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(184, 190, 198);
            inputFillColor = Color.rgb(15, 21, 31);
            inputStrokeColor = Color.rgb(85, 92, 104);
            resultFillColor = Color.rgb(13, 42, 30);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(11, 25, 41);
            cellLockedColor = Color.rgb(25, 31, 42);
            tableLineColor = Color.rgb(78, 84, 96);
        }
    }

    private void buildUi() {
        if (!suppressWorkCapture) saveCurrentWork();
        showingSettings = false;
        applyPalette();
        tableRows.clear();
        levelRows.clear();
        stadiaRows.clear();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        content.addView(azimuthBlock());
        content.addView(coordBlock());
        content.addView(distanceBlock());
        content.addView(twoHairDistanceMiniBlock());
        content.addView(partialTableBlock());
        content.addView(levelingBlock());
        content.addView(stadiaLevelingBlock());

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));
        setContentView(root);
        restoreCurrentWork();
    }

    private void saveCurrentWork() {
        if (azInput == null) return;

        SharedPreferences.Editor ed = getSharedPreferences(PREFS, MODE_PRIVATE).edit();

        putText(ed, "work_az_input", azInput);
        putText(ed, "work_az_label", compassAzLabel);
        putText(ed, "work_rumbo_label", compassRumboLabel);
        putText(ed, "work_contraaz_label", compassContraAzLabel);
        putText(ed, "work_contrarumbo_label", compassContraRumboLabel);
        putText(ed, "work_compass_caption", compassCaption);

        putText(ed, "work_coord_az", coordAzInput);
        putText(ed, "work_coord_dist", distanceInput);
        putText(ed, "work_coord_result", coordResult);

        putText(ed, "work_dh", dhInput);
        putText(ed, "work_di", diInput);
        putText(ed, "work_angle", angleInput);
        putText(ed, "work_desnivel", desnivelInput);
        putText(ed, "work_distance_result", distanceCalcResult);
        putText(ed, "work_hilo_sup_calc", hiloSupCalcInput);
        putText(ed, "work_hilo_inf_calc", hiloInfCalcInput);
        putText(ed, "work_hilo_dist_value", hiloDistValue);
        putText(ed, "work_hilo_dist_result", hiloDistCalcResult);
        putText(ed, "work_poly_x0", polyX0Input);
        putText(ed, "work_poly_y0", polyY0Input);
        putText(ed, "work_poly_check", polyCheckResult);
        putText(ed, "work_poly_proc", polyProcedureResult);

        putText(ed, "work_level_check", levelCheckResult);
        putText(ed, "work_stadia_check", stadiaCheckResult);

        ed.putInt("work_coord_count", tableRows.size());
        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            putText(ed, "work_coord_" + i + "_est", r.est);
            putText(ed, "work_coord_" + i + "_pv", r.pv);
            putText(ed, "work_coord_" + i + "_az", r.az);
            putText(ed, "work_coord_" + i + "_dist", r.dist);
            putText(ed, "work_coord_" + i + "_rumbo", r.rumbo);
            putText(ed, "work_coord_" + i + "_sen", r.sen);
            putText(ed, "work_coord_" + i + "_cos", r.cos);
            putText(ed, "work_coord_" + i + "_este", r.este);
            putText(ed, "work_coord_" + i + "_oeste", r.oeste);
            putText(ed, "work_coord_" + i + "_norte", r.norte);
            putText(ed, "work_coord_" + i + "_sur", r.sur);
            putText(ed, "work_coord_" + i + "_ec", r.eCorr);
            putText(ed, "work_coord_" + i + "_wc", r.wCorr);
            putText(ed, "work_coord_" + i + "_nc", r.nCorr);
            putText(ed, "work_coord_" + i + "_sc", r.sCorr);
            putText(ed, "work_coord_" + i + "_x", r.x);
            putText(ed, "work_coord_" + i + "_y", r.y);
        }

        ed.putInt("work_level_count", levelRows.size());
        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            putText(ed, "work_level_" + i + "_pv", r.pv);
            putText(ed, "work_level_" + i + "_va", r.vAtras);
            putText(ed, "work_level_" + i + "_vi", r.vIntermedia);
            putText(ed, "work_level_" + i + "_vf", r.vAdelante);
            putText(ed, "work_level_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_level_" + i + "_cn", r.cotaNivel);
        }

        ed.putInt("work_stadia_count", stadiaRows.size());
        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            putText(ed, "work_stadia_" + i + "_pv", r.pv);
            putText(ed, "work_stadia_" + i + "_tipo", r.tipo);
            putText(ed, "work_stadia_" + i + "_hi", r.hInf);
            putText(ed, "work_stadia_" + i + "_hm", r.hMedio);
            putText(ed, "work_stadia_" + i + "_hs", r.hSup);
            putText(ed, "work_stadia_" + i + "_dist", r.distancia);
            putText(ed, "work_stadia_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        ed.apply();
    }

    private void restoreCurrentWork() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);

        setTextIfExists(sp, "work_az_input", azInput);
        setTextIfExists(sp, "work_az_label", compassAzLabel);
        setTextIfExists(sp, "work_rumbo_label", compassRumboLabel);
        setTextIfExists(sp, "work_contraaz_label", compassContraAzLabel);
        setTextIfExists(sp, "work_contrarumbo_label", compassContraRumboLabel);
        setTextIfExists(sp, "work_compass_caption", compassCaption);

        setTextIfExists(sp, "work_coord_az", coordAzInput);
        setTextIfExists(sp, "work_coord_dist", distanceInput);
        setTextIfExists(sp, "work_coord_result", coordResult);

        setTextIfExists(sp, "work_dh", dhInput);
        setTextIfExists(sp, "work_di", diInput);
        setTextIfExists(sp, "work_angle", angleInput);
        setTextIfExists(sp, "work_desnivel", desnivelInput);
        setTextIfExists(sp, "work_distance_result", distanceCalcResult);
        setTextIfExists(sp, "work_hilo_sup_calc", hiloSupCalcInput);
        setTextIfExists(sp, "work_hilo_inf_calc", hiloInfCalcInput);
        setTextIfExists(sp, "work_hilo_dist_value", hiloDistValue);
        setTextIfExists(sp, "work_hilo_dist_result", hiloDistCalcResult);
        setTextIfExists(sp, "work_poly_x0", polyX0Input);
        setTextIfExists(sp, "work_poly_y0", polyY0Input);
        setTextIfExists(sp, "work_poly_check", polyCheckResult);
        setTextIfExists(sp, "work_poly_proc", polyProcedureResult);

        setTextIfExists(sp, "work_level_check", levelCheckResult);
        setTextIfExists(sp, "work_stadia_check", stadiaCheckResult);

        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            setTextIfExists(sp, "work_coord_" + i + "_est", r.est);
            setTextIfExists(sp, "work_coord_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_coord_" + i + "_az", r.az);
            setTextIfExists(sp, "work_coord_" + i + "_dist", r.dist);
            setTextIfExists(sp, "work_coord_" + i + "_rumbo", r.rumbo);
            setTextIfExists(sp, "work_coord_" + i + "_sen", r.sen);
            setTextIfExists(sp, "work_coord_" + i + "_cos", r.cos);
            setTextIfExists(sp, "work_coord_" + i + "_este", r.este);
            setTextIfExists(sp, "work_coord_" + i + "_oeste", r.oeste);
            setTextIfExists(sp, "work_coord_" + i + "_norte", r.norte);
            setTextIfExists(sp, "work_coord_" + i + "_sur", r.sur);
            setTextIfExists(sp, "work_coord_" + i + "_ec", r.eCorr);
            setTextIfExists(sp, "work_coord_" + i + "_wc", r.wCorr);
            setTextIfExists(sp, "work_coord_" + i + "_nc", r.nCorr);
            setTextIfExists(sp, "work_coord_" + i + "_sc", r.sCorr);
            setTextIfExists(sp, "work_coord_" + i + "_x", r.x);
            setTextIfExists(sp, "work_coord_" + i + "_y", r.y);
        }

        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            setTextIfExists(sp, "work_level_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_level_" + i + "_va", r.vAtras);
            setTextIfExists(sp, "work_level_" + i + "_vi", r.vIntermedia);
            setTextIfExists(sp, "work_level_" + i + "_vf", r.vAdelante);
            setTextIfExists(sp, "work_level_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_level_" + i + "_cn", r.cotaNivel);
        }

        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            setTextIfExists(sp, "work_stadia_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_stadia_" + i + "_tipo", r.tipo);
            setTextIfExists(sp, "work_stadia_" + i + "_hi", r.hInf);
            setTextIfExists(sp, "work_stadia_" + i + "_hm", r.hMedio);
            setTextIfExists(sp, "work_stadia_" + i + "_hs", r.hSup);
            setTextIfExists(sp, "work_stadia_" + i + "_dist", r.distancia);
            setTextIfExists(sp, "work_stadia_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        try {
            String s = azInput.getText().toString().trim();
            if (!s.isEmpty()) {
                double az = normalize(parseAngle(s));
                double contra = contraAzimuth(az);
                if (compassAzView != null) compassAzView.setAzimuth(az);
                if (compassRumboView != null) compassRumboView.setAzimuth(az);
                if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
                if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
            }
        } catch (Exception ignored) {
        }
    }

    private void putText(SharedPreferences.Editor ed, String key, TextView view) {
        if (view != null) ed.putString(key, view.getText().toString());
    }

    private void setTextIfExists(SharedPreferences sp, String key, TextView view) {
        if (view != null && sp.contains(key)) view.setText(sp.getString(key, ""));
    }

    private void clearWorkAndRebuild() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        for (String key : sp.getAll().keySet()) {
            if (key.startsWith("work_")) ed.remove(key);
        }
        ed.commit();
        suppressWorkCapture = true;
        buildUi();
        suppressWorkCapture = false;
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(14), dp(14), dp(14));
        bar.setBackgroundColor(appBarColor);

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleWrap.setLayoutParams(titleParams);

        TextView title = new TextView(this);
        title.setText("Geo Topo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleWrap.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Cálculos topográficos");
        sub.setTextColor(Color.rgb(193, 218, 240));
        sub.setTextSize(13);
        titleWrap.addView(sub);
        bar.addView(titleWrap);

        Button settings = new Button(this);
        settings.setText("Ajustes");
        settings.setAllCaps(false);
        settings.setTextColor(Color.WHITE);
        settings.setTextSize(14);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        settings.setBackground(gd);
        settings.setPadding(dp(14), dp(8), dp(14), dp(8));
        settings.setOnClickListener(v -> showSettingsScreen());
        bar.addView(settings);

        return bar;
    }

    private void showSettingsScreen() {
        saveCurrentWork();
        applyPalette();
        showingSettings = true;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(settingsBar());

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(18), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        content.addView(settingHeader("APARIENCIA"));
        content.addView(themeRow("☀", "Tema claro", "Fondo blanco limpio", THEME_LIGHT));
        content.addView(themeRow("☾", "Tema oscuro", "Fondo azul oscuro", THEME_DARK));
        content.addView(themeRow("●", "Tema negro", "Fondo negro AMOLED", THEME_BLACK));

        content.addView(settingHeader("COLORES"));
        content.addView(valueRow("▣", "Color de cuadros", accentName(accentIndex), v ->
                showColorPickerDialog("Color de cuadros", accentNames(), ACCENTS, accentIndex, index -> {
                    accentIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));
        content.addView(valueRow("➤", "Flecha de brújula", arrowName(arrowColorIndex), v ->
                showColorPickerDialog("Flecha de brújula", arrowNames(), COMPASS_ARROW_COLORS, arrowColorIndex, index -> {
                    arrowColorIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));
        content.addView(valueRow("◎", "Círculo de brújula", ringName(ringColorIndex), v ->
                showColorPickerDialog("Círculo de brújula", ringNames(), COMPASS_RING_COLORS, ringColorIndex, index -> {
                    ringColorIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));

        content.addView(settingHeader("TABLAS Y DATOS"));
        content.addView(infoRow("＋", "Agregar filas", "Usa + Fila o + Punto dentro de cada cuadro"));
        content.addView(infoRow("□", "Recordar datos", "Abrir donde te quedaste"));
        content.addView(valueRow("🧹", "Limpiar datos guardados", "Borra todos los cuadros", v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Limpiar datos")
                    .setMessage("¿Quieres borrar los datos guardados de los cuadros?")
                    .setPositiveButton("Borrar", (d, w) -> {
                        clearWorkAndRebuild();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        }));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private View settingsBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(16), dp(14), dp(16));
        bar.setBackgroundColor(appBarColor);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(40);
        back.setGravity(Gravity.CENTER);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setOnClickListener(v -> {
            showingSettings = false;
            buildUi();
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView title = new TextView(this);
        title.setText("Ajustes");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView ok = new TextView(this);
        ok.setText("✓");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(34);
        ok.setGravity(Gravity.CENTER);
        ok.setTypeface(Typeface.DEFAULT_BOLD);
        ok.setOnClickListener(v -> {
            savePrefs();
            showingSettings = false;
            buildUi();
        });
        bar.addView(ok, new LinearLayout.LayoutParams(dp(54), dp(54)));
        return bar;
    }

    private TextView settingHeader(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(borderColor);
        v.setTextSize(14);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(4), dp(18), dp(4), dp(8));
        return v;
    }

    private View themeRow(String icon, String title, String subtitle, int mode) {
        return settingRow(icon, title, subtitle, themeMode == mode ? "◉" : "○", v -> {
            themeMode = mode;
            savePrefs();
            showSettingsScreen();
        });
    }

    private View valueRow(String icon, String title, String subtitle, View.OnClickListener listener) {
        return settingRow(icon, title, subtitle, "›", listener);
    }

    private View infoRow(String icon, String title, String subtitle) {
        return settingRow(icon, title, subtitle, "", null);
    }

    private View settingRow(String icon, String title, String subtitle, String right, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 35, 52));
        bg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(225, 230, 238) : Color.rgb(16, 48, 70));
        row.setBackground(bg);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, 0, 0, dp(6));
        row.setLayoutParams(rlp);
        if (listener != null) row.setOnClickListener(listener);

        TextView ico = new TextView(this);
        ico.setText(icon);
        ico.setTextSize(24);
        ico.setTextColor(borderColor);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(58), dp(54)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(textColor);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(t);
        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(subTextColor);
        s.setTextSize(13);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView rr = new TextView(this);
        rr.setText(right);
        rr.setTextColor(right.equals("◉") ? borderColor : subTextColor);
        rr.setTextSize(right.equals("›") ? 30 : 20);
        rr.setGravity(Gravity.CENTER);
        row.addView(rr, new LinearLayout.LayoutParams(dp(42), dp(54)));
        return row;
    }

    private String accentName(int idx) {
        String[] names = accentNames();
        return names[idx % names.length];
    }

    private String arrowName(int idx) {
        String[] names = arrowNames();
        return names[idx % names.length];
    }

    private String ringName(int idx) {
        String[] names = ringNames();
        return names[idx % names.length];
    }

    private String[] accentNames() {
        return fullColorNames();
    }

    private String[] arrowNames() {
        return fullColorNames();
    }

    private String[] ringNames() {
        return fullColorNames();
    }

    private String[] fullColorNames() {
        return new String[]{
                "Azul", "Cian", "Turquesa", "Verde", "Verde lima", "Amarillo",
                "Ámbar", "Naranja", "Rojo", "Rosa", "Morado", "Índigo",
                "Marrón", "Gris", "Negro", "Blanco"
        };
    }

    private void showColorPickerDialog(String title, String[] names, int[] colors, int currentIndex, ColorPickListener listener) {
        final int[] selected = {currentIndex};
        final AlertDialog[] dialogRef = new AlertDialog[1];

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(12));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 25, 39));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(210, 218, 230) : Color.rgb(58, 76, 100));
        panel.setBackground(panelBg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setText("◉");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(23);
        icon.setTextColor(borderColor);
        head.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(textColor);
        titleView.setTextSize(22);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(titleView);
        TextView help = new TextView(this);
        help.setText("Elige el color que quieres aplicar.");
        help.setTextColor(subTextColor);
        help.setTextSize(13);
        texts.addView(help);
        head.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("×");
        close.setGravity(Gravity.CENTER);
        close.setTextColor(subTextColor);
        close.setTextSize(30);
        close.setOnClickListener(v -> {
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        head.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        panel.addView(head);

        ScrollView scroller = new ScrollView(this);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(0, dp(10), 0, dp(6));

        int columns = 2;
        for (int i = 0; i < names.length && i < colors.length; i += columns) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < columns; c++) {
                int index = i + c;
                if (index >= names.length || index >= colors.length) {
                    SpaceView spacer = new SpaceView(this);
                    row.addView(spacer, weightParams());
                    continue;
                }
                View option = colorOptionView(names[index], colors[index], index == currentIndex);
                final int picked = index;
                option.setOnClickListener(v -> {
                    selected[0] = picked;
                    listener.onPick(picked);
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                });
                row.addView(option, weightParams());
            }
            grid.addView(row);
        }
        scroller.addView(grid);
        panel.addView(scroller, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)));

        TextView note = new TextView(this);
        note.setText("Se aplica al instante y queda guardado al volver.");
        note.setTextColor(subTextColor);
        note.setTextSize(12);
        note.setPadding(dp(4), dp(2), dp(4), dp(8));
        panel.addView(note);

        Button cancel = btn("Cerrar");
        cancel.setOnClickListener(v -> {
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        panel.addView(cancel);

        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            }
        });
        dialog.show();
    }

    private View colorOptionView(String name, int color, boolean selected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(15, 26, 40));
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(selected ? 2 : 1), selected ? color : inputStrokeColor);
        row.setBackground(bg);

        TextView chip = new TextView(this);
        chip.setText(selected ? "✓" : "");
        chip.setGravity(Gravity.CENTER);
        chip.setTextColor(bestContrastColor(color));
        chip.setTextSize(15);
        chip.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable chipBg = new GradientDrawable();
        chipBg.setShape(GradientDrawable.OVAL);
        chipBg.setColor(color);
        chipBg.setStroke(dp(1), Color.rgb(188, 194, 205));
        chip.setBackground(chipBg);
        row.addView(chip, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(textColor);
        label.setTextSize(14);
        label.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        label.setPadding(dp(10), 0, 0, 0);
        row.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    public static class SpaceView extends View {
        public SpaceView(Context context) { super(context); }
    }

    private int bestContrastColor(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
        return luminance > 170 ? Color.rgb(30, 33, 40) : Color.WHITE;
    }

    private View azimuthBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("1. Conversión angular"));
        box.addView(small("Elige qué dato tienes, escribe el valor y calcula azimut, rumbo, contraazimut y contrarumbo."));

        azModeHint = small("¿Qué dato tienes? Azimut");
        azModeHint.setPadding(0, dp(6), 0, dp(2));
        box.addView(azModeHint);

        LinearLayout modeRow1 = new LinearLayout(this);
        modeRow1.setOrientation(LinearLayout.HORIZONTAL);
        modeAzBtn = smallModeBtn("Azimut", 0);
        modeRumboBtn = smallModeBtn("Rumbo", 1);
        modeRow1.addView(modeAzBtn, weightParams());
        modeRow1.addView(modeRumboBtn, weightParams());
        box.addView(modeRow1);

        LinearLayout modeRow2 = new LinearLayout(this);
        modeRow2.setOrientation(LinearLayout.HORIZONTAL);
        modeContraAzBtn = smallModeBtn("Contraazimut", 2);
        modeContraRumboBtn = smallModeBtn("Contrarumbo", 3);
        modeRow2.addView(modeContraAzBtn, weightParams());
        modeRow2.addView(modeContraRumboBtn, weightParams());
        box.addView(modeRow2);

        azInput = edit("Ejemplo: 150°00'00\"");
        trackAngleEdit(azInput);
        box.addView(azInput);
        box.addView(angleShortcutBar());
        setAzInputMode(0);

        Button calc = btn("Calcular");
        calc.setOnClickListener(v -> calculateAzimuth());
        box.addView(calc);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(compassItem("Azimut", 0), weightParams());
        row1.addView(compassItem("Rumbo", 1), weightParams());
        box.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(compassItem("Contraazimut", 2), weightParams());
        row2.addView(compassItem("Contrarumbo", 3), weightParams());
        box.addView(row2);

        compassCaption = smallCenter("Vista de referencia");
        compassCaption.setPadding(0, dp(6), 0, 0);
        box.addView(compassCaption);
        return box;
    }

    private Button smallModeBtn(String text, int mode) {
        Button b = btn(text);
        b.setTextSize(13);
        b.setOnClickListener(v -> setAzInputMode(mode));
        return b;
    }

    private void setAzInputMode(int mode) {
        azInputMode = mode;
        if (azModeHint != null) {
            String[] names = {"Azimut", "Rumbo", "Contraazimut", "Contrarumbo"};
            azModeHint.setText("¿Qué dato tienes? " + names[mode]);
        }
        if (azInput != null) {
            if (mode == 0) azInput.setHint("Ejemplo: 150°00'00\"");
            else if (mode == 1) azInput.setHint("Ejemplo: S 30°00'00\" E");
            else if (mode == 2) azInput.setHint("Ejemplo: 330°00'00\"");
            else azInput.setHint("Ejemplo: N 30°00'00\" W");
        }
        styleModeButton(modeAzBtn, mode == 0);
        styleModeButton(modeRumboBtn, mode == 1);
        styleModeButton(modeContraAzBtn, mode == 2);
        styleModeButton(modeContraRumboBtn, mode == 3);
    }

    private void styleModeButton(Button b, boolean active) {
        if (b == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(18));
        gd.setColor(active ? borderColor : inputFillColor);
        gd.setStroke(dp(active ? 2 : 1), active ? borderColor : inputStrokeColor);
        b.setBackground(gd);
        b.setTextColor(active ? Color.WHITE : textColor);
    }

    private View compassItem(String title, int type) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(4), dp(8), dp(4), dp(8));

        CompassView cv = new CompassView(this);
        cv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(185)));
        if (type == 0) compassAzView = cv;
        else if (type == 1) compassRumboView = cv;
        else if (type == 2) compassContraAzView = cv;
        else compassContraRumboView = cv;
        wrap.addView(cv);

        TextView t = compassResultChip(title, "—");
        if (type == 0) compassAzLabel = t;
        else if (type == 1) compassRumboLabel = t;
        else if (type == 2) compassContraAzLabel = t;
        else compassContraRumboLabel = t;
        wrap.addView(t);
        return wrap;
    }

    private TextView compassResultChip(String title, String value) {
        TextView v = tv(title.toUpperCase(Locale.US) + "\n" + value, 13, true);
        v.setGravity(Gravity.CENTER);
        v.setLineSpacing(0, 1.12f);
        v.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(2), dp(6), dp(2), 0);
        v.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(16, 25, 38));
        gd.setCornerRadius(dp(10));
        gd.setStroke(dp(1), borderColor);
        v.setBackground(gd);
        return v;
    }

    private View coordBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("2. Distancia y coordenadas parciales"));
        box.addView(small("Ingresa azimut y distancia horizontal para obtener seno, coseno, ΔX, ΔY y E/O/N/S."));

        coordAzInput = edit("Azimut");
        trackAngleEdit(coordAzInput);
        distanceInput = edit("Distancia horizontal");
        distanceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(coordAzInput);
        box.addView(angleShortcutBar());
        box.addView(distanceInput);

        Button calc = btn("Calcular E/O/N/S");
        calc.setOnClickListener(v -> calculateCoordinateSingle());
        box.addView(calc);

        coordResult = resultBox("Resultado pendiente");
        box.addView(coordResult);
        return box;
    }

    private View distanceBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("3. Distancia, desnivel y pendiente"));
        box.addView(small("Completa dos datos mínimos. Ejemplos: distancia horizontal + desnivel, o distancia inclinada + ángulo vertical."));

        dhInput = edit("Distancia horizontal");
        diInput = edit("Distancia inclinada");
        angleInput = edit("Ángulo vertical");
        trackAngleEdit(angleInput);
        desnivelInput = edit("Desnivel / diferencia de cota");

        dhInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        diInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        desnivelInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(dhInput);
        box.addView(diInput);
        box.addView(angleInput);
        box.addView(angleShortcutBar());
        box.addView(desnivelInput);

        Button calc = btn("Calcular distancia");
        calc.setOnClickListener(v -> calculateDistanceData());
        box.addView(calc);

        distanceCalcResult = resultBox("Resultado pendiente");
        box.addView(distanceCalcResult);
        return box;
    }

    private View twoHairDistanceMiniBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("4. Distancia por 2 hilos"));

        box.addView(small("Escribe hilo superior e inferior. La app usa la diferencia entre ambos × 100, muestra la distancia y permite copiarla o pegarla en DIST."));

        LinearLayout inputs = new LinearLayout(this);
        inputs.setOrientation(LinearLayout.HORIZONTAL);
        hiloSupCalcInput = edit("Hilo superior");
        hiloInfCalcInput = edit("Hilo inferior");
        hiloDistValue = smallResultCell("—");
        hiloSupCalcInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        hiloInfCalcInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        inputs.addView(labeledInput("Hilo superior", hiloSupCalcInput), weightParams());
        inputs.addView(labeledInput("Hilo inferior", hiloInfCalcInput), weightParams());
        inputs.addView(labeledText("Distancia", hiloDistValue), weightParams());
        box.addView(inputs);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        Button calc = btn("Calcular 2 hilos");
        calc.setOnClickListener(v -> calculateTwoHairDistance());
        btns.addView(calc, weightParams());
        Button copy = btn("Copiar distancia");
        copy.setOnClickListener(v -> copyTwoHairDistance());
        btns.addView(copy, weightParams());
        Button paste = btn("Pegar en DIST.");
        paste.setOnClickListener(v -> pasteTwoHairDistanceIntoSelectedCell());
        btns.addView(paste, weightParams());
        box.addView(btns);

        hiloDistCalcResult = resultBox("Distancia calculada: —");
        box.addView(hiloDistCalcResult);
        return box;
    }

    private View partialTableBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("5. Poligonal cerrada"));
        box.addView(small("Llena estación, P.V., azimut y distancia. La app calcula rumbo, E/W/N/S, corrección y coordenadas X/Y."));

        box.addView(small("Coordenada inicial editable. Si el ejercicio no da X/Y, deja 0.000."));
        LinearLayout xyRow = new LinearLayout(this);
        xyRow.setOrientation(LinearLayout.HORIZONTAL);
        polyX0Input = edit("X inicial");
        polyY0Input = edit("Y inicial");
        polyX0Input.setText("0.000");
        polyY0Input.setText("0.000");
        polyX0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        polyY0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        xyRow.addView(labeledInput("X inicial", polyX0Input), weightParams());
        xyRow.addView(labeledInput("Y inicial", polyY0Input), weightParams());
        box.addView(xyRow);
        box.addView(small("Color manual: toca una celda y usa Texto, Fondo, Fila o Columna. Esto solo cambia la apariencia, no el cálculo."));
        box.addView(tableColorBar());
        box.addView(small("Botones rápidos para azimut: toca una celda de AZIMUT y usa los botones de grados, minutos, segundos o 00. También puedes escribir 326 30 o 326.30."));
        box.addView(angleShortcutBar());

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        coordTable = new TableLayout(this);
        coordTable.setStretchAllColumns(false);
        coordTable.addView(headerRow("EST.", "P.V.", "AZIMUT", "DIST.", "RB", "E", "W", "N", "S", "E CORR.", "W CORR.", "N CORR.", "S CORR.", "X", "Y"));
        int coordCount = Math.max(6, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_coord_count", 6));
        for (int i = 0; i < coordCount; i++) addCoordRow();
        hsv.addView(coordTable);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Fila");
        add.setOnClickListener(v -> addCoordRow());
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular poligonal");
        calc.setOnClickListener(v -> calculateTable());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);

        polyCheckResult = resultBox("Verificación pendiente");
        box.addView(polyCheckResult);
        polyProcedureResult = resultBox("Procedimiento pendiente. Aquí verás las fórmulas usadas, dónde va seno y dónde va coseno.");
        LinearLayout moreBtns = new LinearLayout(this);
        moreBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button procBtn = btn("Ver procedimiento");
        procBtn.setOnClickListener(v -> showProcedureDialog("Procedimiento de poligonal", polyProcedureResult.getText()));
        moreBtns.addView(procBtn, weightParams());
        Button graphBtn = btn("Ver gráfico");
        graphBtn.setOnClickListener(v -> showPolyGraphDialog());
        moreBtns.addView(graphBtn, weightParams());
        box.addView(moreBtns);
        return box;
    }

    private View levelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("6. Nivelación: cota terreno y cota nivel"));
        box.addView(small("Llena BM o punto inicial con cota conocida. Usa vista atrás, intermedia y adelante. Puedes agregar más puntos con +."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        levelTable = new TableLayout(this);
        levelTable.setStretchAllColumns(false);
        levelTable.addView(headerRowCompact("P.V.", "V. ATRÁS (+)", "V. INTERMEDIA (-)", "V. ADELANTE (-)", "COTA TERRENO", "COTA NIVEL"));
        int levelCount = Math.max(12, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_level_count", 12));
        for (int i = 0; i < levelCount; i++) addLevelRow(i == 0 ? "BM1" : "", i == 0 ? "1000.000" : "");
        hsv.addView(levelTable);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Punto");
        add.setOnClickListener(v -> addLevelRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular cotas");
        calc.setOnClickListener(v -> calculateLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);
        levelCheckResult = resultBox("Verificación pendiente");
        box.addView(levelCheckResult);
        return box;
    }


    private View stadiaLevelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("7. Nivelación con tres hilos"));
        box.addView(small("Cuadro básico: tipo de vista, hilo inferior, hilo medio e hilo superior. Puedes agregar más filas con +."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        stadiaTable = new TableLayout(this);
        stadiaTable.setStretchAllColumns(false);
        stadiaTable.addView(headerRow("P.V.", "TIPO", "H. INF.", "H. MEDIO", "H. SUP.", "DIST.", "COTA TERRENO", "COTA NIVEL"));
        int stadiaCount = Math.max(10, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_stadia_count", 10));
        for (int i = 0; i < stadiaCount; i++) addStadiaRow(i == 0 ? "BM1" : "", i == 0 ? "A" : "");
        hsv.addView(stadiaTable);
        box.addView(hsv);

        box.addView(small("Tipo: A = vista atrás, I = vista intermedia, D = vista adelante. La distancia se calcula con (H. superior - H. inferior) × 100."));

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Fila");
        add.setOnClickListener(v -> addStadiaRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular hilos");
        calc.setOnClickListener(v -> calculateStadiaLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);
        stadiaCheckResult = resultBox("Verificación pendiente");
        box.addView(stadiaCheckResult);
        return box;
    }

    private void addCoordRow() {
        TableDataRow row = new TableDataRow();
        TableRow tr = new TableRow(this);
        row.est = cellEdit("", false);
        row.pv = cellEdit("", false);
        row.az = cellEdit("", false);
        trackAngleEdit(row.az);
        row.dist = cellEdit("", true);
        row.rumbo = cellText("—");
        row.sen = cellText("—");
        row.cos = cellText("—");
        row.este = cellText("—");
        row.oeste = cellText("—");
        row.norte = cellText("—");
        row.sur = cellText("—");
        row.eCorr = cellText("—");
        row.wCorr = cellText("—");
        row.nCorr = cellText("—");
        row.sCorr = cellText("—");
        row.x = cellText("—");
        row.y = cellText("—");
        applyDefaultPolyColors(row);
        tr.addView(row.est); tr.addView(row.pv); tr.addView(row.az); tr.addView(row.dist);
        tr.addView(row.rumbo); tr.addView(row.este); tr.addView(row.oeste); tr.addView(row.norte); tr.addView(row.sur);
        tr.addView(row.eCorr); tr.addView(row.wCorr); tr.addView(row.nCorr); tr.addView(row.sCorr); tr.addView(row.x); tr.addView(row.y);
        int visualRow = coordTable.getChildCount();
        for (int c = 0; c < tr.getChildCount(); c++) {
            registerColorCell(tr.getChildAt(c), coordTable, visualRow, c);
        }
        coordTable.addView(tr);
        tableRows.add(row);
    }

    private void addLevelRow(String label, String cotaDefault) {
        LevelDataRow row = new LevelDataRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEditCompact(label, false);
        row.vAtras = cellEditCompact("", true);
        row.vIntermedia = cellEditCompact("", true);
        row.vAdelante = cellEditCompact("", true);
        row.cotaTerreno = cellEditCompact(cotaDefault, true);
        row.cotaNivel = cellTextCompact("—");
        tr.addView(row.pv); tr.addView(row.vAtras); tr.addView(row.vIntermedia); tr.addView(row.vAdelante); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        levelTable.addView(tr);
        levelRows.add(row);
    }

    private void addStadiaRow(String label, String tipoDefault) {
        StadiaLevelRow row = new StadiaLevelRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEdit(label, false);
        row.tipo = cellEdit(tipoDefault, false);
        row.hInf = cellEdit("", true);
        row.hMedio = cellEdit("", true);
        row.hSup = cellEdit("", true);
        row.distancia = cellText("—");
        row.cotaTerreno = cellEdit("", true);
        row.cotaNivel = cellText("—");
        tr.addView(row.pv); tr.addView(row.tipo); tr.addView(row.hInf); tr.addView(row.hMedio); tr.addView(row.hSup); tr.addView(row.distancia); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        stadiaTable.addView(tr);
        stadiaRows.add(row);
    }

    private void calculateStadiaLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (StadiaLevelRow row : stadiaRows) {
            String pv = row.pv.getText().toString().trim();
            String tipoText = row.tipo.getText().toString().trim();
            Double hInf = optNumber(row.hInf.getText().toString());
            Double hMedio = optNumber(row.hMedio.getText().toString());
            Double hSup = optNumber(row.hSup.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && tipoText.isEmpty() && hInf == null && hMedio == null && hSup == null && cota == null;
            if (empty) {
                row.distancia.setText("—");
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (hInf != null && hSup != null) {
                    double dist = (hSup - hInf) * 100.0;
                    if (dist < 0) throw new IllegalArgumentException("bad stadia order");
                    row.distancia.setText(f3(dist));
                } else {
                    row.distancia.setText("");
                }

                if (hMedio == null) throw new IllegalArgumentException("missing middle hair");

                int tipo = parseViewType(tipoText, cota != null, currentHI);
                if (tipo == 1) {
                    if (cota == null && lastCota != null) cota = lastCota;
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    row.cotaTerreno.setText(f3(cota));
                    currentHI = cota + hMedio;
                    sumBack += hMedio;
                    row.cotaNivel.setText(f3(currentHI));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                } else {
                    if (Double.isNaN(currentHI)) throw new IllegalArgumentException("no HI");
                    cota = currentHI - hMedio;
                    row.cotaTerreno.setText(f3(cota));
                    row.cotaNivel.setText("");
                    if (tipo == 3) sumForesight += hMedio;
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                calculated++;
            } catch (Exception e) {
                row.distancia.setText(row.distancia.getText().toString().equals("—") ? "ERROR" : row.distancia.getText().toString());
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Fórmula distancia: (H. superior - H. inferior) × 100\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);

        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣA - ΣD: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }

        stadiaCheckResult.setText(check);
        Toast.makeText(this, "Nivelación con hilos calculada", Toast.LENGTH_SHORT).show();
    }

    private int parseViewType(String tipoText, boolean hasKnownCota, double currentHI) {
        String t = tipoText.trim().toUpperCase(Locale.US);
        t = t.replace("Á", "A");
        if (t.isEmpty()) {
            if (Double.isNaN(currentHI) || hasKnownCota) return 1;
            return 2;
        }
        if (t.equals("A") || t.equals("VA") || t.contains("ATRAS")) return 1;
        if (t.equals("I") || t.equals("VI") || t.contains("INTER")) return 2;
        if (t.equals("D") || t.equals("F") || t.equals("FS") || t.equals("VAD") || t.contains("ADEL")) return 3;
        throw new IllegalArgumentException("bad view type");
    }


    private void calculateDistanceData() {
        try {
            Double dh = optNumber(dhInput.getText().toString());
            Double di = optNumber(diInput.getText().toString());
            Double angle = optAngle(angleInput.getText().toString());
            Double dn = optNumber(desnivelInput.getText().toString());

            double horizontal;
            double inclinada;
            double desnivel;
            double angulo;

            if (dh != null && dn != null) {
                horizontal = dh;
                desnivel = dn;
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
                angulo = Math.toDegrees(Math.atan2(desnivel, horizontal));
            } else if (di != null && angle != null) {
                inclinada = di;
                angulo = angle;
                horizontal = inclinada * Math.cos(Math.toRadians(angulo));
                desnivel = inclinada * Math.sin(Math.toRadians(angulo));
            } else if (dh != null && angle != null) {
                horizontal = dh;
                angulo = angle;
                desnivel = horizontal * Math.tan(Math.toRadians(angulo));
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
            } else if (di != null && dn != null) {
                inclinada = di;
                desnivel = dn;
                double inside = inclinada * inclinada - desnivel * desnivel;
                if (inside < 0) throw new IllegalArgumentException("invalid");
                horizontal = Math.sqrt(inside);
                angulo = Math.toDegrees(Math.asin(desnivel / inclinada));
            } else {
                showError("Faltan datos. Usa DH + desnivel, DI + ángulo, DH + ángulo, o DI + desnivel.");
                return;
            }

            if (Math.abs(horizontal) < 0.0000001) throw new IllegalArgumentException("zero horizontal");
            double pendiente = (desnivel / horizontal) * 100.0;

            distanceCalcResult.setText("Distancia horizontal: " + f3(horizontal) + "\n"
                    + "Distancia inclinada: " + f3(inclinada) + "\n"
                    + "Desnivel: " + f3(desnivel) + "\n"
                    + "Ángulo vertical: " + formatDms(angulo) + "\n"
                    + "Pendiente: " + f3(pendiente) + " %");
        } catch (Exception e) {
            showError("Revisa los datos. Ejemplo: DH 100 y desnivel 5, o DI 100 y ángulo 3°00'00\".");
        }
    }

    private void calculateTwoHairDistance() {
        try {
            double sup = parseNumber(hiloSupCalcInput.getText().toString());
            double inf = parseNumber(hiloInfCalcInput.getText().toString());
            double dist = Math.abs(sup - inf) * 100.0;
            if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
            hiloDistCalcResult.setText("Distancia calculada: " + f3(dist) + " m\n"
                    + "Operación: |" + f3(sup) + " - " + f3(inf) + "| × 100");
        } catch (Exception e) {
            if (hiloDistValue != null) hiloDistValue.setText("—");
            hiloDistCalcResult.setText("Distancia calculada: —\nRevisa los 2 hilos. Escribe números válidos.");
        }
    }

    private Double getTwoHairDistanceValue() {
        try {
            double sup = parseNumber(hiloSupCalcInput.getText().toString());
            double inf = parseNumber(hiloInfCalcInput.getText().toString());
            return Math.abs(sup - inf) * 100.0;
        } catch (Exception e) {
            return null;
        }
    }

    private void copyTwoHairDistance() {
        Double dist = getTwoHairDistanceValue();
        if (dist == null) {
            showError("Primero calcula una distancia válida con los 2 hilos.");
            return;
        }
        if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("distancia", f3(dist)));
            Toast.makeText(this, "Distancia copiada: " + f3(dist), Toast.LENGTH_SHORT).show();
        }
    }

    private void pasteTwoHairDistanceIntoSelectedCell() {
        Double dist = getTwoHairDistanceValue();
        if (dist == null) {
            showError("Primero calcula una distancia válida con los 2 hilos.");
            return;
        }
        if (selectedDistCell == null) {
            showError("Primero toca una celda de DIST. en la poligonal.");
            return;
        }
        if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
        selectedDistCell.setText(f3(dist));
        selectedDistCell.requestFocus();
        selectedDistCell.setSelection(selectedDistCell.getText().length());
        Toast.makeText(this, "Distancia pegada en DIST.", Toast.LENGTH_SHORT).show();
    }

    private void calculateLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (LevelDataRow row : levelRows) {
            String pv = row.pv.getText().toString().trim();
            Double va = optNumber(row.vAtras.getText().toString());
            Double vi = optNumber(row.vIntermedia.getText().toString());
            Double vad = optNumber(row.vAdelante.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && va == null && vi == null && vad == null && cota == null;
            if (empty) {
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (cota == null && !Double.isNaN(currentHI)) {
                    if (vi != null) cota = currentHI - vi;
                    else if (vad != null) cota = currentHI - vad;
                }

                if (cota != null) {
                    row.cotaTerreno.setText(f3(cota));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                if (vad != null) sumForesight += vad;
                if (va != null) {
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    sumBack += va;
                    currentHI = cota + va;
                    row.cotaNivel.setText(f3(currentHI));
                } else {
                    row.cotaNivel.setText(vi != null || vad != null ? "" : "—");
                }
                calculated++;
            } catch (Exception e) {
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);
        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣVA - ΣVAdelante: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }
        levelCheckResult.setText(check);
        Toast.makeText(this, "Nivelación calculada", Toast.LENGTH_SHORT).show();
    }

    private void calculateAzimuth() {
        try {
            String raw = azInput.getText().toString().trim();
            double az;
            if (azInputMode == 0) {
                az = normalize(parseAngle(raw));
            } else if (azInputMode == 1) {
                az = normalize(parseRumbo(raw));
            } else if (azInputMode == 2) {
                double contraAz = normalize(parseAngle(raw));
                az = contraAzimuth(contraAz);
            } else {
                double contraAz = normalize(parseRumbo(raw));
                az = contraAzimuth(contraAz);
            }
            double contra = contraAzimuth(az);
            if (compassAzView != null) compassAzView.setAzimuth(az);
            if (compassRumboView != null) compassRumboView.setAzimuth(az);
            if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
            if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
            if (compassAzLabel != null) compassAzLabel.setText("AZIMUT\n" + formatDms(az));
            if (compassRumboLabel != null) compassRumboLabel.setText("RUMBO\n" + rumbo(az));
            if (compassContraAzLabel != null) compassContraAzLabel.setText("CONTRAAZIMUT\n" + formatDms(contra));
            if (compassContraRumboLabel != null) compassContraRumboLabel.setText("CONTRARUMBO\n" + rumbo(contra));
            compassCaption.setText("Cuadrante: " + quadrantLabel(az));
        } catch (Exception e) {
            if (azInputMode == 0 || azInputMode == 2) {
                showError("Revisa el dato angular. Ejemplo correcto: 150°00'00\"");
            } else {
                showError("Revisa el rumbo. Ejemplo correcto: N 30°00'00\" W");
            }
        }
    }

    private void calculateCoordinateSingle() {
        try {
            double az = normalize(parseAngle(coordAzInput.getText().toString()));
            double distance = parseNumber(distanceInput.getText().toString());
            CoordinateResult r = coordinateResult(az, distance);
            coordResult.setText(coordinateOutput(az, distance, r));
        } catch (Exception e) {
            showError("Revisa azimut y distancia. Ejemplo: azimut 326°30'00\" y distancia 75.00");
        }
    }

    private void calculateTable() {
        ArrayList<TableDataRow> validRows = new ArrayList<>();
        ArrayList<Double> distances = new ArrayList<>();
        ArrayList<Double> azimuths = new ArrayList<>();
        ArrayList<Double> dxs = new ArrayList<>();
        ArrayList<Double> dys = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<String> estLabels = new ArrayList<>();
        ArrayList<String> pvLabels = new ArrayList<>();
        double sumDx = 0;
        double sumDy = 0;
        double perimeter = 0;
        int ok = 0;
        int referenceRows = 0;
        String lastEst = "";

        for (TableDataRow row : tableRows) {
            String azText = row.az.getText().toString().trim();
            String distText = row.dist.getText().toString().trim();
            String estText = row.est.getText().toString().trim();
            String pvText = row.pv.getText().toString().trim();
            if (!estText.isEmpty()) lastEst = estText;
            String effectiveEst = estText.isEmpty() ? lastEst : estText;

            if (azText.isEmpty() && distText.isEmpty() && estText.isEmpty() && pvText.isEmpty()) {
                blankPolyRow(row);
                continue;
            }

            try {
                double az = normalize(parseAngle(azText));
                row.rumbo.setText(rumbo(az));

                if (distText.isEmpty()) {
                    blankPolyNumbers(row);
                    referenceRows++;
                    continue;
                }

                double distance = parseNumber(distText);
                CoordinateResult r = coordinateResult(az, distance);

                row.sen.setText(f6(r.sen));
                row.cos.setText(f6(r.cos));
                setDirection(row.este, row.oeste, r.dx);
                setDirection(row.norte, row.sur, r.dy);

                blankPolyCorrections(row);

                validRows.add(row);
                distances.add(distance);
                azimuths.add(az);
                dxs.add(r.dx);
                dys.add(r.dy);
                labels.add((effectiveEst.isEmpty() ? "?" : effectiveEst) + " - " + (pvText.isEmpty() ? "?" : pvText));
                estLabels.add(effectiveEst);
                pvLabels.add(pvText);

                sumDx += r.dx;
                sumDy += r.dy;
                perimeter += Math.abs(distance);
                ok++;
            } catch (Exception e) {
                row.rumbo.setText("ERROR");
                blankPolyNumbers(row);
            }
        }

        if (validRows.isEmpty() || perimeter == 0) {
            if (polyCheckResult != null) polyCheckResult.setText("Agrega azimut y distancia para calcular la poligonal.");
            if (polyProcedureResult != null) {
                polyProcedureResult.setText("Procedimiento pendiente. Primero llena una fila con azimut y distancia.");
            }
            Toast.makeText(this, "No hay filas válidas", Toast.LENGTH_SHORT).show();
            return;
        }

        SpannableStringBuilder procedure = buildPolyProcedureHeader();
        for (int i = 0; i < validRows.size(); i++) {
            appendPartialProcedureRow(procedure, labels.get(i), azimuths.get(i), distances.get(i), dxs.get(i), dys.get(i), i + 1);
        }

        boolean closedChain = isClosedPolygonChain(estLabels, pvLabels);
        if (validRows.size() < 3 || !closedChain) {
            for (TableDataRow row : validRows) {
                blankPolyCorrections(row);
            }
            String check = "Parciales calculadas: " + ok
                    + "\nFilas solo referencia: " + referenceRows
                    + "\nPerímetro ingresado: " + f3(perimeter)
                    + "\nFaltan lados o la secuencia no cierra."
                    + "\nPara compensar debe ser: A-B, B-C, C-D... y terminar regresando al inicio.";
            if (polyCheckResult != null) polyCheckResult.setText(check);
            appendPlain(procedure, "\nPara corregidas, X/Y y gráfico completo, llena una poligonal cerrada: el último P.V. debe volver al primer EST.\n");
            if (polyProcedureResult != null) polyProcedureResult.setText(procedure);
            Toast.makeText(this, "Parciales calculadas. La poligonal todavía no cierra.", Toast.LENGTH_SHORT).show();
            return;
        }

        Double x0 = optNumber(polyX0Input.getText().toString());
        Double y0 = optNumber(polyY0Input.getText().toString());
        double x = x0 != null ? x0 : 0;
        double y = y0 != null ? y0 : 0;
        double startX = x;
        double startY = y;

        for (int i = 0; i < validRows.size(); i++) {
            TableDataRow row = validRows.get(i);
            double distance = distances.get(i);
            double dx = dxs.get(i);
            double dy = dys.get(i);
            double corrX = -sumDx * (Math.abs(distance) / perimeter);
            double corrY = -sumDy * (Math.abs(distance) / perimeter);
            double cdx = dx + corrX;
            double cdy = dy + corrY;

            setDirection(row.eCorr, row.wCorr, cdx);
            setDirection(row.nCorr, row.sCorr, cdy);
            x += cdx;
            y += cdy;
            row.x.setText(f3(x));
            row.y.setText(f3(y));

            appendCorrectionProcedureRow(procedure, labels.get(i), corrX, corrY, cdx, cdy, x, y);
        }

        double closeError = Math.sqrt(sumDx * sumDx + sumDy * sumDy);
        double precision = closeError == 0 ? 0 : perimeter / closeError;
        String check = "Filas calculadas: " + ok
                + "\nFilas solo referencia: " + referenceRows
                + "\nPerímetro: " + f3(perimeter)
                + "\nError X: " + f3(sumDx)
                + "\nError Y: " + f3(sumDy)
                + "\nError de cierre: " + f3(closeError)
                + "\nPrecisión aprox.: 1/" + (precision == 0 ? "∞" : String.format(Locale.US, "%.0f", precision))
                + "\nInicio: X " + f3(startX) + "  Y " + f3(startY)
                + "\nFinal corregido: X " + f3(x) + "  Y " + f3(y);
        if (polyCheckResult != null) polyCheckResult.setText(check);
        appendProcedureSummary(procedure, sumDx, sumDy, perimeter, closeError);
        if (polyProcedureResult != null) polyProcedureResult.setText(procedure);
        Toast.makeText(this, "Poligonal calculada: " + ok + " lados", Toast.LENGTH_SHORT).show();
    }

    private void setDirection(TextView positive, TextView negative, double value) {
        double v = cleanZero(value);
        if (v > 0) {
            positive.setText(f3(v));
            negative.setText("—");
        } else if (v < 0) {
            positive.setText("—");
            negative.setText(f3(-v));
        } else {
            positive.setText("0.000");
            negative.setText("—");
        }
    }

    private void blankPolyRow(TableDataRow row) {
        row.rumbo.setText("—");
        blankPolyNumbers(row);
    }

    private void blankPolyNumbers(TableDataRow row) {
        row.sen.setText("—"); row.cos.setText("—");
        row.este.setText("—"); row.oeste.setText("—"); row.norte.setText("—"); row.sur.setText("—");
        blankPolyCorrections(row);
    }

    private void blankPolyCorrections(TableDataRow row) {
        row.eCorr.setText("—"); row.wCorr.setText("—"); row.nCorr.setText("—"); row.sCorr.setText("—");
        row.x.setText("—"); row.y.setText("—");
    }

    private boolean isClosedPolygonChain(List<String> ests, List<String> pvs) {
        if (ests == null || pvs == null || ests.size() < 3 || ests.size() != pvs.size()) return false;
        String first = normalizeLabel(ests.get(0));
        String last = normalizeLabel(pvs.get(pvs.size() - 1));
        if (first.isEmpty() || last.isEmpty() || !first.equals(last)) return false;
        for (int i = 1; i < ests.size(); i++) {
            String prevPv = normalizeLabel(pvs.get(i - 1));
            String currentEst = normalizeLabel(ests.get(i));
            if (prevPv.isEmpty() || currentEst.isEmpty() || !prevPv.equals(currentEst)) return false;
        }
        return true;
    }

    private String normalizeLabel(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US);
    }

    private CoordinateResult coordinateResult(double az, double distance) {
        double rad = Math.toRadians(az);
        double sen = Math.sin(rad);
        double cos = Math.cos(rad);
        double dx = distance * sen;
        double dy = distance * cos;
        CoordinateResult r = new CoordinateResult();
        r.sen = sen;
        r.cos = cos;
        r.dx = dx;
        r.dy = dy;
        r.este = dx > 0 ? dx : 0;
        r.oeste = dx < 0 ? -dx : 0;
        r.norte = dy > 0 ? dy : 0;
        r.sur = dy < 0 ? -dy : 0;
        return r;
    }

    private String coordinateOutput(double az, double distance, CoordinateResult r) {
        return "Azimut: " + formatDms(az) + "\n"
                + "Rumbo: " + rumbo(az) + "\n"
                + "Distancia: " + f3(distance) + "\n"
                + "Seno: " + f6(r.sen) + "\n"
                + "Coseno: " + f6(r.cos) + "\n"
                + "ΔX = D × sen(Az): " + f3(r.dx) + "\n"
                + "ΔY = D × cos(Az): " + f3(r.dy) + "\n"
                + "Este: " + f3(r.este) + "   Oeste: " + f3(r.oeste) + "\n"
                + "Norte: " + f3(r.norte) + "   Sur: " + f3(r.sur);
    }

    private double parseAngle(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");

        Matcher m = Pattern.compile("-?\\d+(?:\\.\\d+)?").matcher(s);
        ArrayList<Double> nums = new ArrayList<>();
        while (m.find()) nums.add(Double.parseDouble(m.group()));
        if (nums.isEmpty()) throw new IllegalArgumentException("no number");

        double deg = nums.get(0);
        double sign = deg < 0 ? -1 : 1;
        deg = Math.abs(deg);
        double min = nums.size() > 1 ? Math.abs(nums.get(1)) : 0;
        double sec = nums.size() > 2 ? Math.abs(nums.get(2)) : 0;

        if (nums.size() == 1 && !s.contains("°") && !s.contains("º") && !s.contains("'") && !s.contains("\"") && !s.contains(" ")) {
            String clean = s.startsWith("-") ? s.substring(1) : s;
            if (clean.matches("\\d+\\.\\d{2}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1]);
                if (mm < 60) return sign * (d + mm / 60.0);
            }
            if (clean.matches("\\d+\\.\\d{4}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1].substring(0, 2));
                double ss = Double.parseDouble(parts[1].substring(2, 4));
                if (mm < 60 && ss < 60) return sign * (d + mm / 60.0 + ss / 3600.0);
            }
            return nums.get(0);
        }
        return sign * (deg + min / 60.0 + sec / 3600.0);
    }

    private Double optNumber(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseNumber(s);
    }

    private Double optAngle(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseAngle(s);
    }

    private double parseRumbo(String value) {
        String s = value.trim().toUpperCase(Locale.US).replace("º", "°").replace("O", "W");
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        s = s.replaceAll("\\s+", " ").trim();
        char first = 0;
        char last = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 'N' || c == 'S') { first = c; break; }
        }
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == 'E' || c == 'W') { last = c; break; }
        }
        if (first == 0 || last == 0) throw new IllegalArgumentException("bad rumbo");
        int i1 = s.indexOf(first);
        int i2 = s.lastIndexOf(last);
        if (i2 <= i1) throw new IllegalArgumentException("bad rumbo");
        String middle = s.substring(i1 + 1, i2).trim();
        double ang = parseAngle(middle);
        if (ang < 0 || ang > 90) throw new IllegalArgumentException("angle out of range");
        if (first == 'N' && last == 'E') return ang;
        if (first == 'S' && last == 'E') return 180.0 - ang;
        if (first == 'S' && last == 'W') return 180.0 + ang;
        return 360.0 - ang;
    }

    private double parseNumber(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        return Double.parseDouble(s);
    }

    private double normalize(double angle) {
        double a = angle % 360.0;
        if (a < 0) a += 360.0;
        if (Math.abs(a - 360.0) < 0.0000001) a = 0;
        return a;
    }

    private double contraAzimuth(double az) {
        return normalize(az + 180.0);
    }

    private String rumbo(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N";
        if (near(a, 90)) return "E";
        if (near(a, 180)) return "S";
        if (near(a, 270)) return "W";
        if (a > 0 && a < 90) return "N " + formatDms(a) + " E";
        if (a > 90 && a < 180) return "S " + formatDms(180 - a) + " E";
        if (a > 180 && a < 270) return "S " + formatDms(a - 180) + " W";
        return "N " + formatDms(360 - a) + " W";
    }

    private double rumboAngle(double az) {
        double a = normalize(az);
        if (a <= 90) return a;
        if (a <= 180) return 180.0 - a;
        if (a <= 270) return a - 180.0;
        return 360.0 - a;
    }

    private String quadrantLabel(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 90) || near(a, 180) || near(a, 270) || near(a, 360)) {
            return "Eje cardinal";
        }
        if (a > 0 && a < 90) return "NE";
        if (a > 90 && a < 180) return "SE";
        if (a > 180 && a < 270) return "SW";
        return "NW";
    }

    private boolean near(double a, double b) {
        return Math.abs(a - b) < 0.0000001;
    }

    private String formatDms(double angle) {
        double a = Math.abs(angle);
        int deg = (int) Math.floor(a);
        double minFloat = (a - deg) * 60.0;
        int min = (int) Math.floor(minFloat);
        double secFloat = (minFloat - min) * 60.0;
        int sec = (int) Math.round(secFloat);
        if (sec == 60) { sec = 0; min++; }
        if (min == 60) { min = 0; deg++; }
        return String.format(Locale.US, "%02d°%02d'%02d\"", deg, min, sec);
    }

    private String f3(double v) {
        return String.format(Locale.US, "%.3f", cleanZero(v));
    }

    private String f6(double v) {
        return String.format(Locale.US, "%.6f", cleanZero(v));
    }

    private double cleanZero(double v) {
        return Math.abs(v) < 0.0000000001 ? 0 : v;
    }

    private void showError(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cardColor);
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(2), borderColor);
        box.setBackground(gd);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = tv(text, 20, true);
        v.setPadding(0, 0, 0, dp(8));
        return v;
    }

    private TextView small(String text) {
        TextView v = tv(text, 13, false);
        v.setTextColor(subTextColor);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    private TextView smallCenter(String text) {
        TextView v = small(text);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(2), 0, 0);
        return v;
    }

    private TextView tv(String text, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private LinearLayout labeledInput(String label, EditText input) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), 0, 0, 0);
        wrap.addView(title);
        wrap.addView(input);
        return wrap;
    }

    private LinearLayout labeledText(String label, TextView value) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), 0, 0, 0);
        wrap.addView(title);
        wrap.addView(value);
        return wrap;
    }

    private TextView smallResultCell(String text) {
        TextView v = tv(text, 16, false);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        v.setLayoutParams(lp);
        v.setBackground(inputBg(false));
        return v;
    }

    private void trackAngleEdit(EditText input) {
        if (input == null) return;
        input.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus && v instanceof EditText) activeAngleInput = (EditText) v;
        });
        input.setOnClickListener(v -> {
            if (v instanceof EditText) activeAngleInput = (EditText) v;
        });
    }

    private LinearLayout angleShortcutBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setPadding(0, dp(2), 0, dp(6));
        String[] keys = {"°", "'", "\"", "00'", "00\"", "⌫"};
        for (String k : keys) {
            Button b = btn(k);
            b.setTextSize(13);
            b.setPadding(dp(2), dp(6), dp(2), dp(6));
            b.setOnClickListener(v -> {
                if ("⌫".equals(k)) deleteFromAngleInput();
                else insertIntoAngleInput(k);
            });
            wrap.addView(b, weightParams());
        }
        return wrap;
    }

    private void insertIntoAngleInput(String text) {
        EditText target = activeAngleInput;
        if (target == null) target = azInput;
        if (target == null) return;
        target.requestFocus();
        int start = Math.max(0, target.getSelectionStart());
        int end = Math.max(0, target.getSelectionEnd());
        if (end < start) { int tmp = start; start = end; end = tmp; }
        target.getText().replace(start, end, text);
        target.setSelection(start + text.length());
    }

    private void deleteFromAngleInput() {
        EditText target = activeAngleInput;
        if (target == null) target = azInput;
        if (target == null) return;
        target.requestFocus();
        int start = Math.max(0, target.getSelectionStart());
        int end = Math.max(0, target.getSelectionEnd());
        if (end > start) {
            target.getText().delete(start, end);
            target.setSelection(start);
        } else if (start > 0) {
            target.getText().delete(start - 1, start);
            target.setSelection(start - 1);
        }
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        e.setLayoutParams(lp);
        e.setBackground(inputBg(false));
        return e;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        b.setBackground(gd);
        return b;
    }

    private TextView resultBox(String text) {
        TextView v = tv(text, 15, false);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setBackground(inputBg(true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(10), 0, 0);
        v.setLayoutParams(lp);
        return v;
    }

    private GradientDrawable inputBg(boolean result) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(result ? resultFillColor : inputFillColor);
        gd.setCornerRadius(dp(9));
        gd.setStroke(dp(1), result ? resultStrokeColor : inputStrokeColor);
        return gd;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private SpannableStringBuilder buildPolyProcedureHeader() {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        appendColored(sb, "PROCEDIMIENTO SIMPLE DE POLIGONAL\n", borderColor);
        appendPlain(sb, "Datos que tú llenas: estación, P.V., azimut y distancia.\n");
        appendPlain(sb, "La app hace 4 pasos:\n");
        appendPlain(sb, "1) Convierte el azimut a rumbo.\n");
        appendPlain(sb, "2) Del rumbo toma solo el ángulo interior. Ejemplo: N 33°30' W → se usa 33°30'.\n");
        appendPlain(sb, "3) La letra final E/W usa ");
        appendColored(sb, "seno", Color.rgb(255, 171, 0));
        appendPlain(sb, ":  E/W = Distancia × seno(ángulo del rumbo).\n");
        appendPlain(sb, "4) La letra inicial N/S usa ");
        appendColored(sb, "coseno", Color.rgb(0, 184, 148));
        appendPlain(sb, ":  N/S = Distancia × coseno(ángulo del rumbo).\n");
        appendPlain(sb, "5) Después reparte el error con Bowditch y saca X/Y acumuladas.\n\n");
        return sb;
    }

    private void appendProcedureRow(SpannableStringBuilder sb, String label, double az, double distance, double dx, double dy,
                                    double corrX, double corrY, double cdx, double cdy, double x, double y, int index) {
        appendColored(sb, "Lado " + index + ": " + label + "\n", Color.rgb(41, 121, 255));
        appendPlain(sb, "Azimut: ");
        appendColored(sb, formatDms(az), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Rumbo: ");
        appendColored(sb, rumbo(az), Color.rgb(194, 170, 120));
        appendPlain(sb, "\nDistancia: ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nΔE/ΔW = ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, " × ");
        appendColored(sb, "sen(" + formatDms(az) + ")", Color.rgb(255, 171, 0));
        appendPlain(sb, " = ");
        appendColored(sb, f3(Math.abs(dx)), dx >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, dx >= 0 ? "  → E\n" : "  → W\n");
        appendPlain(sb, "ΔN/ΔS = ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, " × ");
        appendColored(sb, "cos(" + formatDms(az) + ")", Color.rgb(0, 184, 148));
        appendPlain(sb, " = ");
        appendColored(sb, f3(Math.abs(dy)), dy >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, dy >= 0 ? "  → N\n" : "  → S\n");
        appendPlain(sb, "Corrección X: ");
        appendColored(sb, f3(corrX), Color.rgb(142, 68, 173));
        appendPlain(sb, "   Corrección Y: ");
        appendColored(sb, f3(corrY), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nE/W corregida: ");
        appendColored(sb, f3(Math.abs(cdx)), cdx >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, cdx >= 0 ? "  → E" : "  → W");
        appendPlain(sb, "   N/S corregida: ");
        appendColored(sb, f3(Math.abs(cdy)), cdy >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, cdy >= 0 ? "  → N\n" : "  → S\n");
        appendPlain(sb, "X = ");
        appendColored(sb, f3(x), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Y = ");
        appendColored(sb, f3(y), Color.rgb(41, 121, 255));
        appendPlain(sb, "\n\n");
    }

    private void appendPartialProcedureRow(SpannableStringBuilder sb, String label, double az, double distance, double dx, double dy, int index) {
        String rb = rumbo(az);
        double rbAngle = rumboAngle(az);
        String ew = dx >= 0 ? "E" : "W";
        String ns = dy >= 0 ? "N" : "S";
        appendColored(sb, "Fila " + index + ": " + label + "\n", Color.rgb(41, 121, 255));
        appendPlain(sb, "Dato escrito: azimut + distancia.\n");
        appendPlain(sb, "Azimut: ");
        appendColored(sb, formatDms(az), Color.rgb(41, 121, 255));
        appendPlain(sb, "  →  Rumbo: ");
        appendColored(sb, rb, Color.rgb(194, 170, 120));
        appendPlain(sb, "\nDistancia: ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nÁngulo útil del rumbo: ");
        appendColored(sb, formatDms(rbAngle), Color.rgb(41, 121, 255));
        appendPlain(sb, "  (sale del rumbo, no del azimut completo)");
        appendPlain(sb, "\nComo el rumbo termina en ");
        appendColored(sb, ew, Color.rgb(255, 171, 0));
        appendPlain(sb, ", se usa SENO:\n");
        appendColored(sb, ew + " = " + f3(distance) + " × sen(" + formatDms(rbAngle) + ") = " + f3(Math.abs(dx)), Color.rgb(255, 171, 0));
        appendPlain(sb, "\nComo el rumbo empieza en ");
        appendColored(sb, ns, Color.rgb(0, 184, 148));
        appendPlain(sb, ", se usa COSENO:\n");
        appendColored(sb, ns + " = " + f3(distance) + " × cos(" + formatDms(rbAngle) + ") = " + f3(Math.abs(dy)), Color.rgb(0, 184, 148));
        appendPlain(sb, "\nEntonces en la tabla va: ");
        appendColored(sb, ew + " = " + f3(Math.abs(dx)), Color.rgb(255, 171, 0));
        appendPlain(sb, " y ");
        appendColored(sb, ns + " = " + f3(Math.abs(dy)), Color.rgb(0, 184, 148));
        appendPlain(sb, "\n\n");
    }

    private void appendCorrectionProcedureRow(SpannableStringBuilder sb, String label,
                                             double corrX, double corrY, double cdx, double cdy, double x, double y) {
        appendColored(sb, "Corrección " + label + "\n", Color.rgb(142, 68, 173));
        appendPlain(sb, "Cx: ");
        appendColored(sb, f3(corrX), Color.rgb(142, 68, 173));
        appendPlain(sb, "   Cy: ");
        appendColored(sb, f3(corrY), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nE/W corregida: ");
        appendColored(sb, f3(Math.abs(cdx)), Color.rgb(255, 171, 0));
        appendPlain(sb, cdx >= 0 ? " → E" : " → W");
        appendPlain(sb, "   N/S corregida: ");
        appendColored(sb, f3(Math.abs(cdy)), Color.rgb(0, 184, 148));
        appendPlain(sb, cdy >= 0 ? " → N" : " → S");
        appendPlain(sb, "\nX: ");
        appendColored(sb, f3(x), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Y: ");
        appendColored(sb, f3(y), Color.rgb(41, 121, 255));
        appendPlain(sb, "\n\n");
    }

    private void appendProcedureSummary(SpannableStringBuilder sb, double sumDx, double sumDy, double perimeter, double closeError) {
        appendColored(sb, "RESUMEN FINAL\n", borderColor);
        appendPlain(sb, "Σ parciales X: ");
        appendColored(sb, f3(sumDx), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nΣ parciales Y: ");
        appendColored(sb, f3(sumDy), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nPerímetro: ");
        appendColored(sb, f3(perimeter), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nError de cierre: ");
        appendColored(sb, f3(closeError), Color.rgb(231, 76, 60));
    }

    private void appendPlain(SpannableStringBuilder sb, String text) {
        sb.append(text);
    }

    private void appendColored(SpannableStringBuilder sb, String text, int color) {
        int start = sb.length();
        sb.append(text);
        sb.setSpan(new ForegroundColorSpan(color), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void showProcedureDialog(String title, CharSequence content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        TextView tv = new TextView(this);
        tv.setText(content);
        tv.setTextColor(Color.rgb(30, 33, 40));
        tv.setTextSize(13);
        tv.setLineSpacing(0, 1.08f);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        scroll.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(scroll)
                .setPositiveButton("Cerrar", null)
                .show();
    }

    private void showPolyGraphDialog() {
        ArrayList<GraphPoint> points = buildPolyGraphPoints();
        if (points.size() < 2) {
            showError("Primero calcula la poligonal cerrada para generar el gráfico.");
            return;
        }

        final AlertDialog[] dialogRef = new AlertDialog[1];
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(12));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(10, 24, 39));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(210, 218, 230) : Color.rgb(58, 76, 100));
        panel.setBackground(panelBg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setText("⌁");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(24);
        icon.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(borderColor);
        iconBg.setCornerRadius(dp(10));
        icon.setBackground(iconBg);
        head.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(10), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText("Gráfico de poligonal");
        title.setTextColor(textColor);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Croquis con cuadrícula, puntos y brújula norte.");
        subtitle.setTextColor(subTextColor);
        subtitle.setTextSize(13);
        texts.addView(subtitle);
        head.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("×");
        close.setGravity(Gravity.CENTER);
        close.setTextColor(subTextColor);
        close.setTextSize(30);
        close.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        head.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        panel.addView(head);

        TextView hint = small("Sale de las coordenadas X/Y calculadas. La brújula es referencia de orientación.");
        hint.setPadding(0, dp(10), 0, dp(4));
        panel.addView(hint);

        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        legend.addView(legendItem("━", "Poligonal", Color.rgb(41, 121, 255)));
        legend.addView(legendItem("●", "Vértice", textColor));
        legend.addView(legendItem("✥", "Brújula", textColor));
        panel.addView(legend);

        PolyGraphView graph = new PolyGraphView(this, points);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360));
        gp.setMargins(0, dp(8), 0, dp(8));
        panel.addView(graph, gp);

        TextView info = resultBox("ⓘ El croquis no está a escala exacta. Sirve para revisar la forma y verificar las coordenadas en la tabla.");
        info.setTextSize(12);
        panel.addView(info);

        Button closeBtn = btn("Cerrar ✓");
        closeBtn.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        panel.addView(closeBtn);

        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            }
        });
        dialog.show();
    }

    private View legendItem(String symbol, String text, int color) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(0, 0, dp(14), 0);
        TextView s = new TextView(this);
        s.setText(symbol);
        s.setTextColor(color);
        s.setTextSize(18);
        s.setTypeface(Typeface.DEFAULT_BOLD);
        item.addView(s);
        TextView t = new TextView(this);
        t.setText("  " + text);
        t.setTextColor(subTextColor);
        t.setTextSize(12);
        item.addView(t);
        return item;
    }

    private ArrayList<GraphPoint> buildPolyGraphPoints() {
        ArrayList<GraphPoint> points = new ArrayList<>();
        double startX = optNumber(polyX0Input.getText().toString()) != null ? optNumber(polyX0Input.getText().toString()) : 0;
        double startY = optNumber(polyY0Input.getText().toString()) != null ? optNumber(polyY0Input.getText().toString()) : 0;
        String startLabel = "Inicio";
        for (TableDataRow r : tableRows) {
            String est = r.est.getText().toString().trim();
            String pv = r.pv.getText().toString().trim();
            String dist = r.dist.getText().toString().trim();
            if (!est.isEmpty() && !pv.isEmpty() && !dist.isEmpty()) {
                startLabel = est.toUpperCase(Locale.US);
                break;
            }
        }
        points.add(new GraphPoint(startLabel, startX, startY));
        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow row = tableRows.get(i);
            Double x = optNumber(row.x.getText().toString());
            Double y = optNumber(row.y.getText().toString());
            if (x == null || y == null) continue;
            String label = row.pv.getText().toString().trim();
            if (label.isEmpty()) label = String.valueOf(i + 1);
            label = label.toUpperCase(Locale.US);
            points.add(new GraphPoint(label, x, y));
        }
        return points;
    }

    private LinearLayout tableColorBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        Button text = btn("Texto");
        text.setTextSize(12);
        text.setOnClickListener(v -> applyManualTextColor());
        wrap.addView(text, weightParams());
        Button bg = btn("Fondo");
        bg.setTextSize(12);
        bg.setOnClickListener(v -> applyManualBgColor(false, false));
        wrap.addView(bg, weightParams());
        Button row = btn("Fila");
        row.setTextSize(12);
        row.setOnClickListener(v -> applyManualBgColor(true, false));
        wrap.addView(row, weightParams());
        Button col = btn("Col.");
        col.setTextSize(12);
        col.setOnClickListener(v -> applyManualBgColor(false, true));
        wrap.addView(col, weightParams());
        Button reset = btn("Normal");
        reset.setTextSize(12);
        reset.setOnClickListener(v -> resetCoordTableColors());
        wrap.addView(reset, weightParams());
        return wrap;
    }

    private void registerColorCell(View cell, TableLayout table, int row, int col) {
        cell.setOnClickListener(v -> {
            selectColorCell(v, table, row, col);
            if (v instanceof EditText && col == 2) activeAngleInput = (EditText) v;
            if (v instanceof EditText && col == 3) selectedDistCell = (EditText) v;
        });
        cell.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                selectColorCell(v, table, row, col);
                if (v instanceof EditText && col == 2) activeAngleInput = (EditText) v;
                if (v instanceof EditText && col == 3) selectedDistCell = (EditText) v;
            }
        });
    }

    private void selectColorCell(View cell, TableLayout table, int row, int col) {
        selectedColorCell = cell;
        selectedColorTable = table;
        selectedColorRow = row;
        selectedColorCol = col;
    }

    private void applyManualTextColor() {
        if (selectedColorCell == null) {
            Toast.makeText(this, "Primero toca una celda de la tabla", Toast.LENGTH_SHORT).show();
            return;
        }
        manualTextColorIndex = (manualTextColorIndex + 1) % manualTextColors.length;
        if (selectedColorCell instanceof TextView) {
            ((TextView) selectedColorCell).setTextColor(manualTextColors[manualTextColorIndex]);
        }
    }

    private void applyManualBgColor(boolean wholeRow, boolean wholeColumn) {
        if (selectedColorCell == null || selectedColorTable == null) {
            Toast.makeText(this, "Primero toca una celda de la tabla", Toast.LENGTH_SHORT).show();
            return;
        }
        manualBgColorIndex = (manualBgColorIndex + 1) % manualBgColors.length;
        int color = manualBgColors[manualBgColorIndex];
        if (wholeRow) {
            TableRow row = (TableRow) selectedColorTable.getChildAt(selectedColorRow);
            for (int c = 0; c < row.getChildCount(); c++) setCellManualBg(row.getChildAt(c), color);
        } else if (wholeColumn) {
            for (int r = 1; r < selectedColorTable.getChildCount(); r++) {
                View rv = selectedColorTable.getChildAt(r);
                if (rv instanceof TableRow) {
                    TableRow tr = (TableRow) rv;
                    if (selectedColorCol >= 0 && selectedColorCol < tr.getChildCount()) setCellManualBg(tr.getChildAt(selectedColorCol), color);
                }
            }
        } else {
            setCellManualBg(selectedColorCell, color);
        }
    }

    private void setCellManualBg(View cell, int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setStroke(1, tableLineColor);
        cell.setBackground(gd);
    }

    private void resetCoordTableColors() {
        if (coordTable == null) return;
        for (int r = 1; r < coordTable.getChildCount(); r++) {
            View rv = coordTable.getChildAt(r);
            if (!(rv instanceof TableRow)) continue;
            TableRow tr = (TableRow) rv;
            for (int c = 0; c < tr.getChildCount(); c++) {
                View cell = tr.getChildAt(c);
                boolean locked = !(cell instanceof EditText);
                cell.setBackground(cellBg(locked));
                if (cell instanceof TextView) ((TextView) cell).setTextColor(textColor);
            }
        }
        for (TableDataRow row : tableRows) applyDefaultPolyColors(row);
    }

    private void applyDefaultPolyColors(TableDataRow row) {
        row.este.setTextColor(sinColor);
        row.oeste.setTextColor(sinColor);
        row.eCorr.setTextColor(sinColor);
        row.wCorr.setTextColor(sinColor);
        row.norte.setTextColor(cosColor);
        row.sur.setTextColor(cosColor);
        row.nCorr.setTextColor(cosColor);
        row.sCorr.setTextColor(cosColor);
    }

    private TableRow headerRowCompact(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellTextCompact(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEditCompact(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(12);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(4), dp(2), dp(4), dp(2));
        e.setMinWidth(dp(82));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellTextCompact(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(12);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(4), dp(6), dp(4), dp(6));
        v.setMinWidth(dp(82));
        v.setBackground(cellBg(true));
        return v;
    }

    private TableRow headerSpanRow(String[] headers, int[] spans) {
        TableRow tr = new TableRow(this);
        for (int i = 0; i < headers.length; i++) {
            TextView v = cellText(headers[i]);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            v.setMinWidth(dp(96 * spans[i]));
            tr.addView(v);
        }
        return tr;
    }

    private TableRow headerRow(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellText(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEdit(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(13);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(6), dp(3), dp(6), dp(3));
        e.setMinWidth(dp(96));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(7), dp(6), dp(7));
        v.setMinWidth(dp(96));
        v.setBackground(cellBg(true));
        return v;
    }

    private GradientDrawable cellBg(boolean locked) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(locked ? cellLockedColor : cellEditColor);
        gd.setStroke(1, tableLineColor);
        return gd;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private static class CoordinateResult {
        double sen;
        double cos;
        double dx;
        double dy;
        double este;
        double oeste;
        double norte;
        double sur;
    }

    private interface ColorPickListener {
        void onPick(int index);
    }

    private static class TableDataRow {
        EditText est;
        EditText pv;
        EditText az;
        EditText dist;
        TextView rumbo;
        TextView sen;
        TextView cos;
        TextView este;
        TextView oeste;
        TextView norte;
        TextView sur;
        TextView eCorr;
        TextView wCorr;
        TextView nCorr;
        TextView sCorr;
        TextView x;
        TextView y;
    }

    private static class LevelDataRow {
        EditText pv;
        EditText vAtras;
        EditText vIntermedia;
        EditText vAdelante;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class StadiaLevelRow {
        EditText pv;
        EditText tipo;
        EditText hInf;
        EditText hMedio;
        EditText hSup;
        TextView distancia;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class GraphPoint {
        String label;
        double x;
        double y;

        GraphPoint(String label, double x, double y) {
            this.label = label;
            this.x = x;
            this.y = y;
        }
    }

    public static class ZoomLayout extends FrameLayout {
        private final ScaleGestureDetector detector;
        private float scale = 1.0f;

        public ZoomLayout(Context context) {
            super(context);
            detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    scale *= d.getScaleFactor();
                    scale = Math.max(0.80f, Math.min(scale, 3.00f));
                    setScaleX(scale);
                    setScaleY(scale);
                    setPivotX(0);
                    setPivotY(0);
                    return true;
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            detector.onTouchEvent(event);
            return true;
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            detector.onTouchEvent(ev);
            return super.dispatchTouchEvent(ev);
        }

        public void resetZoom() {
            scale = 1.0f;
            setScaleX(scale);
            setScaleY(scale);
        }
    }

    public class PolyGraphView extends View {
        private final List<GraphPoint> points;
        private final Paint plotBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint minorGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint majorGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lineGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassWhitePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public PolyGraphView(Context context, List<GraphPoint> points) {
            super(context);
            this.points = points;

            plotBgPaint.setColor(Color.rgb(248, 251, 255));
            plotBgPaint.setStyle(Paint.Style.FILL);

            minorGridPaint.setColor(Color.rgb(235, 241, 248));
            minorGridPaint.setStrokeWidth(dp(1));

            majorGridPaint.setColor(Color.rgb(205, 217, 232));
            majorGridPaint.setStrokeWidth(dp(1));

            framePaint.setColor(Color.rgb(135, 150, 170));
            framePaint.setStyle(Paint.Style.STROKE);
            framePaint.setStrokeWidth(dp(1));

            axisPaint.setColor(Color.rgb(30, 33, 40));
            axisPaint.setStrokeWidth(dp(1));
            axisPaint.setStyle(Paint.Style.STROKE);
            axisPaint.setTextSize(dp(10));
            axisPaint.setTypeface(Typeface.DEFAULT);
            axisPaint.setTextAlign(Paint.Align.CENTER);

            lineGlowPaint.setColor(Color.rgb(122, 176, 255));
            lineGlowPaint.setStrokeWidth(dp(5));
            lineGlowPaint.setStyle(Paint.Style.STROKE);
            lineGlowPaint.setStrokeCap(Paint.Cap.ROUND);
            lineGlowPaint.setStrokeJoin(Paint.Join.ROUND);
            lineGlowPaint.setAlpha(80);

            linePaint.setColor(Color.rgb(41, 121, 255));
            linePaint.setStrokeWidth(dp(3));
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            linePaint.setStrokeJoin(Paint.Join.ROUND);

            pointPaint.setColor(Color.rgb(18, 20, 24));
            pointPaint.setStyle(Paint.Style.FILL);

            pointStrokePaint.setColor(Color.WHITE);
            pointStrokePaint.setStyle(Paint.Style.STROKE);
            pointStrokePaint.setStrokeWidth(dp(2));

            labelPaint.setColor(Color.rgb(18, 20, 24));
            labelPaint.setTextSize(dp(12));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);

            compassPaint.setColor(Color.rgb(18, 20, 24));
            compassPaint.setStyle(Paint.Style.FILL);
            compassWhitePaint.setColor(Color.WHITE);
            compassWhitePaint.setStyle(Paint.Style.FILL);
            compassStrokePaint.setColor(Color.rgb(18, 20, 24));
            compassStrokePaint.setStyle(Paint.Style.STROKE);
            compassStrokePaint.setStrokeWidth(dp(1));
            compassStrokePaint.setTextSize(dp(10));
            compassStrokePaint.setTypeface(Typeface.DEFAULT_BOLD);
            compassStrokePaint.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();

            float left = dp(42);
            float top = dp(16);
            float right = w - dp(14);
            float bottom = h - dp(32);

            canvas.drawRoundRect(left, top, right, bottom, dp(9), dp(9), plotBgPaint);

            double minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
            double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY;
            for (GraphPoint p : points) {
                minX = Math.min(minX, p.x);
                maxX = Math.max(maxX, p.x);
                minY = Math.min(minY, p.y);
                maxY = Math.max(maxY, p.y);
            }
            if (!Double.isFinite(minX) || !Double.isFinite(minY)) return;
            double spanX = Math.max(1.0, maxX - minX);
            double spanY = Math.max(1.0, maxY - minY);
            minX -= spanX * 0.10;
            maxX += spanX * 0.10;
            minY -= spanY * 0.10;
            maxY += spanY * 0.10;
            spanX = Math.max(1.0, maxX - minX);
            spanY = Math.max(1.0, maxY - minY);

            float plotLeft = left + dp(22);
            float plotTop = top + dp(14);
            float plotRight = right - dp(12);
            float plotBottom = bottom - dp(24);
            double scaleX = (plotRight - plotLeft) / spanX;
            double scaleY = (plotBottom - plotTop) / spanY;

            for (int i = 0; i <= 20; i++) {
                float x = plotLeft + (plotRight - plotLeft) * i / 20f;
                float y = plotTop + (plotBottom - plotTop) * i / 20f;
                canvas.drawLine(x, plotTop, x, plotBottom, (i % 4 == 0) ? majorGridPaint : minorGridPaint);
                canvas.drawLine(plotLeft, y, plotRight, y, (i % 4 == 0) ? majorGridPaint : minorGridPaint);
            }

            canvas.drawLine(plotLeft, plotBottom, plotRight, plotBottom, axisPaint);
            canvas.drawLine(plotLeft, plotTop, plotLeft, plotBottom, axisPaint);
            canvas.drawLine(plotRight, plotBottom, plotRight - dp(7), plotBottom - dp(4), axisPaint);
            canvas.drawLine(plotRight, plotBottom, plotRight - dp(7), plotBottom + dp(4), axisPaint);
            canvas.drawLine(plotLeft, plotTop, plotLeft - dp(4), plotTop + dp(7), axisPaint);
            canvas.drawLine(plotLeft, plotTop, plotLeft + dp(4), plotTop + dp(7), axisPaint);

            axisPaint.setTextAlign(Paint.Align.CENTER);
            for (int i = 0; i <= 4; i++) {
                float x = plotLeft + (plotRight - plotLeft) * i / 4f;
                double val = minX + spanX * i / 4.0;
                canvas.drawLine(x, plotBottom, x, plotBottom + dp(4), axisPaint);
                canvas.drawText(fmtTick(val), x, plotBottom + dp(16), axisPaint);
            }
            axisPaint.setTextAlign(Paint.Align.RIGHT);
            for (int i = 0; i <= 4; i++) {
                float y = plotBottom - (plotBottom - plotTop) * i / 4f;
                double val = minY + spanY * i / 4.0;
                canvas.drawLine(plotLeft - dp(4), y, plotLeft, y, axisPaint);
                canvas.drawText(fmtTick(val), plotLeft - dp(7), y + dp(4), axisPaint);
            }
            axisPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("X (m)", (plotLeft + plotRight) / 2f, h - dp(8), axisPaint);
            axisPaint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("Y (m)", left + dp(2), top + dp(12), axisPaint);

            Path poly = new Path();
            for (int i = 0; i < points.size(); i++) {
                GraphPoint p = points.get(i);
                float px = (float) (plotLeft + (p.x - minX) * scaleX);
                float py = (float) (plotBottom - (p.y - minY) * scaleY);
                if (i == 0) poly.moveTo(px, py); else poly.lineTo(px, py);
            }
            canvas.drawPath(poly, lineGlowPaint);
            canvas.drawPath(poly, linePaint);

            for (GraphPoint p : points) {
                float px = (float) (plotLeft + (p.x - minX) * scaleX);
                float py = (float) (plotBottom - (p.y - minY) * scaleY);
                canvas.drawCircle(px, py, dp(5), pointPaint);
                canvas.drawCircle(px, py, dp(5), pointStrokePaint);
                canvas.drawText(p.label, px + dp(8), py - dp(7), labelPaint);
            }

            canvas.drawRoundRect(left, top, right, bottom, dp(9), dp(9), framePaint);
            drawCompassRose(canvas, right - dp(55), top + dp(56), dp(30));
        }

        private String fmtTick(double value) {
            if (Math.abs(value) < 0.0001) value = 0;
            if (Math.abs(value) >= 100) return String.format(Locale.US, "%.0f", value);
            if (Math.abs(value - Math.round(value)) < 0.001) return String.format(Locale.US, "%.0f", value);
            return String.format(Locale.US, "%.1f", value);
        }

        private void drawCompassRose(Canvas canvas, float cx, float cy, float r) {
            canvas.drawCircle(cx, cy, r, compassStrokePaint);
            canvas.drawCircle(cx, cy, r * 0.72f, compassStrokePaint);
            for (int i = 0; i < 16; i++) {
                double a = Math.toRadians(i * 22.5 - 90);
                float len = (i % 2 == 0) ? r * 0.92f : r * 0.62f;
                float x = (float) (cx + Math.cos(a) * len);
                float y = (float) (cy + Math.sin(a) * len);
                canvas.drawLine(cx, cy, x, y, compassStrokePaint);
            }
            for (int i = 0; i < 8; i++) {
                double a = Math.toRadians(i * 45 - 90);
                double leftA = a - Math.toRadians(10);
                double rightA = a + Math.toRadians(10);
                float tipR = (i % 2 == 0) ? r * 0.85f : r * 0.58f;
                float baseR = r * 0.13f;
                Path path = new Path();
                path.moveTo((float) (cx + Math.cos(a) * tipR), (float) (cy + Math.sin(a) * tipR));
                path.lineTo((float) (cx + Math.cos(leftA) * baseR), (float) (cy + Math.sin(leftA) * baseR));
                path.lineTo((float) (cx + Math.cos(rightA) * baseR), (float) (cy + Math.sin(rightA) * baseR));
                path.close();
                canvas.drawPath(path, (i % 2 == 0) ? compassPaint : compassWhitePaint);
                canvas.drawPath(path, compassStrokePaint);
            }
            compassStrokePaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("N", cx, cy - r - dp(4), compassStrokePaint);
            canvas.drawText("S", cx, cy + r + dp(12), compassStrokePaint);
            canvas.drawText("E", cx + r + dp(10), cy + dp(4), compassStrokePaint);
            canvas.drawText("W", cx - r - dp(10), cy + dp(4), compassStrokePaint);
        }
    }

    public class CompassView extends View {
        private final Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private double azimuth;

        public CompassView(Context context) {
            super(context);
            circlePaint.setStyle(Paint.Style.STROKE);
            circlePaint.setStrokeWidth(dp(2));
            circlePaint.setColor(compassRingColor);

            crossPaint.setStyle(Paint.Style.STROKE);
            crossPaint.setStrokeWidth(dp(1));
            crossPaint.setColor(subTextColor);

            textPaint.setColor(textColor);
            textPaint.setTextSize(dp(12));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(Paint.Align.CENTER);

            arrowPaint.setStyle(Paint.Style.STROKE);
            arrowPaint.setStrokeWidth(dp(3));
            arrowPaint.setStrokeCap(Paint.Cap.ROUND);
            arrowPaint.setStrokeJoin(Paint.Join.ROUND);
            arrowPaint.setColor(compassArrowColor);
        }

        public void setAzimuth(double azimuth) {
            this.azimuth = azimuth;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) * 0.34f;

            Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(250, 252, 255) : Color.rgb(13, 18, 28));
            canvas.drawCircle(cx, cy, r, fillPaint);
            canvas.drawCircle(cx, cy, r, circlePaint);
            for (int i = 0; i < 36; i++) {
                double rr = Math.toRadians(i * 10 - 90);
                float outerX = (float) (cx + Math.cos(rr) * r);
                float outerY = (float) (cy + Math.sin(rr) * r);
                float innerFactor = (i % 9 == 0) ? 0.84f : 0.90f;
                float innerX = (float) (cx + Math.cos(rr) * r * innerFactor);
                float innerY = (float) (cy + Math.sin(rr) * r * innerFactor);
                canvas.drawLine(innerX, innerY, outerX, outerY, crossPaint);
            }
            canvas.drawLine(cx, cy - r, cx, cy + r, crossPaint);
            canvas.drawLine(cx - r, cy, cx + r, cy, crossPaint);

            canvas.drawText("N", cx, cy - r - dp(10), textPaint);
            canvas.drawText("S", cx, cy + r + dp(18), textPaint);
            canvas.drawText("E", cx + r + dp(16), cy + dp(4), textPaint);
            canvas.drawText("W", cx - r - dp(16), cy + dp(4), textPaint);

            double rad = Math.toRadians(azimuth - 90.0);
            float tipX = (float) (cx + Math.cos(rad) * r * 0.92f);
            float tipY = (float) (cy + Math.sin(rad) * r * 0.92f);
            float backX = (float) (cx - Math.cos(rad) * r * 0.20f);
            float backY = (float) (cy - Math.sin(rad) * r * 0.20f);
            canvas.drawLine(backX, backY, tipX, tipY, arrowPaint);

            double leftRad = rad + Math.toRadians(150);
            double rightRad = rad - Math.toRadians(150);
            float side = r * 0.18f;
            canvas.drawLine(tipX, tipY, (float) (tipX + Math.cos(leftRad) * side), (float) (tipY + Math.sin(leftRad) * side), arrowPaint);
            canvas.drawLine(tipX, tipY, (float) (tipX + Math.cos(rightRad) * side), (float) (tipY + Math.sin(rightRad) * side), arrowPaint);

            Paint centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            centerPaint.setColor(compassArrowColor);
            canvas.drawCircle(cx, cy, dp(4), centerPaint);

            // Texto inferior del círculo se muestra fuera del dibujo, en cada tarjeta.
        }
    }
}
