package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Vista liviana para practicar lecturas de mira tipo E.
 * Se dibuja por código para evitar imágenes pesadas y se prioriza
 * una apariencia más legible y cercana a una mira real de campo.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int textColor;
    private final int subTextColor;
    private final int panelColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.textColor = textColor;
        this.subTextColor = subTextColor;
        this.panelColor = panelColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        int halfSpanMm = 45 + random.nextInt(56); // 45 mm a 100 mm por lado.
        int middleMm = 500 + random.nextInt(4001); // 0.500 m a 4.500 m.
        if (middleMm - halfSpanMm < 120) middleMm = 120 + halfSpanMm;
        if (middleMm + halfSpanMm > 4880) middleMm = 4880 - halfSpanMm;

        // Evita caer exactamente en la marca centimétrica para obligar
        // a estimar el último milímetro visualmente.
        if (middleMm % 10 == 0) middleMm += 3 + random.nextInt(4);

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;

        double span = Math.max(0.24, (upperReading - lowerReading) + 0.12);
        double center = middleReading;
        visibleMin = Math.floor((center - span / 2.0) * 100.0) / 100.0;
        visibleMax = Math.ceil((center + span / 2.0) * 100.0) / 100.0;
        if (visibleMin < 0.0) {
            visibleMax -= visibleMin;
            visibleMin = 0.0;
        }
        if (visibleMax > 5.0) {
            visibleMin -= (visibleMax - 5.0);
            visibleMax = 5.0;
        }
        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = dp(500);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float footerHeight = dp(54);
        float cx = w / 2f;
        float cy = (h - footerHeight) / 2f;
        float radius = Math.min(w * 0.46f, (h - footerHeight) * 0.46f);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(16), dp(16), paint);

        // Bisel del ocular.
        paint.setColor(Color.rgb(16, 20, 26));
        paint.setShadowLayer(dp(10), 0f, dp(3), Color.argb(120, 0, 0, 0));
        canvas.drawCircle(cx, cy, radius + dp(9), paint);
        paint.clearShadowLayer();
        paint.setColor(Color.rgb(244, 244, 244));
        canvas.drawCircle(cx, cy, radius, paint);

        Path fieldPath = new Path();
        fieldPath.addCircle(cx, cy, radius - dp(2), Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(fieldPath);

        drawScopeBackground(canvas, cx, cy, radius);

        float staffWidth = Math.min(dp(176), radius * 0.86f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = cy - radius - dp(28);
        float staffBottom = cy + radius + dp(28);

        float numberColLeft = staffLeft;
        float numberColRight = staffLeft + staffWidth * 0.49f;
        float patternColLeft = numberColRight;
        float patternColRight = staffRight;

        // Cuerpo de la mira.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(84, 84, 84));
        paint.setStrokeWidth(dp(1));
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        // Separadores verticales.
        paint.setColor(Color.rgb(116, 116, 116));
        paint.setStrokeWidth(dp(1));
        canvas.drawLine(numberColRight, staffTop, numberColRight, staffBottom, paint);
        float numberGuide = numberColLeft + (numberColRight - numberColLeft) * 0.12f;
        paint.setColor(Color.rgb(195, 195, 195));
        paint.setStrokeWidth(dp(0.7f));
        canvas.drawLine(numberGuide, staffTop, numberGuide, staffBottom, paint);

        drawStaffScale(canvas, staffTop, staffBottom, numberColLeft, numberColRight, patternColLeft, patternColRight);
        drawThreads(canvas, cx, radius, staffTop, staffBottom);

        canvas.restoreToCount(save);

        // Aro exterior.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(5));
        paint.setColor(Color.rgb(17, 22, 28));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(Color.rgb(76, 76, 76));
        canvas.drawCircle(cx, cy, radius - dp(4), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(12f));
        paint.setColor(subTextColor);
        canvas.drawText("Mira tipo E realista · números negros · patrón rojo", cx, h - dp(28), paint);
        canvas.drawText("Cada franja roja o blanca representa 1 cm", cx, h - dp(10), paint);
    }

    private void drawScopeBackground(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(248, 248, 246));
        canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint);

        // Viñeta suave para dar sensación de lente.
        paint.setColor(Color.argb(18, 0, 0, 0));
        canvas.drawCircle(cx + radius * 0.24f, cy - radius * 0.15f, radius * 0.98f, paint);
        paint.setColor(Color.argb(16, 0, 0, 0));
        canvas.drawCircle(cx - radius * 0.24f, cy + radius * 0.24f, radius * 0.88f, paint);
    }

    private void drawStaffScale(Canvas canvas, float staffTop, float staffBottom,
                                float numberColLeft, float numberColRight,
                                float patternColLeft, float patternColRight) {
        int startCm = (int) Math.floor(visibleMin * 100.0) - 1;
        int endCm = (int) Math.ceil(visibleMax * 100.0) + 1;

        // Cuadrícula horizontal centimétrica y de ayuda.
        for (int cm = startCm; cm <= endCm; cm++) {
            double value = cm / 100.0;
            float y = readingToY(value, staffTop, staffBottom);
            if (y < staffTop - dp(2) || y > staffBottom + dp(2)) continue;

            boolean decimeter = floorMod(cm, 10) == 0;
            boolean fiveCm = floorMod(cm, 5) == 0;
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(decimeter ? Color.rgb(100, 100, 100)
                    : (fiveCm ? Color.rgb(160, 160, 160) : Color.rgb(215, 215, 215)));
            paint.setStrokeWidth(decimeter ? dp(1.1f) : (fiveCm ? dp(0.75f) : dp(0.5f)));
            canvas.drawLine(numberColLeft, y, patternColRight, y, paint);
        }

        int startDm = (int) Math.floor(visibleMin * 10.0) - 1;
        int endDm = (int) Math.ceil(visibleMax * 10.0) + 1;
        for (int dm = startDm; dm <= endDm; dm++) {
            double dmValue = dm / 10.0;
            double nextDmValue = dmValue + 0.10;
            float y1 = readingToY(nextDmValue, staffTop, staffBottom);
            float y2 = readingToY(dmValue, staffTop, staffBottom);
            float top = Math.min(y1, y2);
            float bottom = Math.max(y1, y2);
            if (bottom < staffTop || top > staffBottom) continue;

            drawDecimeterNumber(canvas, dm, top, bottom, numberColLeft, numberColRight);
            drawDecimeterPattern(canvas, top, bottom, dm, patternColLeft, patternColRight);
        }
    }

    private void drawDecimeterNumber(Canvas canvas, int dm, float top, float bottom,
                                     float numberColLeft, float numberColRight) {
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(Math.min(dp(30), Math.max(dp(22), (bottom - top) * 0.34f)));
        paint.setColor(Color.rgb(18, 18, 18));

        float centerX = numberColLeft + (numberColRight - numberColLeft) * 0.56f;
        float centerY = (top + bottom) / 2f;
        canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)), centerX, centeredTextBaseline(centerY), paint);
    }

    private void drawDecimeterPattern(Canvas canvas, float top, float bottom, int dm,
                                      float patternLeft, float patternRight) {
        float colWidth = patternRight - patternLeft;
        float cmH = (bottom - top) / 10f;
        boolean toRight = floorMod(dm, 2) == 0;

        float margin = colWidth * 0.02f;
        float left = patternLeft + margin;
        float right = patternRight - margin;
        float width = right - left;
        float spineW = width * 0.14f;
        float longArm = width * 0.88f;
        float shortArm = width * 0.52f;
        float tinyArm = width * 0.34f;

        float spineLeft = toRight ? left : right - spineW;
        float spineRight = spineLeft + spineW;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(224, 26, 26));

        // Espina vertical del patrón tipo E.
        float eTop = top + cmH * 1f;
        float eBottom = top + cmH * 9f;
        canvas.drawRect(spineLeft, eTop, spineRight, eBottom, paint);

        // Pequeño rectángulo superior.
        drawBar(canvas, toRight, left, right, top + cmH * 0.05f, top + cmH * 0.90f, tinyArm);
        // Brazo superior largo.
        drawBar(canvas, toRight, left, right, top + cmH * 1.10f, top + cmH * 3.00f, longArm);
        // Rectángulos intermedios de 1 cm.
        drawBar(canvas, toRight, left, right, top + cmH * 3.25f, top + cmH * 4.00f, tinyArm);
        // Brazo medio corto.
        drawBar(canvas, toRight, left, right, top + cmH * 4.10f, top + cmH * 5.90f, shortArm);
        // Rectángulos intermedios de 1 cm.
        drawBar(canvas, toRight, left, right, top + cmH * 6.10f, top + cmH * 6.90f, tinyArm);
        // Brazo inferior largo.
        drawBar(canvas, toRight, left, right, top + cmH * 7.00f, top + cmH * 8.90f, longArm);
        // Pequeño rectángulo inferior.
        drawBar(canvas, toRight, left, right, top + cmH * 9.10f, top + cmH * 9.95f, tinyArm);

        // Línea lateral tenue para acabado visual.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(0.6f));
        paint.setColor(Color.rgb(184, 184, 184));
        canvas.drawLine(right, top, right, bottom, paint);
    }

    private void drawBar(Canvas canvas, boolean toRight, float left, float right,
                         float top, float bottom, float width) {
        if (toRight) {
            canvas.drawRect(left, top, Math.min(left + width, right), bottom, paint);
        } else {
            canvas.drawRect(Math.max(right - width, left), top, right, bottom, paint);
        }
    }

    private void drawThreads(Canvas canvas, float cx, float radius, float staffTop, float staffBottom) {
        drawThread(canvas, "LS", upperReading, cx, radius, staffTop, staffBottom, false);
        drawThread(canvas, "LM", middleReading, cx, radius, staffTop, staffBottom, true);
        drawThread(canvas, "LI", lowerReading, cx, radius, staffTop, staffBottom, false);

        // Hilo vertical central.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(Color.rgb(18, 18, 18));
        canvas.drawLine(cx, cyFromScope(staffTop, staffBottom, radius, true), cx,
                cyFromScope(staffTop, staffBottom, radius, false), paint);
    }

    private float cyFromScope(float staffTop, float staffBottom, float radius, boolean top) {
        float mid = (staffTop + staffBottom) / 2f;
        return top ? mid - radius * 0.92f : mid + radius * 0.92f;
    }

    private void drawThread(Canvas canvas, String label, double reading, float cx, float radius,
                            float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        float left = cx - radius + dp(8);
        float right = cx + radius - dp(8);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(20, 20, 20));
        paint.setStrokeWidth(middle ? dp(2.4f) : dp(1.7f));
        canvas.drawLine(left, y, right, y, paint);

        // Etiquetas LS / LM / LI al lado izquierdo, claras pero discretas.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(38, 38, 38));
        paint.setTextSize(dp(13));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(label, left + dp(8), y - dp(5), paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(16, 16, 16));
        paint.setStrokeWidth(dp(1.2f));
        canvas.drawLine(cx, y - dp(8), cx, y + dp(8), paint);
    }

    private float centeredTextBaseline(float centerY) {
        Paint.FontMetrics fm = paint.getFontMetrics();
        return centerY - (fm.ascent + fm.descent) / 2f;
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double t = (visibleMax - reading) / range;
        return (float) (top + t * (bottom - top));
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
